from __future__ import annotations

import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from app.config import Settings
from app.models import CandidateProfile, CandidateProfileDraft
from app.services.candidate_portal import CandidatePortalStore


class CandidatePortalTests(unittest.TestCase):
    def test_builder_application_with_supporting_docs_writes_workspace_profile(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            store = CandidatePortalStore(settings)
            session = store.register_candidate(
                full_name="Aditi Sharma",
                email="aditi@example.com",
                password="strong-pass-123",
            )

            draft = CandidateProfileDraft(
                full_name="Aditi Sharma",
                email="aditi@example.com",
                phone="+91 99999 99999",
                location="Bengaluru",
                headline="Applied AI Engineer",
                summary="Builds live RAG and ranking systems.",
                skills=["Python", "Pathway", "RAG", "FastAPI"],
                education=[{"institution": "IIIT", "degree": "B.Tech", "field": "CSE"}],
                experience=[{"company": "Pulse Systems", "title": "AI Engineer", "highlights": ["Built live ranking APIs"]}],
                projects=[{"name": "Talent Graph", "description": "Recruiting intelligence stack", "technologies": ["Python", "Pathway"]}],
                certifications=[{"name": "AWS Certified", "issuer": "AWS"}],
            )

            store.save_profile(session.candidate_account_id, draft)
            store.save_document(
                candidate_account_id=session.candidate_account_id,
                company_id="acme",
                role_ids=["acme--realtime-rag-engineer"],
                company_candidate_id=None,
                document_type="skill_certificate",
                file_name="python-cert.pdf",
                raw_bytes=b"certificate-proof",
                tags=["Python", "Pathway"],
                title="Python Certificate",
            )
            application = store.upsert_application(
                candidate_account_id=session.candidate_account_id,
                company_id="acme",
                role_ids=["acme--realtime-rag-engineer"],
                resume_mode="builder",
                profile_draft=draft,
                resume_document=None,
            )

            self.assertEqual(application["company_id"], "acme")
            self.assertEqual(application["resume_version"], 1)
            self.assertTrue(application["company_candidate_id"].startswith("acme--"))
            stream_file = settings.resume_stream_dir / "acme" / f"{application['company_candidate_id']}.json"
            self.assertTrue(stream_file.exists())

    def test_builder_application_can_submit_without_supporting_documents(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            store = CandidatePortalStore(settings)
            session = store.register_candidate(
                full_name="Rahul Menon",
                email="rahul@example.com",
                password="strong-pass-123",
            )
            draft = CandidateProfileDraft(
                full_name="Rahul Menon",
                email="rahul@example.com",
                headline="Backend Engineer",
                summary="Builds backend and platform systems.",
                skills=["Python", "FastAPI", "Docker"],
            )
            application = store.upsert_application(
                candidate_account_id=session.candidate_account_id,
                company_id="acme",
                role_ids=["acme--backend-engineer"],
                resume_mode="builder",
                profile_draft=draft,
                resume_document=None,
            )

            self.assertEqual(application["company_id"], "acme")
            self.assertEqual(application["verification_summary"]["document_count"], 0)
            self.assertEqual(application["verification_summary"]["verification_score"], 0.0)

    def test_recruiter_feedback_preserves_existing_verification_state(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            store = CandidatePortalStore(settings)
            session = store.register_candidate(
                full_name="Priya Nair",
                email="priya@example.com",
                password="strong-pass-123",
            )
            draft = CandidateProfileDraft(
                full_name="Priya Nair",
                email="priya@example.com",
                headline="Analytics Engineer",
                summary="Builds analytics and data products.",
                skills=["Python", "SQL", "Analytics"],
            )
            application = store.upsert_application(
                candidate_account_id=session.candidate_account_id,
                company_id="aurora-analytics",
                role_ids=["aurora-analytics--analytics-engineer"],
                resume_mode="builder",
                profile_draft=draft,
                resume_document=None,
            )

            store.record_verification_review(
                company_id="aurora-analytics",
                company_candidate_id=application["company_candidate_id"],
                role_id="aurora-analytics--analytics-engineer",
                decision="verified",
                notes="Proof was confirmed.",
                reviewer="Aurora Hiring",
            )
            updated = store.record_recruiter_feedback(
                company_id="aurora-analytics",
                company_candidate_id=application["company_candidate_id"],
                role_id="aurora-analytics--analytics-engineer",
                label="shortlist",
                notes="Strong fit for the role.",
                recruiter="Aurora Hiring",
            )

            role_state = (updated or {}).get("role_statuses", {}).get("aurora-analytics--analytics-engineer", {})
            self.assertEqual(role_state.get("verification_status"), "verified")
            self.assertEqual(role_state.get("status"), "shortlist")

    def test_candidate_can_delete_own_message(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            store = CandidatePortalStore(settings)
            session = store.register_candidate(
                full_name="Priya Nair",
                email="priya@example.com",
                password="strong-pass-123",
            )
            posted = store.post_message(
                company_id="aurora-analytics",
                candidate_account_id=session.candidate_account_id,
                company_candidate_id="aurora-analytics--candidate-priya",
                role_id="aurora-analytics--analytics-engineer",
                sender_type="candidate",
                sender_name="Priya Nair",
                message="Please confirm whether my documents are sufficient.",
                application_id="app-1",
            )

            deleted = store.delete_message(
                candidate_account_id=session.candidate_account_id,
                message_id=posted["message_id"],
            )

            self.assertIsNotNone(deleted)
            self.assertEqual(
                store.list_messages(
                    candidate_account_id=session.candidate_account_id,
                    company_id="aurora-analytics",
                    role_id="aurora-analytics--analytics-engineer",
                ),
                [],
            )

    def test_upsert_application_reuses_existing_company_candidate_id(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            store = CandidatePortalStore(settings)
            session = store.register_candidate(
                full_name="Aditi Sharma",
                email="aditi@example.com",
                password="strong-pass-123",
            )
            linked_candidate = CandidateProfile(
                candidate_id="iit-bhubaneswar--aditi-sharma-linked",
                name="Aditi Sharma",
                email="aditi@example.com",
                current_title="Applied AI Engineer",
                summary="Builds real-time ranking systems.",
                skills=["Python", "Pathway", "RAG"],
                source_path="stream/aditi.json",
            )
            store.ensure_linked_application(
                candidate_account_id=session.candidate_account_id,
                company_id="iit-bhubaneswar",
                company_candidate_id=linked_candidate.candidate_id,
                role_ids=["iit-bhubaneswar--real-time-rag-engineer"],
                candidate_profile=linked_candidate,
            )
            application = store.upsert_application(
                candidate_account_id=session.candidate_account_id,
                company_id="iit-bhubaneswar",
                role_ids=["iit-bhubaneswar--real-time-rag-engineer"],
                resume_mode="builder",
                profile_draft=CandidateProfileDraft(
                    full_name="Aditi Sharma",
                    email="aditi@example.com",
                    headline="Applied AI Engineer",
                    summary="Builds real-time ranking systems.",
                    skills=["Python", "Pathway", "RAG"],
                ),
                resume_document=None,
            )

            self.assertEqual(application["company_candidate_id"], linked_candidate.candidate_id)


if __name__ == "__main__":
    unittest.main()
