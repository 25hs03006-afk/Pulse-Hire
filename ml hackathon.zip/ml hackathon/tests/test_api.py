from __future__ import annotations

import json
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import Mock, patch

from app.config import Settings
from app.models import CandidateProfile
from app.services.uploads import resolve_candidate_upload_destination


class ApiUploadTests(unittest.TestCase):
    def test_duplicate_resume_reuses_existing_candidate_identity(self) -> None:
        existing = CandidateProfile(
            candidate_id="aditi-sharma-resume",
            name="Aditi Sharma",
            email="aditi.sharma@example.com",
            phone="+91 98765 43001",
            location="Bengaluru, India",
            current_title="Senior MLOps Engineer",
            source_path="artifacts/stream/resumes/aditi-sharma-resume.json",
        )
        preview = CandidateProfile(
            candidate_id="aditi-sharma",
            name="Aditi Sharma",
            email="aditi.sharma@example.com",
            phone="+91 98765 43001",
            location="Bengaluru, India",
            current_title="Senior MLOps Engineer",
            source_path="aditi.pdf",
        )

        destination, candidate_id, matched_existing = resolve_candidate_upload_destination(
            preview=preview,
            suffix=".pdf",
            resumes_dir=__import__("pathlib").Path("data/resumes"),
            existing_candidates=[existing],
            raw_bytes=b"resume-bytes",
        )

        self.assertTrue(matched_existing)
        self.assertEqual(candidate_id, existing.candidate_id)
        self.assertEqual(destination, __import__("pathlib").Path("data/resumes") / "aditi-sharma-resume.pdf")


class CompanyDiscoveryTests(unittest.TestCase):
    def test_workspace_roles_are_discoverable_without_registered_company_record(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            workspace_dir = settings.jobs_dir / "iit-bhubaneswar"
            workspace_dir.mkdir(parents=True, exist_ok=True)
            (workspace_dir / "role.json").write_text(
                json.dumps(
                    {
                        "title": "Real-Time RAG Engineer",
                        "team": "Talent Intelligence Lab",
                        "location": "Bhubaneswar",
                        "description": "Build live retrieval systems.",
                        "must_have_skills": ["Python", "Pathway", "RAG"],
                        "responsibilities": ["Build streaming pipelines", "Own retrieval quality"],
                        "education_requirement": "B.Tech",
                        "hiring_target": 2,
                    }
                ),
                encoding="utf-8",
            )

            with patch("app.api.settings", settings), patch("app.api.auth_manager") as auth_manager, patch(
                "app.api.runtime_state"
            ) as runtime_state, patch("app.api.orchestrator") as orchestrator:
                auth_manager.list_companies.return_value = []
                auth_manager.get_company.return_value = None
                runtime_state.list_jobs.return_value = []
                orchestrator.handle_job_upsert.side_effect = lambda job: job
                orchestrator.refresh_job = Mock()

                from app.api import _company_roles_payload, _company_record, _discover_company_workspaces

                workspace_ids = _discover_company_workspaces()
                roles = _company_roles_payload("iit-bhubaneswar")
                company = _company_record("iit-bhubaneswar")

                self.assertIn("iit-bhubaneswar", workspace_ids)
                self.assertEqual(len(roles), 1)
                self.assertEqual(roles[0]["title"], "Real-Time RAG Engineer")
                self.assertEqual(company["company_name"], "IIT Bhubaneswar")
                self.assertFalse(company["is_registered"])


if __name__ == "__main__":
    unittest.main()
