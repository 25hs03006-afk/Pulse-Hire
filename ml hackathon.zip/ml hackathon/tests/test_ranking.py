from __future__ import annotations

import unittest

from app.config import get_settings
from app.models import CandidateProfile, FeedbackEntry, JobProfile, RetrievalHit
from app.services.ranking.engine import RankingService


class RankingTests(unittest.TestCase):
    def test_ranking_prefers_better_skill_match(self) -> None:
        settings = get_settings()
        engine = RankingService(settings)
        job = JobProfile(
            job_id="rag-engineer",
            title="RAG Engineer",
            description="Build real-time Pathway systems.",
            must_have_skills=["Python", "Pathway", "RAG"],
            nice_to_have_skills=["Docker"],
            responsibilities=[],
            keywords=["streaming", "retrieval"],
            min_years_experience=4,
            education_requirement="Bachelors",
            source_path="job.json",
        )
        candidate_a = CandidateProfile(
            candidate_id="candidate-a",
            name="A Candidate",
            skills=["Python", "Pathway", "RAG", "Docker"],
            education=["B.Tech in Computer Science"],
            experience_highlights=["Built streaming retrieval pipelines"],
            projects=[],
            years_experience=5,
            source_path="a.pdf",
        )
        candidate_b = CandidateProfile(
            candidate_id="candidate-b",
            name="B Candidate",
            skills=["Python", "Docker"],
            education=["B.Tech in Computer Science"],
            experience_highlights=["Built backend APIs"],
            projects=[],
            years_experience=5,
            source_path="b.pdf",
        )
        feedback = [
            FeedbackEntry(
                feedback_id="fb-1",
                candidate_id="candidate-a",
                job_id="rag-engineer",
                label="strong_yes",
                score_adjustment=0.35,
                source_path="feedback.json",
            )
        ]
        hits = [
            RetrievalHit(candidate_id="candidate-a", rank=1, score=0.9, snippet="Strong Pathway and RAG experience."),
            RetrievalHit(candidate_id="candidate-b", rank=2, score=0.3, snippet="General backend experience."),
        ]

        snapshot = engine.rank_job(job, [candidate_a, candidate_b], feedback, hits)
        self.assertEqual(snapshot.rankings[0].candidate.candidate_id, "candidate-a")
        self.assertGreater(snapshot.rankings[0].breakdown.total_score, snapshot.rankings[1].breakdown.total_score)
        self.assertGreater(snapshot.rankings[0].breakdown.confidence_score, 0.6)
        self.assertGreaterEqual(snapshot.rankings[0].breakdown.stability_score, 0.4)


if __name__ == "__main__":
    unittest.main()
