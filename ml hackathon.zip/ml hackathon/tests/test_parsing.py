from __future__ import annotations

import io
import zipfile
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from app.config import Settings, get_settings
from app.services.dataset_loader import ResumeDatasetLoader
from app.services.job_loader import JobDatasetLoader, parse_job_records
from app.services.datasets import import_dataset_bundle
from app.services.parsers.extractors import parse_feedback_document, parse_job_document, parse_resume_document
from app.services.parsers.resume_parser import parse_resume_records


class ParsingTests(unittest.TestCase):
    def test_resume_text_parsing_extracts_skills_and_experience(self) -> None:
        resume_text = """
        Aditi Sharma
        Senior MLOps Engineer
        Bengaluru, India
        aditi.sharma@example.com | +91 9876543001

        Summary
        Built streaming RAG systems with Python, Pathway, FastAPI, Docker, Kubernetes, and AWS.

        Experience
        Jan 2020 - Present: Built real-time resume matching pipelines.

        Education
        B.Tech in Computer Science
        """
        candidate = parse_resume_document("aditi_sharma_resume.txt", resume_text.encode("utf-8"))
        self.assertEqual(candidate.name, "Aditi Sharma")
        self.assertIn("Python", candidate.skills)
        self.assertIn("Pathway", candidate.skills)
        self.assertGreaterEqual(candidate.years_experience, 4.0)

    def test_job_json_parsing_extracts_requirements(self) -> None:
        payload = {
            "title": "Real-Time RAG Engineer",
            "must_have_skills": ["Python", "Pathway", "RAG"],
            "nice_to_have_skills": ["Kubernetes"],
            "min_years_experience": 4,
            "description": "Build adaptive candidate ranking systems.",
        }
        job = parse_job_document("job.json", __import__("json").dumps(payload).encode("utf-8"))
        self.assertEqual(job.title, "Real-Time RAG Engineer")
        self.assertIn("Pathway", job.must_have_skills)
        self.assertEqual(job.min_years_experience, 4.0)

    def test_feedback_parsing_builds_entries(self) -> None:
        feedback_text = """
        candidate_id: aditi-sharma-resume
        job_id: realtime-rag-engineer
        label: strong_yes
        notes: Excellent Pathway implementation depth.
        """
        entries = parse_feedback_document("feedback.txt", feedback_text.encode("utf-8"))
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0].label, "strong_yes")
        self.assertGreater(entries[0].score_adjustment, 0.0)

    def test_resume_parsing_groups_skills(self) -> None:
        resume_text = """
        Nisha Iyer
        Senior Product Designer
        Bengaluru, India
        nisha.iyer@example.com
        Summary
        Designed in Figma, led user research, and shipped UX design systems with stakeholder management.
        Education
        Bachelor of Design
        """
        candidate = parse_resume_document("nisha_iyer_resume.txt", resume_text.encode("utf-8"))
        self.assertIn("Figma", candidate.skills)
        self.assertIn("Design", candidate.skill_groups)

    def test_dataset_bundle_import_routes_files_without_fixed_paths(self) -> None:
        settings = get_settings()
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            archive.writestr("resumes/alex_resume.txt", "Alex Doe\nPython\nFastAPI\n")
            archive.writestr("jobs/data_scientist.txt", "Data Scientist\nPython, SQL, Machine Learning")
            archive.writestr("feedback/review.txt", "candidate_id: alex-doe\nlabel: strong_yes\nnotes: Excellent fit")
        payload = import_dataset_bundle(buffer.getvalue(), "public-bundle.zip", settings)
        try:
            self.assertEqual(payload["counts"]["resumes"], 1)
            self.assertEqual(payload["counts"]["jobs"], 1)
            self.assertEqual(payload["counts"]["feedback"], 1)
        finally:
            for target in payload.get("imported_files", []):
                __import__("pathlib").Path(target).unlink(missing_ok=True)

    def test_non_resume_document_is_rejected(self) -> None:
        fake_resume = """
        GC ML HACKATHON
        Problem statement
        Evaluation criteria
        Submission format
        Judges and presentation rubric
        """
        with self.assertRaises(ValueError):
            parse_resume_document("hackathon_brief.txt", fake_resume.encode("utf-8"))

    def test_non_job_document_is_rejected(self) -> None:
        fake_job = """
        GC ML HACKATHON
        Problem statement
        Evaluation criteria
        Submission format
        Demo video
        """
        with self.assertRaises(ValueError):
            parse_job_document("hackathon_brief.txt", fake_job.encode("utf-8"))

    def test_resume_csv_dataset_expands_multiple_candidates(self) -> None:
        csv_payload = (
            "name,email,current_title,location,skills,summary,education,years_experience\n"
            "Aditi Sharma,aditi@example.com,Applied AI Engineer,Bengaluru,\"Python|Pathway|RAG|FastAPI\",Builds RAG systems,B.Tech,5\n"
            "Rahul Menon,rahul@example.com,NLP Engineer,Pune,\"Python|NLP|Vector Search|Docker\",Builds semantic search,M.S.,4\n"
        )
        candidates = parse_resume_records("resumes.csv", csv_payload.encode("utf-8"), {"path": "data/resumes/resumes.csv"})
        self.assertEqual(len(candidates), 2)
        self.assertNotEqual(candidates[0].candidate_id, candidates[1].candidate_id)

    def test_kaggle_resume_csv_maps_resume_str_and_category(self) -> None:
        csv_payload = (
            "Category,Resume_str\n"
            "\"Data Science\",\"Experienced data scientist with Python, SQL, Machine Learning, Pandas, and Scikit-learn. Built forecasting models and A/B tests.\"\n"
            "\"HR\",\"HR generalist with recruiting, onboarding, stakeholder management, and communication.\"\n"
        )
        candidates = parse_resume_records("kaggle_resume_dataset.csv", csv_payload.encode("utf-8"), {"path": "data/resumes/kaggle.csv"})
        self.assertEqual(len(candidates), 2)
        self.assertEqual(candidates[0].current_title, "Data Science")
        self.assertIn("Python", candidates[0].skills)
        self.assertTrue(candidates[0].name.startswith("Data Science Candidate"))

    def test_job_csv_dataset_expands_multiple_roles(self) -> None:
        csv_payload = (
            "title,team,description,required_skills,years_experience\n"
            "\"Software Engineer\",Platform,\"Build backend APIs\",\"Python|Docker|REST APIs\",3\n"
            "\"Data Scientist\",AI,\"Build ML models\",\"Python|SQL|Machine Learning\",4\n"
        )
        jobs = parse_job_records("jobs.csv", csv_payload.encode("utf-8"), {"path": "data/jobs/jobs.csv"})
        self.assertEqual(len(jobs), 2)
        self.assertNotEqual(jobs[0].job_id, jobs[1].job_id)

    def test_resume_loader_continues_past_invalid_documents(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
                minimum_candidate_pool_size=5,
                allow_synthetic_backfill=True,
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            (settings.resumes_dir / "good_resume.txt").write_text(
                "Aditi Sharma\nApplied AI Engineer\nPython, Pathway, RAG\nB.Tech\n5 years of experience",
                encoding="utf-8",
            )
            (settings.resumes_dir / "bad_resume.txt").write_text(
                "GC ML HACKATHON\nProblem statement\nEvaluation criteria",
                encoding="utf-8",
            )

            loader = ResumeDatasetLoader(settings)
            loader.sync_once()

            manifest = __import__("json").loads((settings.cache_dir / "resume_loader_manifest.json").read_text(encoding="utf-8"))
            self.assertIn(str(settings.resumes_dir / "good_resume.txt"), manifest)
            self.assertIn(str(settings.resumes_dir / "bad_resume.txt"), manifest)
            self.assertIn("error", manifest[str(settings.resumes_dir / "bad_resume.txt")])

            generated_files = list(settings.resume_stream_dir.glob("*.json"))
            self.assertGreaterEqual(len(generated_files), 5)

    def test_resume_loader_reprocesses_empty_manifest_records(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
                minimum_candidate_pool_size=0,
                allow_synthetic_backfill=False,
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            resume_path = settings.resumes_dir / "aditi_resume.txt"
            resume_payload = (
                "Aditi Sharma\n"
                "Applied AI Engineer\n"
                "Bengaluru, India\n"
                "aditi.sharma@example.com\n"
                "Python, Pathway, RAG, FastAPI\n"
                "B.Tech in Computer Science\n"
                "5 years of experience\n"
            )
            resume_path.write_text(resume_payload, encoding="utf-8")
            checksum = __import__("hashlib").sha1(resume_path.read_bytes()).hexdigest()
            (settings.cache_dir / "resume_loader_manifest.json").write_text(
                __import__("json").dumps(
                    {
                        str(resume_path): {
                            "checksum": checksum,
                            "candidate_ids": [],
                            "stream_paths": [],
                        }
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )

            loader = ResumeDatasetLoader(settings)
            loader.sync_once()

            stream_files = list(settings.resume_stream_dir.glob("*.json"))
            self.assertEqual(len(stream_files), 1)

    def test_job_loader_reprocesses_empty_manifest_records(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
                minimum_job_pool_size=0,
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            job_path = settings.jobs_dir / "realtime_rag_engineer.txt"
            job_payload = (
                "Real-Time RAG Engineer\n"
                "Team: Talent Intelligence Lab\n"
                "Location: Bengaluru / Remote\n"
                "Requirements\n"
                "- Python\n"
                "- Pathway\n"
                "- RAG\n"
                "- FastAPI\n"
                "- Docker\n"
                "Responsibilities\n"
                "- Build live ranking systems.\n"
                "- Maintain recruiter-facing decision support.\n"
            )
            job_path.write_text(job_payload, encoding="utf-8")
            checksum = __import__("hashlib").sha1(job_path.read_bytes()).hexdigest()
            (settings.cache_dir / "job_loader_manifest.json").write_text(
                __import__("json").dumps(
                    {
                        str(job_path): {
                            "checksum": checksum,
                            "job_ids": [],
                            "stream_paths": [],
                        }
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )

            loader = JobDatasetLoader(settings)
            loader.sync_once()

            stream_files = list(settings.job_stream_dir.glob("*.json"))
            self.assertEqual(len(stream_files), 1)

    def test_job_loader_restore_removes_suppression(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            loader = JobDatasetLoader(settings)
            loader.suppress_job("realtime-rag-engineer")
            loader.restore_job("realtime-rag-engineer")

            payload = __import__("json").loads((settings.cache_dir / "job_loader_suppressions.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["job_ids"], [])

    def test_resume_loader_restore_removes_suppression(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            loader = ResumeDatasetLoader(settings)
            loader.suppress_candidate("aditi-sharma-resume")
            loader.restore_candidate("aditi-sharma-resume")

            payload = __import__("json").loads((settings.cache_dir / "resume_loader_suppressions.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["candidate_ids"], [])

    def test_job_loader_reprocesses_restored_suppressed_records(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
                minimum_job_pool_size=0,
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            job_path = settings.jobs_dir / "realtime_rag_engineer.txt"
            job_payload = (
                "Real-Time RAG Engineer\n"
                "Team: Talent Intelligence Lab\n"
                "Location: Bengaluru / Remote\n"
                "Requirements\n"
                "- Python\n"
                "- Pathway\n"
                "- RAG\n"
                "- FastAPI\n"
                "- Docker\n"
                "Responsibilities\n"
                "- Build live ranking systems.\n"
            )
            job_path.write_text(job_payload, encoding="utf-8")
            checksum = __import__("hashlib").sha1(job_path.read_bytes()).hexdigest()
            (settings.cache_dir / "job_loader_manifest.json").write_text(
                __import__("json").dumps(
                    {
                        str(job_path): {
                            "checksum": checksum,
                            "job_ids": ["realtime-rag-engineer"],
                            "stream_paths": [],
                        }
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
            (settings.cache_dir / "job_loader_suppressions.json").write_text(
                __import__("json").dumps({"job_ids": []}, indent=2),
                encoding="utf-8",
            )

            loader = JobDatasetLoader(settings)
            loader.sync_once()

            stream_files = list(settings.job_stream_dir.glob("*.json"))
            self.assertEqual(len(stream_files), 1)


if __name__ == "__main__":
    unittest.main()
