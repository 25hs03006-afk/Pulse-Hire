from __future__ import annotations

import unittest

from app.models import FeedbackEntry
from app.services.state.store import RuntimeState


class RuntimeStateTests(unittest.TestCase):
    def test_feedback_lookup_and_source_grouping(self) -> None:
        state = RuntimeState()
        source_path = "data/feedback/review.json"
        entries = [
            FeedbackEntry(
                feedback_id="fb-1",
                candidate_id="candidate-a",
                job_id="job-1",
                label="strong_yes",
                notes="Strong fit",
                source_path=source_path,
            ),
            FeedbackEntry(
                feedback_id="fb-2",
                candidate_id="candidate-b",
                job_id="job-1",
                label="hold",
                notes="Needs more validation",
                source_path=source_path,
            ),
        ]

        state.replace_feedback_from_source(source_path, entries)

        self.assertEqual(state.get_feedback("fb-1").candidate_id, "candidate-a")
        self.assertEqual(len(state.get_feedback_entries_for_source(source_path)), 2)


if __name__ == "__main__":
    unittest.main()
