from __future__ import annotations

import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from app.config import Settings
from app.models import ApprovalDraft, ApprovalSignoffDraft, ATSRequisitionDraft, CandidateStageDraft, JobProfile
from app.services.ats import ATSWorkflowStore
from app.services.auth import AuthManager, seed_company_password
from app.services.candidate_portal import CandidatePortalStore, seed_candidate_password


class PlatformFoundationTests(unittest.TestCase):
    def test_auth_manager_persists_company_session_in_sqlite(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            manager = AuthManager(root)
            session = manager.register_company(
                company_name="Acme Hiring",
                admin_name="Owner",
                email="owner@example.com",
                password="StrongPass123!",
            )

            reloaded = AuthManager(root)
            fetched = reloaded.get_session(session.token)

            self.assertIsNotNone(fetched)
            self.assertEqual(fetched.workspace_id, session.workspace_id)
            self.assertEqual(fetched.role, "owner")

    def test_ats_workflow_tracks_stage_and_approval(self) -> None:
        with TemporaryDirectory() as tmpdir:
            store = ATSWorkflowStore(Path(tmpdir) / "platform.db")
            job = JobProfile(
                job_id="acme--backend-engineer",
                title="Backend Engineer",
                team="Platform",
                description="Build APIs",
                must_have_skills=["Python", "FastAPI"],
                source_path="jobs/backend.json",
            )
            store.ensure_requisition("acme", job)
            requisition = store.upsert_requisition(
                "acme",
                ATSRequisitionDraft(job_id=job.job_id, priority="high", requested_headcount=2, stage_order=["Applied", "Technical", "Offer"]),
                job,
            )
            stage_state = store.advance_candidate_stage(
                "acme",
                job.job_id,
                "acme--candidate-1",
                CandidateStageDraft(stage="Technical", actor="Recruiter", notes="Strong shortlist"),
            )
            approval = store.request_approval(
                "acme",
                ApprovalDraft(job_id=job.job_id, approval_type="requisition", requested_by="Recruiter", approvers=["Manager"]),
            )
            signed = store.signoff_approval("acme", approval["approval_id"], ApprovalSignoffDraft(approver="Manager", decision="approved"))
            pipeline = store.pipeline_for_job(
                "acme",
                job.job_id,
                [
                    {
                        "rank": 1,
                        "candidate": {"candidate_id": "acme--candidate-1", "name": "Aditi Sharma"},
                        "breakdown": {"total_score": 0.91, "confidence_score": 0.88},
                    }
                ],
            )

            self.assertEqual(requisition["priority"], "high")
            self.assertEqual(stage_state["current_stage"], "Technical")
            self.assertEqual(signed["status"], "approved")
            self.assertEqual(pipeline["stage_counts"]["Technical"], 1)

    def test_auth_manager_bootstraps_existing_workspace_account(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            manager = AuthManager(root)
            record = manager.ensure_seed_company(workspace_id="iit-bhubaneswar", company_name="IIT Bhubaneswar")
            session = manager.login(company_name="IIT Bhubaneswar", password=seed_company_password("IIT Bhubaneswar"))
            claimed = manager.register_company(
                company_name="IIT Bhubaneswar",
                admin_name="Owner",
                email="owner@iitbbs.ac.in",
                password="SecureOwner123!",
            )

            self.assertEqual(record["workspace_id"], "iit-bhubaneswar")
            self.assertEqual(session.workspace_id, "iit-bhubaneswar")
            self.assertTrue(record["seeded"])
            self.assertEqual(claimed.admin_name, "Owner")

    def test_candidate_store_bootstraps_resume_accounts_and_allows_name_login(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)
            (settings.resumes_dir / "aditi_sharma_resume.txt").write_text(
                "\n".join(
                    [
                        "Aditi Sharma",
                        "Applied AI Engineer",
                        "Email: aditi@example.com",
                        "Location: Bengaluru",
                        "Skills: Python, FastAPI, Pathway, RAG",
                        "Education: B.Tech in Computer Science",
                        "Experience: Built real-time RAG systems",
                    ]
                ),
                encoding="utf-8",
            )

            store = CandidatePortalStore(settings)
            seeded = store.ensure_seed_accounts_from_resumes()
            session = store.login_candidate(identifier="Aditi Sharma", password=seed_candidate_password("Aditi Sharma"))

            self.assertEqual(len(seeded), 1)
            self.assertEqual(session.full_name, "Aditi Sharma")
            profile = store.get_profile(session.candidate_account_id)
            self.assertIsNotNone(profile)
            self.assertIn("Python", profile.get("skills", []))

    def test_candidate_store_persists_conversation_messages(self) -> None:
        with TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            settings = Settings(
                data_root=root / "data",
                resumes_dir=root / "data" / "resumes",
                jobs_dir=root / "data" / "jobs",
                feedback_dir=root / "data" / "feedback",
                catalog_dir=root / "data" / "catalog",
                staging_dir=root / "data" / "staging",
                artifacts_dir=root / "artifacts",
                cache_dir=root / "artifacts" / "cache",
                stream_root=root / "artifacts" / "stream",
                resume_stream_dir=root / "artifacts" / "stream" / "resumes",
                job_stream_dir=root / "artifacts" / "stream" / "jobs",
                generated_root=root / "artifacts" / "generated",
                generated_resume_dir=root / "artifacts" / "generated" / "resumes",
                generated_job_dir=root / "artifacts" / "generated" / "jobs",
            )
            for directory in settings.ensured_directories:
                directory.mkdir(parents=True, exist_ok=True)

            store = CandidatePortalStore(settings)
            session = store.register_candidate(
                full_name="Priya Nair",
                email="priya@example.com",
                password="StrongPass123!",
            )
            first = store.post_message(
                company_id="aurora-analytics",
                candidate_account_id=session.candidate_account_id,
                company_candidate_id="aurora-analytics--candidate-priya",
                role_id="aurora-analytics--data-scientist",
                sender_type="candidate",
                sender_name="Priya Nair",
                message="Hello, I would like to confirm whether my application is complete.",
                application_id="app-1",
            )
            second = store.post_message(
                company_id="aurora-analytics",
                candidate_account_id=session.candidate_account_id,
                company_candidate_id="aurora-analytics--candidate-priya",
                role_id="aurora-analytics--data-scientist",
                sender_type="company",
                sender_name="Aurora Hiring",
                message="Yes, your application is complete and under review.",
                application_id="app-1",
            )

            messages = store.list_messages(
                candidate_account_id=session.candidate_account_id,
                company_id="aurora-analytics",
                role_id="aurora-analytics--data-scientist",
            )

            self.assertEqual(len(messages), 2)
            self.assertEqual(messages[0]["message_id"], first["message_id"])
            self.assertEqual(messages[1]["message_id"], second["message_id"])
            self.assertEqual(messages[1]["sender_type"], "company")


if __name__ == "__main__":
    unittest.main()
