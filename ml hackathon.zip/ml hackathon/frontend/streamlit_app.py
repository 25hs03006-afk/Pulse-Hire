from __future__ import annotations

import json
import os
from textwrap import dedent
from collections import Counter
from datetime import UTC, datetime, timedelta, timezone
from html import escape
from typing import Any

import requests
import streamlit as st

try:
    from zoneinfo import ZoneInfo

    LOCAL_TZ = ZoneInfo("Asia/Kolkata")
except Exception:  # pragma: no cover
    LOCAL_TZ = timezone(timedelta(hours=5, minutes=30))

API_BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000").rstrip("/")
UPLOAD_TYPES = ["pdf", "docx", "txt", "csv"]
PAGE_SIZE = 12
FIT_ORDER = ["excellent", "strong", "promising", "partial", "weak"]
FIT_LABELS = {
    "excellent": "Excellent fit",
    "strong": "Strong fit",
    "promising": "Promising",
    "partial": "Partial fit",
    "weak": "Limited fit",
    "profile": "Profile",
}
FLASH_KEY = "flash_messages"
AUTH_KEY = "auth_session"
CANDIDATE_AUTH_KEY = "candidate_auth_session"
PORTAL_KEY = "portal_mode"
DETAIL_NOTICE_KEY = "candidate_detail_notice"
CANDIDATE_NOTICE_KEY = "candidate_portal_notice"
SECTION_NOTICE_PREFIX = "candidate_section_notice_"
REVIEW_OPTIONS = {
    "Strong yes": "strong_yes",
    "Interview recommended": "interview_recommended",
    "Shortlist": "shortlist",
    "Hold": "hold",
    "Neutral": "neutral",
    "Reject": "reject",
}
VIEW_META = {
    "About": {
        "tone": "details",
        "tag": "Platform guide",
        "title": "About PulseHire",
    },
    "Candidates": {
        "tone": "candidates",
        "tag": "Candidate directory",
        "title": "Candidate intake",
    },
    "Candidate details": {
        "tone": "details",
        "tag": "Candidate review",
        "title": "Candidate details",
    },
    "Roles": {
        "tone": "roles",
        "tag": "Role setup",
        "title": "Hiring roles",
    },
    "Shortlist": {
        "tone": "shortlist",
        "tag": "Decision support",
        "title": "Shortlist",
    },
    "Reviews": {
        "tone": "reviews",
        "tag": "Hiring reviews",
        "title": "Reviews",
    },
    "Analytics": {
        "tone": "roles",
        "tag": "Hiring analytics",
        "title": "Analytics",
    },
}
ROLE_TEMPLATES = {
    "Real-Time RAG Engineer": {
        "title": "Real-Time RAG Engineer",
        "team": "AI Platform",
        "location": "Bengaluru / Remote",
        "employment_type": "Full-time",
        "description": "Own the streaming retrieval stack for recruiter-facing AI products, from live ingestion to grounded ranking and decision support.",
        "must_have_skills": ["Python", "Pathway", "RAG", "FastAPI", "Docker"],
        "nice_to_have_skills": ["Kubernetes", "AWS", "Vector Search"],
        "responsibilities": ["Build live ingestion pipelines", "Maintain ranking quality", "Improve retrieval grounding"],
        "hiring_target": 2,
        "min_years_experience": 4.0,
        "education_requirement": "Bachelors",
    },
    "Applied AI Engineer": {
        "title": "Applied AI Engineer",
        "team": "Product Engineering",
        "location": "Hyderabad",
        "employment_type": "Full-time",
        "description": "Build production AI features with strong model orchestration, evaluation discipline, and product empathy.",
        "must_have_skills": ["Python", "LLMs", "Prompt Engineering", "APIs", "Evaluation"],
        "nice_to_have_skills": ["RAG", "LangChain", "Experimentation"],
        "responsibilities": ["Ship AI product features", "Measure model quality", "Partner with product managers"],
        "hiring_target": 3,
        "min_years_experience": 3.0,
        "education_requirement": "Bachelors",
    },
    "ML Platform Engineer": {
        "title": "ML Platform Engineer",
        "team": "Infrastructure",
        "location": "Pune",
        "employment_type": "Full-time",
        "description": "Scale ML systems with reliable deployment, observability, feature pipelines, and model operations.",
        "must_have_skills": ["Python", "MLOps", "Docker", "Kubernetes", "CI/CD"],
        "nice_to_have_skills": ["Terraform", "AWS", "Feature Stores"],
        "responsibilities": ["Maintain model delivery workflows", "Improve infra reliability", "Standardize deployment tooling"],
        "hiring_target": 2,
        "min_years_experience": 4.0,
        "education_requirement": "Bachelors",
    },
    "Data Scientist": {
        "title": "Data Scientist",
        "team": "Decision Science",
        "location": "Remote",
        "employment_type": "Full-time",
        "description": "Turn product and hiring data into models, experiments, and decision frameworks that improve outcomes.",
        "must_have_skills": ["Python", "SQL", "Machine Learning", "Statistics", "Experimentation"],
        "nice_to_have_skills": ["NLP", "Pandas", "Scikit-learn"],
        "responsibilities": ["Build predictive models", "Run experiments", "Present insights to stakeholders"],
        "hiring_target": 2,
        "min_years_experience": 3.0,
        "education_requirement": "Masters",
    },
    "Product Manager": {
        "title": "Product Manager",
        "team": "Core Product",
        "location": "Mumbai",
        "employment_type": "Full-time",
        "description": "Lead roadmap decisions for data and AI workflows with clear prioritization, stakeholder alignment, and execution rigor.",
        "must_have_skills": ["Product Strategy", "Stakeholder Management", "Roadmapping", "Analytics"],
        "nice_to_have_skills": ["AI Products", "Experimentation", "B2B SaaS"],
        "responsibilities": ["Own roadmap", "Drive discovery", "Translate customer feedback into execution"],
        "hiring_target": 1,
        "min_years_experience": 5.0,
        "education_requirement": "Bachelors",
    },
    "UX Designer": {
        "title": "UX Designer",
        "team": "Design",
        "location": "Bengaluru",
        "employment_type": "Full-time",
        "description": "Design operational workflows for recruiter teams with strong information architecture, interaction design, and visual clarity.",
        "must_have_skills": ["Figma", "UX Research", "Interaction Design", "Design Systems"],
        "nice_to_have_skills": ["B2B SaaS", "Prototyping", "Accessibility"],
        "responsibilities": ["Design recruiter journeys", "Prototype decision flows", "Improve system usability"],
        "hiring_target": 1,
        "min_years_experience": 3.0,
        "education_requirement": "Bachelors",
    },
}


class APIRequestError(RuntimeError):
    pass


def request(method: str, path: str, *, auth_key: str = AUTH_KEY, **kwargs: Any) -> Any:
    headers = dict(kwargs.pop("headers", {}) or {})
    auth_session = st.session_state.get(auth_key, {})
    token = text(auth_session.get("token"))
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if headers:
        kwargs["headers"] = headers
    try:
        response = requests.request(method, f"{API_BASE_URL}{path}", timeout=60, **kwargs)
    except requests.RequestException as exc:
        raise APIRequestError("The hiring service is temporarily unavailable.") from exc
    if not response.ok:
        try:
            payload = response.json()
        except ValueError:
            payload = {}
        detail = payload.get("detail") if isinstance(payload, dict) else None
        raise APIRequestError(str(detail or response.text or "The request could not be completed."))
    try:
        return response.json()
    except ValueError as exc:
        raise APIRequestError("The hiring service returned an unexpected response.") from exc


def api_get(path: str) -> Any:
    return request("GET", path)


def api_post(path: str, *, json_payload: dict[str, Any] | None = None, files: list[tuple[str, tuple[str, bytes, str]]] | None = None) -> Any:
    kwargs: dict[str, Any] = {}
    if json_payload is not None:
        kwargs["json"] = json_payload
    if files is not None:
        kwargs["files"] = files
    return request("POST", path, **kwargs)


def api_delete(path: str) -> Any:
    return request("DELETE", path)


def candidate_api_get(path: str) -> Any:
    return request("GET", path, auth_key=CANDIDATE_AUTH_KEY)


def candidate_api_post(path: str, *, json_payload: dict[str, Any] | None = None, files: list[tuple[str, tuple[str, bytes, str]]] | None = None, data: dict[str, Any] | None = None) -> Any:
    kwargs: dict[str, Any] = {}
    if json_payload is not None:
        kwargs["json"] = json_payload
    if files is not None:
        kwargs["files"] = files
    if data is not None:
        kwargs["data"] = data
    return request("POST", path, auth_key=CANDIDATE_AUTH_KEY, **kwargs)


def candidate_api_delete(path: str) -> Any:
    return request("DELETE", path, auth_key=CANDIDATE_AUTH_KEY)


def push_flash(level: str, message: str) -> None:
    st.session_state.setdefault(FLASH_KEY, []).append((level, message))


def show_flash_messages() -> None:
    for level, message in st.session_state.pop(FLASH_KEY, []):
        if level == "success":
            st.success(message)
        elif level == "warning":
            st.warning(message)
        elif level == "error":
            st.error(message)
        else:
            st.info(message)


def clear_shortlist_answer() -> None:
    st.session_state.pop("answer_payload", None)
    st.session_state.pop("answer_question", None)
    st.session_state.pop("answer_job_id", None)


def set_detail_notice(level: str, message: str, candidate_id: str) -> None:
    st.session_state[DETAIL_NOTICE_KEY] = {
        "level": level,
        "message": message,
        "candidate_id": candidate_id,
    }


def show_detail_notice(candidate_id: str) -> None:
    notice = st.session_state.get(DETAIL_NOTICE_KEY)
    if not notice or notice.get("candidate_id") != candidate_id:
        return
    level = text(notice.get("level"), "info")
    message = text(notice.get("message"))
    if level == "success":
        st.success(message)
    elif level == "warning":
        st.warning(message)
    elif level == "error":
        st.error(message)
    else:
        st.info(message)


def set_candidate_notice(level: str, message: str) -> None:
    st.session_state[CANDIDATE_NOTICE_KEY] = {"level": level, "message": message}


def show_candidate_notice() -> None:
    notice = st.session_state.pop(CANDIDATE_NOTICE_KEY, None)
    if not notice:
        return
    level = text(notice.get("level"), "info")
    message = text(notice.get("message"))
    if level == "success":
        st.success(message)
    elif level == "warning":
        st.warning(message)
    elif level == "error":
        st.error(message)
    else:
        st.info(message)


def set_section_notice(section: str, level: str, message: str) -> None:
    st.session_state[f"{SECTION_NOTICE_PREFIX}{section}"] = {"level": level, "message": message}


def clear_section_notice(section: str) -> None:
    st.session_state.pop(f"{SECTION_NOTICE_PREFIX}{section}", None)


def show_section_notice(section: str, *, clear: bool = False) -> None:
    key = f"{SECTION_NOTICE_PREFIX}{section}"
    notice = st.session_state.pop(key, None) if clear else st.session_state.get(key)
    if not notice:
        return
    level = text(notice.get("level"), "info")
    message = text(notice.get("message"))
    if level == "success":
        st.success(message)
    elif level == "warning":
        st.warning(message)
    elif level == "error":
        st.error(message)
    else:
        st.info(message)


def text(value: Any, fallback: str = "") -> str:
    if value is None:
        return fallback
    if isinstance(value, str):
        value = value.strip()
        return value or fallback
    return str(value)


def items(values: list[Any] | None) -> list[str]:
    return [text(value) for value in (values or []) if text(value)]


def split_csv(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def split_lines(value: str) -> list[str]:
    return [item.strip() for item in value.splitlines() if item.strip()]


def pct(value: float | None) -> int:
    return max(0, min(100, int(round(float(value or 0.0) * 100))))


def parse_stamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def clock(value: str | None) -> str:
    stamp = parse_stamp(value)
    return stamp.astimezone(LOCAL_TZ).strftime("%I:%M %p") if stamp else "--:--"


def full_time(value: str | None) -> str:
    stamp = parse_stamp(value)
    return stamp.astimezone(LOCAL_TZ).strftime("%d %b %Y | %I:%M %p") if stamp else "Unknown"


def ago(value: str | None) -> str:
    stamp = parse_stamp(value)
    if not stamp:
        return "Unknown"
    delta = max(int((datetime.now(UTC) - stamp.astimezone(UTC)).total_seconds()), 0)
    if delta < 60:
        return f"{delta}s ago"
    if delta < 3600:
        return f"{delta // 60}m ago"
    if delta < 86400:
        return f"{delta // 3600}h ago"
    return f"{delta // 86400}d ago"


def chips(values: list[str], tone: str, empty_text: str) -> str:
    labels = values[:4] or [empty_text]
    return "".join(f"<span class='chip {tone}'>{escape(label)}</span>" for label in labels)


def role_priority(role: dict[str, Any]) -> tuple[Any, ...]:
    verification_status = text(role.get("verification_status"), "pending").lower()
    recruiter_notes = items(role.get("recruiter_notes"))
    feedback_notes = [text(entry.get("notes")) for entry in (role.get("feedback") or []) if text(entry.get("notes"))]
    return (
        0 if verification_status == "verified" else 1,
        0 if role.get("score_visible") else 1,
        -(len(recruiter_notes) + len(feedback_notes)),
        -float(role.get("match_score") or 0.0),
        int(role.get("rank") or 9999),
        text(role.get("title")).lower(),
    )


def preferred_role_id(roles: list[dict[str, Any]], current_role_id: str | None = None) -> str | None:
    role_ids = [text(role.get("job_id")) for role in roles if text(role.get("job_id"))]
    if current_role_id and current_role_id in role_ids:
        return current_role_id
    if not roles:
        return None
    best = min(roles, key=role_priority)
    return text(best.get("job_id")) or role_ids[0]


def application_priority(application: dict[str, Any]) -> tuple[Any, ...]:
    roles = application.get("roles") or []
    best_role = min(roles, key=role_priority) if roles else {}
    updated = parse_stamp(text(application.get("updated_at")))
    updated_ts = updated.timestamp() if updated else 0.0
    return (*role_priority(best_role), -updated_ts, text(application.get("company", {}).get("company_name")).lower())


def preferred_company_id(companies: list[dict[str, Any]], applications: list[dict[str, Any]], current_company_id: str | None = None) -> str | None:
    ordered_company_ids = [text(company.get("workspace_id")) for company in companies if text(company.get("workspace_id"))]
    valid_company_ids = set(ordered_company_ids)
    if current_company_id and current_company_id in valid_company_ids:
        return current_company_id
    if applications:
        ranked = sorted(
            [application for application in applications if text(application.get("company", {}).get("workspace_id")) in valid_company_ids],
            key=application_priority,
        )
        if ranked:
            return text(ranked[0].get("company", {}).get("workspace_id"))
    return ordered_company_ids[0] if ordered_company_ids else None


def html_block(value: str) -> str:
    return dedent(value).strip()


def source_label(entity: dict[str, Any]) -> str:
    mode = text(entity.get("source_mode"), "dataset")
    if mode == "manual_override":
        return "Updated profile"
    if mode in {"synthetic", "starter"}:
        return "Starter profile"
    if mode == "dataset":
        return "Resume file"
    return "Live intake"


def candidate_focus_label(candidate: dict[str, Any], ranking: dict[str, Any] | None) -> str:
    parts = [text(candidate.get("name"), "Candidate")]
    if ranking:
        parts.append(f"Rank #{ranking.get('rank')}")
    title = text(candidate.get("current_title"))
    if title:
        parts.append(title)
    return " | ".join(parts)


def candidate_card(candidate: dict[str, Any], ranking: dict[str, Any] | None, active_role: bool) -> str:
    updated = False
    stamp = parse_stamp(candidate.get("last_updated"))
    if stamp:
        updated = (datetime.now(UTC) - stamp.astimezone(UTC)).total_seconds() <= 240
    if ranking and (ranking.get("rank_delta") or abs(float(ranking.get("score_delta", 0.0))) >= 0.01):
        updated = True
    score = pct(ranking.get("breakdown", {}).get("total_score", 0.0)) if ranking else pct(candidate.get("completeness_score", 0.0))
    confidence = pct(ranking.get("breakdown", {}).get("confidence_score", 0.0)) if ranking else pct(candidate.get("completeness_score", 0.0))
    stability = pct(ranking.get("breakdown", {}).get("stability_score", 0.0)) if ranking else 0
    label = "Match score" if ranking and active_role else "Profile completeness"
    fit = text(ranking.get("fit_band") if ranking else "profile", "profile")
    return html_block(
        f"""
        <section class='card {"updated" if updated else ""}'>
          <div class='card-top'>
            <div>
              <div class='eyebrow'>Candidate {f"<span class='pill'>Updated</span>" if updated else ""}</div>
              <div class='card-title'>{escape(text(candidate.get("name"), "Candidate"))}</div>
              <div class='muted'>{escape(text(candidate.get("current_title"), "Candidate profile"))}</div>
              <div class='muted'>{escape(text(candidate.get("location"), "Location flexible"))} | {candidate.get("years_experience", 0.0):.1f} years | {escape(ago(candidate.get("last_updated")))} | {escape(source_label(candidate))}</div>
            </div>
            <div class='score-box'>
              <div class='fit'>{escape(FIT_LABELS.get(fit, fit.title()))}</div>
              <div class='score'>{score}</div>
              <div class='muted small'>{escape(label)}</div>
            </div>
          </div>
          <div class='bar'><div class='fill' style='width:{max(score, 5)}%'></div></div>
          <div class='mini-stats'>
            <span><strong>{confidence}%</strong> confidence</span>
            <span><strong>{stability}%</strong> stability</span>
          </div>
          <div class='section'>Top strengths</div>
          <div>{chips(items(ranking.get("strengths")) if ranking else items(candidate.get("skills")), "good", "Strengths appear once a role is selected")}</div>
          <div class='section'>Missing skills</div>
          <div>{chips(items(ranking.get("breakdown", {}).get("missing_must_have_skills")) if ranking else [], "risk", "No critical gaps identified")}</div>
          <div class='section'>Why this candidate is here</div>
          <div class='body'>{escape(text(ranking.get("explanation") if ranking else candidate.get("summary"), "Profile uploaded successfully."))}</div>
        </section>
        """
    )


def candidate_identity_key(candidate: dict[str, Any]) -> str:
    email = text(candidate.get("email")).lower()
    if email:
        return f"email:{email}"
    phone = text(candidate.get("phone")).lower()
    name = text(candidate.get("name")).lower()
    location = text(candidate.get("location")).lower()
    return f"profile:{name}|{phone or location}"


def dedupe_candidates(candidates: list[dict[str, Any]], ranking_lookup: dict[str, dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    ranking_lookup = ranking_lookup or {}
    chosen: dict[str, dict[str, Any]] = {}
    for candidate in candidates:
        key = candidate_identity_key(candidate)
        current = chosen.get(key)
        if not current:
            chosen[key] = candidate
            continue
        current_rank = ranking_lookup.get(current.get("candidate_id", ""), {}).get("rank", 999)
        new_rank = ranking_lookup.get(candidate.get("candidate_id", ""), {}).get("rank", 999)
        if new_rank < current_rank:
            chosen[key] = candidate
            continue
        current_stamp = parse_stamp(current.get("last_updated")) or datetime.min.replace(tzinfo=UTC)
        new_stamp = parse_stamp(candidate.get("last_updated")) or datetime.min.replace(tzinfo=UTC)
        if new_rank == current_rank and new_stamp > current_stamp:
            chosen[key] = candidate
    return list(chosen.values())


def fit_matrix(job: dict[str, Any], rankings: list[dict[str, Any]]) -> str:
    skills = items(job.get("must_have_skills"))
    if not skills or not rankings:
        return "<div class='box'><div class='box-title'>Skill coverage</div><div class='muted'>Add a role and candidate matches to compare core requirements.</div></div>"
    headers = "".join(f"<th>{escape(skill)}</th>" for skill in skills[:6])
    rows = []
    for ranking in rankings[:5]:
        candidate = ranking["candidate"]
        skill_set = {skill.lower() for skill in items(candidate.get("skills"))}
        cells = "".join(
            f"<td><span class='mini {'yes' if skill.lower() in skill_set else 'no'}'>{'Covered' if skill.lower() in skill_set else 'Gap'}</span></td>"
            for skill in skills[:6]
        )
        rows.append(f"<tr><td>{escape(candidate['name'])}</td><td>{pct(ranking['breakdown']['total_score'])}%</td>{cells}</tr>")
    return (
        "<div class='box'><div class='box-title'>Skill coverage</div><div class='muted'>A quick comparison of how the current shortlist covers the role's must-have skills.</div>"
        "<div class='table-wrap'><table><thead><tr><th>Candidate</th><th>Score</th>"
        + headers
        + "</tr></thead><tbody>"
        + "".join(rows)
        + "</tbody></table></div></div>"
    )


def skill_family_coverage(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "<div class='box'><div class='box-title'>Role skill coverage</div><div class='muted'>Coverage appears here once a role has grouped requirements and matched candidates.</div></div>"
    tiles = []
    for row in rows[:8]:
        ratio = pct(row.get("coverage_ratio"))
        tone = "high" if ratio >= 75 else "medium" if ratio >= 40 else "low"
        covered_by = items(row.get("covered_candidates"))
        skills = items(row.get("skills"))
        skill_rows = row.get("skill_rows") or []
        detail_rows = "".join(
            html_block(
                f"""
                <div class='skill-row'>
                  <div class='skill-row-head'>
                    <span>{escape(text(skill_row.get("skill"), "Skill"))}</span>
                    <span>{pct(skill_row.get("coverage_ratio"))}%</span>
                  </div>
                  <div class='tiny-bar'><div class='tiny-fill' style='width:{max(pct(skill_row.get("coverage_ratio")), 4)}%'></div></div>
                  <div class='muted small'>{escape(", ".join(items(skill_row.get("covered_candidates"))[:3]) or "No shortlist coverage yet")}</div>
                </div>
                """
            )
            for skill_row in skill_rows[:6]
        )
        tiles.append(
            html_block(
                f"""
                <div class='family-card {tone}'>
                  <div class='family-head'>
                    <div>
                      <div class='eyebrow'>Skill family</div>
                      <div class='box-title'>{escape(text(row.get("group"), "Coverage area"))}</div>
                    </div>
                    <div class='coverage-pill'>{ratio}%</div>
                  </div>
                  <div class='bar'><div class='fill' style='width:{max(ratio, 6)}%'></div></div>
                  <div class='muted small'>{escape(", ".join(skills[:6]) or "Grouped capability coverage")}</div>
                  <div style='margin-top:.8rem'>{chips(covered_by[:4], "good", "No shortlist coverage yet")}</div>
                  <div class='skill-stack'>{detail_rows}</div>
                </div>
                """
            )
        )
    return html_block("<div class='box'><div class='box-title'>Role skill coverage</div><div class='family-grid'>" + "".join(tiles) + "</div></div>")


def render_feature_banner(view_name: str) -> None:
    meta = VIEW_META[view_name]
    st.markdown(
        f"""
        <section class='feature-hero {meta['tone']}'>
          <div class='accent-tag'>{escape(meta['tag'])}</div>
          <div class='feature-title'>{escape(meta['title'])}</div>
        </section>
        """,
        unsafe_allow_html=True,
    )


def render_portal_selection() -> None:
    st.markdown(
        """
        <div class='auth-shell'>
          <div class='auth-hero'>
            <div class='eyebrow' style='color:#dbeafe'>PulseHire</div>
            <div class='hero-title' style='color:#fff'>Choose your workspace</div>
            <div style='opacity:.92; line-height:1.7'>PulseHire supports a dedicated candidate journey and a separate recruiter workspace. Select the experience you want to enter.</div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    left, right = st.columns(2)
    with left:
        st.markdown("<div class='auth-card'><div class='box-title'>I am a Candidate</div><div class='muted'>Apply to companies, submit documents, build or upload a resume, and track recruiter feedback for each role.</div></div>", unsafe_allow_html=True)
        if st.button("Open Candidate Portal", use_container_width=True, key="open_candidate_portal"):
            st.session_state[PORTAL_KEY] = "candidate"
            st.rerun()
    with right:
        st.markdown("<div class='auth-card'><div class='box-title'>I am a Company</div><div class='muted'>Review candidates, manage roles, verify documents, compare applicants, and adapt rankings in real time.</div></div>", unsafe_allow_html=True)
        if st.button("Open Company Portal", use_container_width=True, key="open_company_portal"):
            st.session_state[PORTAL_KEY] = "company"
            st.rerun()


def candidate_status_label(value: str | None) -> str:
    label = text(value, "under_review").replace("_", " ").title()
    return label if label else "Under Review"


def render_candidate_portal() -> None:
    candidate_session = st.session_state.get(CANDIDATE_AUTH_KEY)
    if candidate_session:
        try:
            candidate_session = candidate_api_get("/candidate/auth/me")
            st.session_state[CANDIDATE_AUTH_KEY] = candidate_session
        except APIRequestError:
            st.session_state.pop(CANDIDATE_AUTH_KEY, None)
            candidate_session = None

    if not candidate_session:
        st.markdown(
            """
            <div class='auth-shell'>
              <div class='auth-hero'>
                <div class='eyebrow' style='color:#dbeafe'>Candidate Portal</div>
                <div class='hero-title' style='color:#fff'>Apply with verified credentials</div>
                <div style='opacity:.92; line-height:1.7'>Build a trusted candidate profile, attach proof documents, apply to multiple roles in one company, and track recruiter decisions in one place.</div>
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        left, right = st.columns(2)
        with left:
            st.markdown("<div class='auth-card'><div class='box-title'>Candidate login</div><div class='muted'>Sign in with your email or full name to continue with your saved profile and applications.</div></div>", unsafe_allow_html=True)
            with st.form("candidate_signin_form"):
                email = st.text_input("Email or full name", key="candidate_signin_email")
                password = st.text_input("Password", type="password", key="candidate_signin_password")
                submit = st.form_submit_button("Sign in", use_container_width=True)
            if submit:
                try:
                    st.session_state[CANDIDATE_AUTH_KEY] = candidate_api_post(
                        "/candidate/auth/login",
                        json_payload={"email": email, "password": password},
                    )
                    st.rerun()
                except APIRequestError as exc:
                    st.error(str(exc))
        with right:
            st.markdown("<div class='auth-card'><div class='box-title'>Create candidate account</div><div class='muted'>Start a separate candidate workspace for applications and feedback tracking.</div></div>", unsafe_allow_html=True)
        with st.form("candidate_signup_form"):
            full_name = st.text_input("Full name", key="candidate_signup_name")
            email = st.text_input("Email", key="candidate_signup_email")
            password = st.text_input("Password", type="password", key="candidate_signup_password")
            submit = st.form_submit_button("Create account", use_container_width=True)
            if submit:
                try:
                    st.session_state[CANDIDATE_AUTH_KEY] = candidate_api_post(
                        "/candidate/auth/register",
                        json_payload={"full_name": full_name, "email": email, "password": password},
                    )
                    st.rerun()
                except APIRequestError as exc:
                    st.error(str(exc))
        if st.button("Back to portal selection", use_container_width=True, key="candidate_back_to_selection"):
            st.session_state.pop(CANDIDATE_AUTH_KEY, None)
            st.session_state.pop(PORTAL_KEY, None)
            st.rerun()
        return

    try:
        companies = candidate_api_get("/candidate/companies")
        profile_payload = candidate_api_get("/candidate/profile")
        applications = candidate_api_get("/candidate/applications")
        candidate_documents = candidate_api_get("/candidate/documents")
    except APIRequestError as exc:
        st.error(str(exc))
        return

    profile_data = profile_payload.get("profile") or {}
    profile_notifications = profile_payload.get("notifications") or []
    profile_timeline = profile_payload.get("timeline") or []
    candidate_views = ["About", "Application", "Dashboard", "Feedback", "Messages"]
    selected_company_id = st.session_state.get("candidate_selected_company_id")
    company_labels = {
        f"{company['company_name']} ({company.get('roles_count', 0)} open role{'s' if company.get('roles_count', 0) != 1 else ''})": company["workspace_id"]
        for company in companies
    }
    label_list = list(company_labels.keys())
    selected_company_id = preferred_company_id(companies, applications, selected_company_id)
    if selected_company_id:
        st.session_state["candidate_selected_company_id"] = selected_company_id

    with st.sidebar:
        st.markdown(
            f"<div class='brand'><div class='box-title' style='color:#fff'>PulseHire Candidate</div><div style='opacity:.88'>{escape(text(candidate_session.get('full_name')))}</div><div style='opacity:.72; margin-top:.3rem'>{escape(text(candidate_session.get('email')))}</div></div>",
            unsafe_allow_html=True,
        )
        candidate_view = st.radio("Sections", candidate_views, key="candidate_workspace_view")
        if label_list:
            selected_label = st.selectbox(
                "Company",
                label_list,
                index=next((index for index, label in enumerate(label_list) if company_labels[label] == selected_company_id), 0),
            )
            selected_company_id = company_labels[selected_label]
            st.session_state["candidate_selected_company_id"] = selected_company_id
        if st.button("Switch portal", use_container_width=True, key="candidate_switch_portal"):
            st.session_state.pop(CANDIDATE_AUTH_KEY, None)
            st.session_state.pop(PORTAL_KEY, None)
            st.rerun()
        if st.button("Sign out", use_container_width=True, key="candidate_signout"):
            try:
                candidate_api_post("/candidate/auth/logout")
            except APIRequestError:
                pass
            st.session_state.pop(CANDIDATE_AUTH_KEY, None)
            st.rerun()

    selected_company = next((company for company in companies if company["workspace_id"] == selected_company_id), None)
    available_roles = selected_company.get("roles", []) if selected_company else []
    current_application = next((application for application in applications if application.get("company", {}).get("workspace_id") == selected_company_id), None)
    existing_docs = [document for document in candidate_documents if document.get("company_id") == selected_company_id]
    verification_docs = [
        document
        for document in existing_docs
        if document.get("document_type") in {"profile_photo", "skill_certificate", "education_certificate", "supporting_document"}
    ]
    resume_docs = [document for document in existing_docs if document.get("document_type") == "resume"]

    st.markdown(
        f"<div class='topline'><div><div class='box-title'>Candidate workspace</div><div class='subtle'>{escape(text(candidate_session.get('full_name')))}</div></div><div class='subtle'>{escape(text(selected_company.get('company_name') if selected_company else None, 'Choose a company'))}</div></div>",
        unsafe_allow_html=True,
    )

    if candidate_view == "About":
        st.markdown(
            "<div class='box'><div class='box-title'>How PulseHire helps candidates</div><div class='body' style='margin-top:.55rem'>PulseHire gives candidates a transparent application workflow. You can apply to multiple roles inside one company, attach proof documents for your claims, choose between uploading a resume or building one from structured sections, and then track recruiter feedback, match quality, and verification outcomes in one dashboard.</div></div>",
            unsafe_allow_html=True,
        )
        st.markdown(
            "<div class='section-grid'>"
            "<div class='metric'><div class='eyebrow'>AI evaluation</div><div class='body'>Your resume is parsed into structured skills, experience, education, and project evidence before match scores are calculated for each selected role.</div></div>"
            "<div class='metric'><div class='eyebrow'>Skill validation</div><div class='body'>Certificates and proof documents are linked to the skills or qualifications they verify, helping recruiters trust the evidence behind your profile.</div></div>"
            "<div class='metric'><div class='eyebrow'>Transparent feedback</div><div class='body'>Recruiter notes, status changes, verification outcomes, and role-by-role match scores are visible back to you once they are created.</div></div>"
            "</div>",
            unsafe_allow_html=True,
        )
        st.markdown(
            "<div class='box'><div class='box-title'>How the workflow works</div><ul class='bullet-list'>"
            "<li>Select a company and one or more open roles.</li>"
            "<li>Upload a profile photo, then attach your resume or build a structured profile.</li>"
            "<li>Add supporting proof documents for skills, education, and certifications.</li>"
            "<li>Submit once, then track role-wise feedback, verification status, and hiring progress.</li>"
            "</ul></div>",
            unsafe_allow_html=True,
        )
        return

    if candidate_view == "Application":
        st.markdown("<div class='box'><div class='box-title'>Company and roles</div></div>", unsafe_allow_html=True)
        if not selected_company:
            st.info("No company workspaces are available yet. Ask the recruiter to create a company workspace first.")
            return
        selected_role_ids = st.multiselect(
            "Choose role(s)",
            options=[role["job_id"] for role in available_roles],
            default=st.session_state.get("candidate_selected_roles", []),
            format_func=lambda role_id: next((role["title"] for role in available_roles if role["job_id"] == role_id), role_id),
            key="candidate_selected_roles",
        )
        if available_roles:
            st.markdown(
                "<div class='box'><div class='box-title'>Open roles</div><div class='body' style='margin-top:.55rem'>"
                + "".join(
                    f"<p><strong>{escape(role['title'])}</strong> | {escape(text(role.get('team'), 'Team'))}<br>{escape(', '.join(items(role.get('must_have_skills'))) or 'Skills to be defined')}</p>"
                    for role in available_roles[:6]
                )
                + "</div></div>",
                unsafe_allow_html=True,
            )
        st.markdown(
            "<div class='box'><div class='box-title'>1. Upload photo</div><div class='muted'>Attach a clear profile photo for identity verification inside this company workspace.</div></div>",
            unsafe_allow_html=True,
        )
        doc_col, list_col = st.columns([0.95, 1.05])
        with doc_col:
            st.markdown("<div class='box'><div class='box-title'>Profile photo</div><div class='muted'>Upload a clear headshot to attach to your application.</div></div>", unsafe_allow_html=True)
            with st.form("candidate_photo_upload"):
                photo_title = st.text_input("Photo title", value="Profile photo")
                photo_file = st.file_uploader(
                    "Photo",
                    type=["png", "jpg", "jpeg"],
                    key="candidate_photo_file",
                )
                upload_photo = st.form_submit_button("Upload photo", use_container_width=True)
            if upload_photo:
                if not selected_role_ids:
                    set_section_notice("photo", "error", "Choose at least one role before uploading your photo.")
                elif not photo_file:
                    set_section_notice("photo", "error", "Choose a profile photo first.")
                else:
                    try:
                        candidate_api_post(
                            "/candidate/documents",
                            data={
                                "company_id": selected_company_id,
                                "role_ids": json.dumps(selected_role_ids),
                                "document_type": "profile_photo",
                                "title": photo_title,
                                "tags": "",
                            },
                            files=[("file", (photo_file.name, photo_file.getvalue(), photo_file.type or "application/octet-stream"))],
                        )
                        set_section_notice("photo", "success", "Profile photo uploaded.")
                    except APIRequestError as exc:
                        set_section_notice("photo", "error", str(exc))
                    st.rerun()
            show_section_notice("photo", clear=True)

        with list_col:
            profile_photos = [document for document in existing_docs if document.get("document_type") == "profile_photo"]
            support_docs = [document for document in existing_docs if document.get("document_type") in {"skill_certificate", "education_certificate", "supporting_document"}]
            if profile_photos:
                st.markdown("<div class='box'><div class='box-title'>Uploaded photo</div></div>", unsafe_allow_html=True)
                latest_photo = profile_photos[0]
                st.markdown(
                    f"<div class='review'><strong>{escape(text(latest_photo.get('title'), latest_photo.get('file_name')))}</strong><br><span class='muted'>{escape(full_time(latest_photo.get('uploaded_at')))}</span></div>",
                    unsafe_allow_html=True,
                )
            else:
                st.info("Upload a profile photo for a complete registration.")

        st.markdown("<div class='box'><div class='box-title'>2. Resume submission</div><div class='muted'>Upload your resume or build a structured profile. Your application will be sent in the final step below.</div></div>", unsafe_allow_html=True)
        resume_mode_label = st.radio("Resume option", ["Upload resume", "Build resume"], horizontal=True, key="candidate_resume_mode_label")
        if resume_mode_label == "Upload resume":
            st.markdown("<div class='box'><div class='box-title'>Upload resume</div><div class='muted'>Upload your latest resume in PDF, DOCX, TXT, or CSV format.</div></div>", unsafe_allow_html=True)
            resume_file = st.file_uploader("Resume", type=["pdf", "docx", "txt", "csv"], key="candidate_resume_file")
            if st.button("Add resume", use_container_width=True, key="candidate_resume_upload_button"):
                if not selected_role_ids:
                    set_section_notice("resume", "error", "Choose at least one role before uploading your resume.")
                elif not resume_file:
                    set_section_notice("resume", "error", "Choose a resume file first.")
                else:
                    try:
                        candidate_api_post(
                            "/candidate/documents",
                            data={
                                "company_id": selected_company_id,
                                "role_ids": json.dumps(selected_role_ids),
                                "document_type": "resume",
                                "title": resume_file.name,
                                "tags": "",
                            },
                            files=[("file", (resume_file.name, resume_file.getvalue(), resume_file.type or "application/octet-stream"))],
                        )
                        set_section_notice("resume", "success", "Resume uploaded.")
                    except APIRequestError as exc:
                        set_section_notice("resume", "error", str(exc))
                    st.rerun()
            show_section_notice("resume", clear=True)
            latest_resume = resume_docs[0] if resume_docs else None
            if latest_resume:
                st.markdown(
                    f"<div class='review'><strong>{escape(text(latest_resume.get('title'), latest_resume.get('file_name')))}</strong><br><span class='muted'>Latest uploaded resume</span></div>",
                    unsafe_allow_html=True,
                )
            else:
                st.info("Add a resume here if you want to submit an uploaded file instead of the structured profile.")
        else:
            st.markdown("<div class='box'><div class='box-title'>Build your profile</div><div class='muted'>Fill each section below to create a structured resume directly in the portal.</div></div>", unsafe_allow_html=True)
            with st.form("candidate_builder_form"):
                st.markdown("**Personal details**")
                full_name = st.text_input("Full name", value=text(profile_data.get("full_name"), text(candidate_session.get("full_name"))), key="candidate_builder_full_name")
                email = st.text_input("Email", value=text(profile_data.get("email"), text(candidate_session.get("email"))), key="candidate_builder_email")
                phone = st.text_input("Phone", value=text(profile_data.get("phone")), key="candidate_builder_phone")
                location = st.text_input("Location", value=text(profile_data.get("location")), key="candidate_builder_location")
                headline = st.text_input("Professional headline", value=text(profile_data.get("headline")), key="candidate_builder_headline")
                summary = st.text_area("Professional summary", value=text(profile_data.get("summary")), height=120, key="candidate_builder_summary")
                st.markdown("**Skills**")
                skills = st.text_area("Skills", value=", ".join(items(profile_data.get("skills"))), height=90, placeholder="Python, FastAPI, Pathway, SQL", key="candidate_builder_skills")
                st.markdown("**Education**")
                education = st.text_area("Education", value="\n".join(
                    " | ".join(filter(None, [entry.get("degree"), entry.get("field"), entry.get("institution"), entry.get("start_year"), entry.get("end_year")]))
                    for entry in (profile_data.get("education") or [])
                ), height=110, placeholder="Degree | Field | Institution | Start year | End year", key="candidate_builder_education")
                st.markdown("**Experience**")
                experience = st.text_area("Experience", value="\n".join(
                    " | ".join(filter(None, [entry.get("title"), entry.get("company"), entry.get("start_date"), entry.get("end_date"), ", ".join(entry.get("highlights", []))]))
                    for entry in (profile_data.get("experience") or [])
                ), height=140, placeholder="Title | Company | Start date | End date | Highlight one, Highlight two", key="candidate_builder_experience")
                st.markdown("**Projects**")
                projects = st.text_area("Projects", value="\n".join(
                    " | ".join(filter(None, [entry.get("name"), entry.get("description"), ", ".join(entry.get("technologies", []))]))
                    for entry in (profile_data.get("projects") or [])
                ), height=120, placeholder="Project name | Description | Python, FastAPI", key="candidate_builder_projects")
                st.markdown("**Certifications**")
                certifications = st.text_area("Certifications", value="\n".join(
                    " | ".join(filter(None, [entry.get("name"), entry.get("issuer"), entry.get("issued_on")]))
                    for entry in (profile_data.get("certifications") or [])
                ), height=110, placeholder="Certification | Issuer | Date", key="candidate_builder_certifications")
                save_builder = st.form_submit_button("Save profile details", use_container_width=True)
            if save_builder:
                try:
                    education_rows = []
                    for line in split_lines(education):
                        degree, field, institution, start_year, end_year = (line.split("|") + ["", "", "", "", ""])[:5]
                        education_rows.append({"degree": degree.strip(), "field": field.strip() or None, "institution": institution.strip(), "start_year": start_year.strip() or None, "end_year": end_year.strip() or None})
                    experience_rows = []
                    for line in split_lines(experience):
                        title_value, company_value, start_date, end_date, highlights = (line.split("|") + ["", "", "", "", ""])[:5]
                        experience_rows.append(
                            {
                                "title": title_value.strip(),
                                "company": company_value.strip(),
                                "start_date": start_date.strip() or None,
                                "end_date": end_date.strip() or None,
                                "highlights": split_csv(highlights),
                            }
                        )
                    project_rows = []
                    for line in split_lines(projects):
                        name, description, technologies = (line.split("|") + ["", "", ""])[:3]
                        project_rows.append({"name": name.strip(), "description": description.strip(), "technologies": split_csv(technologies)})
                    certification_rows = []
                    for line in split_lines(certifications):
                        name, issuer, issued_on = (line.split("|") + ["", "", ""])[:3]
                        certification_rows.append({"name": name.strip(), "issuer": issuer.strip() or None, "issued_on": issued_on.strip() or None})
                    candidate_api_post(
                        "/candidate/profile",
                        json_payload={
                            "full_name": full_name,
                            "email": email,
                            "phone": phone or None,
                            "location": location or None,
                            "headline": headline or None,
                            "summary": summary,
                            "skills": split_csv(skills),
                            "education": education_rows,
                            "experience": experience_rows,
                            "projects": project_rows,
                            "certifications": certification_rows,
                        },
                    )
                    set_section_notice("builder", "success", "Profile details saved.")
                    st.rerun()
                except APIRequestError as exc:
                    set_section_notice("builder", "error", str(exc))
                    st.rerun()
            show_section_notice("builder", clear=True)

        st.markdown("<div class='box'><div class='box-title'>3. Supporting documents</div><div class='muted'>Upload certificates and validation documents for the selected roles. These stay visible to the company you are applying to.</div></div>", unsafe_allow_html=True)
        support_left, support_right = st.columns([0.95, 1.05])
        with support_left:
            with st.form("candidate_supporting_document_upload"):
                document_type = st.selectbox(
                    "Document type",
                    [
                        "skill_certificate",
                        "education_certificate",
                        "supporting_document",
                    ],
                    format_func=lambda value: value.replace("_", " ").title(),
                )
                document_title = st.text_input("Document title")
                document_tags = st.text_input("Tags", placeholder="Python, AWS, Bachelors")
                document_file = st.file_uploader(
                    "Document",
                    type=["pdf", "docx", "png", "jpg", "jpeg"],
                    key="candidate_supporting_file",
                )
                upload_document = st.form_submit_button("Upload document", use_container_width=True)
            if upload_document:
                if not selected_role_ids:
                    set_section_notice("supporting", "error", "Choose at least one role before uploading supporting documents.")
                elif not document_file:
                    set_section_notice("supporting", "error", "Choose a file before uploading.")
                else:
                    try:
                        candidate_api_post(
                            "/candidate/documents",
                            data={
                                "company_id": selected_company_id,
                                "role_ids": json.dumps(selected_role_ids),
                                "document_type": document_type,
                                "title": document_title,
                                "tags": document_tags,
                            },
                            files=[("file", (document_file.name, document_file.getvalue(), document_file.type or "application/octet-stream"))],
                        )
                        set_section_notice("supporting", "success", "Supporting document uploaded.")
                    except APIRequestError as exc:
                        set_section_notice("supporting", "error", str(exc))
                    st.rerun()
            show_section_notice("supporting", clear=True)
        with support_right:
            if support_docs:
                for document in support_docs[:8]:
                    st.markdown(
                        f"<div class='review'><strong>{escape(text(document.get('title'), document.get('file_name')))}</strong><br><span class='muted'>{escape(text(document.get('document_type')).replace('_', ' ').title())} | {escape(', '.join(items(document.get('tags'))) or 'No tags')}</span></div>",
                        unsafe_allow_html=True,
                    )
            else:
                st.info("No supporting documents are attached yet.")

        st.markdown("<div class='box'><div class='box-title'>4. Final submit</div><div class='muted'>Submit after your role selection and uploads are ready. Match scores, recruiter notes, and verification outcomes will then appear in your dashboard.</div></div>", unsafe_allow_html=True)
        submit_cols = st.columns(3)
        submit_cols[0].metric("Roles selected", len(selected_role_ids))
        submit_cols[1].metric("Photo added", "Yes" if profile_photos else "No")
        submit_cols[2].metric("Supporting files", len(support_docs))
        if st.button("Submit application", use_container_width=True, key="candidate_submit_final"):
            try:
                if not selected_role_ids:
                    raise APIRequestError("Choose at least one role before submitting.")
                if resume_mode_label == "Upload resume":
                    latest_resume = resume_docs[0] if resume_docs else None
                    if not latest_resume:
                        raise APIRequestError("Add your resume before submitting.")
                    candidate_api_post(
                        "/candidate/applications",
                        json_payload={
                            "company_id": selected_company_id,
                            "role_ids": selected_role_ids,
                            "resume_mode": "upload",
                            "resume_document_id": latest_resume["document_id"],
                        },
                    )
                else:
                    education_rows = []
                    for line in split_lines(st.session_state.get("candidate_builder_education", education)):
                        degree, field, institution, start_year, end_year = (line.split("|") + ["", "", "", "", ""])[:5]
                        education_rows.append({"degree": degree.strip(), "field": field.strip() or None, "institution": institution.strip(), "start_year": start_year.strip() or None, "end_year": end_year.strip() or None})
                    experience_rows = []
                    for line in split_lines(st.session_state.get("candidate_builder_experience", experience)):
                        title_value, company_value, start_date, end_date, highlights = (line.split("|") + ["", "", "", "", ""])[:5]
                        experience_rows.append({"title": title_value.strip(), "company": company_value.strip(), "start_date": start_date.strip() or None, "end_date": end_date.strip() or None, "highlights": split_csv(highlights)})
                    project_rows = []
                    for line in split_lines(st.session_state.get("candidate_builder_projects", projects)):
                        name, description, technologies = (line.split("|") + ["", "", ""])[:3]
                        project_rows.append({"name": name.strip(), "description": description.strip(), "technologies": split_csv(technologies)})
                    certification_rows = []
                    for line in split_lines(st.session_state.get("candidate_builder_certifications", certifications)):
                        name, issuer, issued_on = (line.split("|") + ["", "", ""])[:3]
                        certification_rows.append({"name": name.strip(), "issuer": issuer.strip() or None, "issued_on": issued_on.strip() or None})
                    candidate_api_post(
                        "/candidate/applications",
                        json_payload={
                            "company_id": selected_company_id,
                            "role_ids": selected_role_ids,
                            "resume_mode": "builder",
                            "profile": {
                                "full_name": text(st.session_state.get("candidate_builder_full_name"), full_name),
                                "email": text(st.session_state.get("candidate_builder_email"), email),
                                "phone": text(st.session_state.get("candidate_builder_phone")) or None,
                                "location": text(st.session_state.get("candidate_builder_location")) or None,
                                "headline": text(st.session_state.get("candidate_builder_headline")) or None,
                                "summary": text(st.session_state.get("candidate_builder_summary"), summary),
                                "skills": split_csv(text(st.session_state.get("candidate_builder_skills"), skills)),
                                "education": education_rows,
                                "experience": experience_rows,
                                "projects": project_rows,
                                "certifications": certification_rows,
                            },
                        },
                    )
                set_section_notice("submit", "success", "Application submitted successfully.")
            except APIRequestError as exc:
                set_section_notice("submit", "error", str(exc))
            st.rerun()
        show_section_notice("submit", clear=True)
        return

    active_application = current_application
    active_roles = active_application.get("roles", []) if active_application else []
    role_label_map = {role.get("job_id"): text(role.get("title"), "Role") for role in active_roles if role.get("job_id")}
    current_feedback_company_id = st.session_state.get("candidate_feedback_company_id")
    selected_feedback_role_id = st.session_state.get("candidate_feedback_role_id")
    if current_feedback_company_id != selected_company_id:
        selected_feedback_role_id = None
    selected_feedback_role_id = preferred_role_id(active_roles, selected_feedback_role_id)
    st.session_state["candidate_feedback_role_id"] = selected_feedback_role_id
    st.session_state["candidate_feedback_company_id"] = selected_company_id
    active_role = next((role for role in active_roles if role.get("job_id") == selected_feedback_role_id), active_roles[0] if active_roles else None)

    if candidate_view == "Dashboard":
        st.markdown("<div class='box'><div class='box-title'>Saved profile</div><div class='muted'>This is the reusable profile that powers your applications across companies and roles.</div></div>", unsafe_allow_html=True)
        st.markdown(
            "<div class='profile-shell'><div class='profile-header'><div><div class='eyebrow'>Candidate profile</div>"
            f"<div class='feature-title' style='font-size:1.8rem; margin:.2rem 0'>{escape(text(profile_data.get('full_name'), text(candidate_session.get('full_name'), 'Candidate profile')))}</div>"
            f"<div class='muted'>{escape(text(profile_data.get('headline'), text(profile_data.get('email'), 'Saved in your candidate workspace')))}</div></div><div class='coverage-pill'>Reusable profile</div></div>"
            f"<div class='body' style='margin-top:.55rem'>{escape(text(profile_data.get('summary'), 'Your saved profile will appear here once you upload or build one.'))}</div>"
            f"<div style='margin-top:.8rem'>{chips(items(profile_data.get('skills')), 'good', 'No skills saved yet')}</div>"
            + (
                "<div class='section'>Education</div><ul class='bullet-list'>"
                + "".join(
                    f"<li>{escape(' | '.join(filter(None, [entry.get('degree'), entry.get('field'), entry.get('institution')])) or text(entry.get('institution')))}</li>"
                    for entry in (profile_data.get("education") or [])[:5]
                )
                + "</ul>"
                if profile_data.get("education")
                else ""
            )
            + (
                "<div class='section'>Experience</div><ul class='bullet-list'>"
                + "".join(
                    f"<li>{escape(' | '.join(filter(None, [entry.get('title'), entry.get('company')])))}"
                    + (f": {escape(', '.join(items(entry.get('highlights'))[:2]))}" if items(entry.get("highlights")) else "")
                    + "</li>"
                    for entry in (profile_data.get("experience") or [])[:5]
                )
                + "</ul>"
                if profile_data.get("experience")
                else ""
            )
            + (
                "<div class='section'>Projects</div><ul class='bullet-list'>"
                + "".join(
                    f"<li>{escape(' | '.join(filter(None, [entry.get('name'), entry.get('description')])) or text(entry.get('name')))}</li>"
                    for entry in (profile_data.get("projects") or [])[:5]
                )
                + "</ul>"
                if profile_data.get("projects")
                else ""
            )
            + (
                "<div class='section'>Certifications</div><ul class='bullet-list'>"
                + "".join(
                    f"<li>{escape(' | '.join(filter(None, [entry.get('name'), entry.get('issuer'), entry.get('issued_on')])) or text(entry.get('name')))}</li>"
                    for entry in (profile_data.get("certifications") or [])[:5]
                )
                + "</ul>"
                if profile_data.get("certifications")
                else ""
            )
            + "</div>",
            unsafe_allow_html=True,
        )
        summary_cols = st.columns(3)
        summary_cols[0].metric("Saved skills", len(items(profile_data.get("skills"))))
        summary_cols[1].metric("Documents", len(candidate_documents))
        summary_cols[2].metric("Notifications", len(profile_notifications))
        return

    if candidate_view == "Feedback":
        st.markdown("<div class='box'><div class='box-title'>Feedback</div><div class='muted'>See recruiter notes, verification outcomes, and score visibility for one selected role at a time.</div></div>", unsafe_allow_html=True)
        if not active_application or not active_roles:
            st.info("Submit an application first to unlock recruiter feedback and verification outcomes.")
            return
        selected_feedback_role_id = st.selectbox(
            "Selected role",
            list(role_label_map.keys()),
            index=list(role_label_map.keys()).index(selected_feedback_role_id) if selected_feedback_role_id in role_label_map else 0,
            format_func=lambda role_id: role_label_map.get(role_id, role_id),
            key="candidate_feedback_role_picker",
        )
        st.session_state["candidate_feedback_role_id"] = selected_feedback_role_id
        st.session_state["candidate_feedback_company_id"] = selected_company_id
        active_role = next((role for role in active_roles if role.get("job_id") == selected_feedback_role_id), active_roles[0])
        company = active_application.get("company", {})
        st.markdown(
            f"<div class='box'><div class='box-title'>{escape(text(company.get('company_name'), 'Company'))}</div><div class='muted'>{escape(text(active_role.get('title'), 'Role'))} | {escape(text(active_role.get('team'), 'Team'))}</div></div>",
            unsafe_allow_html=True,
        )
        verification_status = text(active_role.get("verification_status"), "pending").replace("_", " ").title()
        verification_cols = st.columns(3)
        verification_cols[0].metric("Verification", verification_status)
        verification_cols[1].metric("Status", candidate_status_label(active_role.get("status")))
        verification_cols[2].metric("Feedback notes", len(items(active_role.get("recruiter_notes"))))
        if active_role.get("score_visible"):
            st.markdown(
                f"<div class='box'><div class='box-title'>Match score</div><div class='metric-value'>{pct(active_role.get('match_score', 0.0))}%</div><div class='muted'>Visible after recruiter verification</div></div>",
                unsafe_allow_html=True,
            )
        else:
            st.info("The match score will appear here after the hiring team verifies your documents for this role.")
        if text(active_role.get("verification_notes")):
            st.markdown(
                f"<div class='box'><div class='box-title'>Verification outcome</div><div class='body' style='margin-top:.45rem'>{escape(text(active_role.get('verification_notes')))}</div><div class='muted' style='margin-top:.35rem'>{escape(text(active_role.get('verification_reviewer'), 'Hiring team'))}</div></div>",
                unsafe_allow_html=True,
            )
        verification_checks = active_role.get("verification_summary", {}).get("checks") or []
        if verification_checks:
            st.markdown(
                "<div class='box'><div class='box-title'>Proof review</div><ul class='bullet-list'>"
                + "".join(f"<li>{escape(text(check.get('label')))}: {escape(text(check.get('detail')))}</li>" for check in verification_checks[:6])
                + "</ul></div>",
                unsafe_allow_html=True,
            )
        recruiter_notes = items(active_role.get("recruiter_notes")) or [
            text(entry.get("notes"))
            for entry in (active_role.get("feedback") or [])
            if text(entry.get("notes"))
        ]
        if recruiter_notes:
            st.markdown(
                "<div class='box'><div class='box-title'>Recruiter feedback</div><ul class='bullet-list'>"
                + "".join(f"<li>{escape(note)}</li>" for note in recruiter_notes[:6])
                + "</ul></div>",
                unsafe_allow_html=True,
            )
        else:
            st.markdown("<div class='box'><div class='box-title'>Recruiter feedback</div><div class='muted'>Recruiter notes will appear here when the company updates this role.</div></div>", unsafe_allow_html=True)
        return

    if candidate_view == "Messages":
        st.markdown("<div class='box'><div class='box-title'>Messages</div><div class='muted'>Keep company conversations separate from recruiter feedback and profile details.</div></div>", unsafe_allow_html=True)
        if not active_application or not active_roles:
            st.info("Submit an application first to start a conversation with the company.")
            return
        selected_feedback_role_id = st.selectbox(
            "Selected role",
            list(role_label_map.keys()),
            index=list(role_label_map.keys()).index(selected_feedback_role_id) if selected_feedback_role_id in role_label_map else 0,
            format_func=lambda role_id: role_label_map.get(role_id, role_id),
            key="candidate_message_role_picker",
        )
        st.session_state["candidate_feedback_role_id"] = selected_feedback_role_id
        st.session_state["candidate_feedback_company_id"] = selected_company_id
        active_role = next((role for role in active_roles if role.get("job_id") == selected_feedback_role_id), active_roles[0])
        company = active_application.get("company", {})
        conversation_entries = active_role.get("conversation") or []
        st.markdown(
            f"<div class='box'><div class='box-title'>{escape(text(company.get('company_name'), 'Company'))}</div><div class='muted'>{escape(text(active_role.get('title'), 'Role'))}</div></div>",
            unsafe_allow_html=True,
        )
        message_notice_key = f"message_{active_application.get('application_id')}_{selected_feedback_role_id}"
        if conversation_entries:
            for entry in conversation_entries[-8:]:
                st.markdown(
                    f"<div class='review'><strong>{escape(text(entry.get('sender_name')))}</strong><br><span class='muted'>{escape(full_time(entry.get('created_at')))} | {escape(text(entry.get('sender_type')).title())}</span><div class='body' style='margin-top:.45rem'>{escape(text(entry.get('message')))}</div></div>",
                    unsafe_allow_html=True,
                )
                if text(entry.get("sender_type")) == "candidate" and text(entry.get("message_id")):
                    if st.button("Delete message", key=f"candidate_delete_message_{entry['message_id']}", use_container_width=True):
                        try:
                            candidate_api_delete(f"/candidate/conversations/{entry['message_id']}")
                            set_section_notice(message_notice_key, "success", "Message deleted.")
                        except APIRequestError as exc:
                            set_section_notice(message_notice_key, "error", str(exc))
                        st.rerun()
        else:
            st.info("No messages yet for this role.")
        with st.form(f"candidate_message_form_{active_application.get('application_id')}_{selected_feedback_role_id}", clear_on_submit=True):
            message_body = st.text_area(
                "Message to company",
                height=100,
                placeholder="Ask about next steps, document review, or anything related to this role.",
            )
            send_message = st.form_submit_button("Send message", use_container_width=True)
        if send_message:
            try:
                candidate_api_post(
                    "/candidate/conversations",
                    json_payload={
                        "company_id": company.get("workspace_id"),
                        "role_id": selected_feedback_role_id,
                        "message": message_body,
                    },
                )
                set_section_notice(message_notice_key, "success", "Your message has been sent to the company.")
            except APIRequestError as exc:
                set_section_notice(message_notice_key, "error", str(exc))
            st.rerun()
        show_section_notice(message_notice_key, clear=True)
        return


st.set_page_config(page_title="PulseHire", page_icon="P", layout="wide", initial_sidebar_state="expanded")
st.markdown(
    """
    <style>
    :root { --bg:#f4f7fb; --panel:#ffffff; --ink:#102132; --muted:#5f7082; --line:#dbe4ef; --brand:#123f68; --brand2:#0f3150; --good:#176251; --goodbg:#e8f5ef; --risk:#934747; --riskbg:#f9ecec; }
    .stApp { background:linear-gradient(180deg,#f8fafc,#f2f5f9); color:var(--ink); }
    .block-container { padding-top:1rem; padding-bottom:2rem; max-width:1380px; }
    [data-testid="stSidebar"] { background:#fbfcfe; border-right:1px solid var(--line); }
    [data-testid="stSidebar"] [role="radiogroup"] { gap:.35rem; }
    [data-testid="stSidebar"] [data-baseweb="radio"] { background:#fff; border:1px solid var(--line); border-radius:14px; padding:.65rem .8rem; }
    [data-testid="stSidebar"] [data-baseweb="radio"] label { width:100%; }
    .stButton>button, .stFormSubmitButton>button { background:linear-gradient(180deg,var(--brand),var(--brand2)); color:#fff !important; border:0 !important; border-radius:14px !important; font-weight:700 !important; box-shadow:0 10px 22px rgba(18,63,104,.16); }
    .stTextInput input, .stTextArea textarea, .stNumberInput input, [data-baseweb="select"]>div, [data-testid="stFileUploaderDropzone"] { background:#fff !important; color:var(--ink) !important; border:1px solid #d7e0eb !important; border-radius:14px !important; }
    .brand { background:linear-gradient(145deg,var(--brand),var(--brand2)); color:#fff; padding:1rem; border-radius:22px; margin-bottom:1rem; box-shadow:0 18px 34px rgba(18,63,104,.18); }
    .hero, .box, .card { background:var(--panel); border:1px solid var(--line); box-shadow:0 16px 34px rgba(16,33,50,.07); border-radius:22px; transition:transform .22s ease, box-shadow .22s ease, border-color .22s ease; }
    .hero { padding:1.35rem; margin-bottom:1rem; }
    .hero-grid { display:grid; grid-template-columns:1.45fr .85fr; gap:1rem; }
    .hero-kicker, .eyebrow, .section { text-transform:uppercase; letter-spacing:.14em; font-size:.72rem; color:var(--brand); font-weight:800; }
    .hero-title { font-size:2.25rem; font-weight:800; letter-spacing:-.05em; color:var(--ink); margin:.35rem 0 .45rem; }
    .hero-copy, .muted { color:var(--muted); }
    .side { background:linear-gradient(145deg,var(--brand),var(--brand2)); color:#fff; border-radius:18px; padding:1rem; }
    .side-row { display:flex; justify-content:space-between; gap:.75rem; padding:.3rem 0; border-bottom:1px solid rgba(255,255,255,.12); }
    .side-row:last-child { border-bottom:0; }
    .metrics { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:1rem; margin-bottom:1rem; }
    .metric { background:#fff; border:1px solid var(--line); border-radius:20px; padding:1rem; box-shadow:0 16px 34px rgba(16,33,50,.07); }
    .metric-value { font-size:1.9rem; font-weight:800; color:var(--ink); margin:.18rem 0 .28rem; }
    .box, .card { padding:1rem; margin-bottom:1rem; }
    .card:hover, .box:hover { transform:translateY(-2px); box-shadow:0 20px 38px rgba(16,33,50,.10); }
    .box-title, .card-title { font-size:1.22rem; font-weight:800; color:var(--ink); letter-spacing:-.03em; }
    .card-top { display:grid; grid-template-columns:1fr auto; gap:1rem; }
    .score-box { text-align:right; min-width:6rem; }
    .fit, .chip, .pill, .mini { display:inline-flex; align-items:center; justify-content:center; border-radius:999px; padding:.28rem .65rem; font-size:.78rem; font-weight:700; }
    .fit { background:#e7eef8; color:var(--brand); }
    .pill { background:#e8f5ef; color:var(--good); margin-left:.4rem; }
    .chip.good, .mini.yes { background:var(--goodbg); color:var(--good); }
    .chip.risk, .mini.no { background:var(--riskbg); color:var(--risk); }
    .score { font-size:2rem; font-weight:800; color:var(--ink); line-height:1; margin-top:.25rem; }
    .small { font-size:.82rem; }
    .mini-stats { display:flex; gap:1rem; color:var(--muted); font-size:.84rem; margin-bottom:.2rem; }
    .bar { height:.58rem; border-radius:999px; background:#ebf0f5; overflow:hidden; margin:.7rem 0; }
    .fill { height:100%; border-radius:999px; background:linear-gradient(90deg,#1a5a8f,#176251); }
    .section { margin:.55rem 0 .25rem; }
    .body { color:var(--ink); line-height:1.6; }
    .updated { border-color:#bfd3e7; }
    .table-wrap { overflow-x:auto; margin-top:.7rem; }
    table { width:100%; border-collapse:collapse; }
    th, td { padding:.65rem .5rem; border-bottom:1px solid var(--line); text-align:left; }
    th { color:var(--brand); font-size:.75rem; text-transform:uppercase; letter-spacing:.1em; }
    .timeline { display:flex; flex-direction:column; gap:.8rem; }
    .timeline-item { padding-left:.9rem; border-left:2px solid #dbe4ef; }
    .review { background:#f8fbff; border:1px solid var(--line); border-radius:18px; padding:.95rem; margin-bottom:.8rem; }
    .feature-hero { border-radius:22px; padding:1.15rem 1.2rem; margin-bottom:1rem; border:1px solid var(--line); box-shadow:0 16px 34px rgba(16,33,50,.06); }
    .feature-title { font-size:1.65rem; font-weight:800; letter-spacing:-.04em; color:var(--ink); margin:.3rem 0; }
    .feature-copy { color:var(--muted); line-height:1.65; }
    .accent-tag { display:inline-flex; align-items:center; padding:.32rem .72rem; border-radius:999px; font-size:.78rem; font-weight:800; letter-spacing:.08em; text-transform:uppercase; }
    .feature-hero.candidates { background:linear-gradient(135deg,#edf8f5,#ffffff); }
    .feature-hero.candidates .accent-tag { background:#d8efe7; color:#13614f; }
    .feature-hero.details { background:linear-gradient(135deg,#eef6fb,#ffffff); }
    .feature-hero.details .accent-tag { background:#d9eaf7; color:#1b4d75; }
    .feature-hero.roles { background:linear-gradient(135deg,#f1f0fb,#ffffff); }
    .feature-hero.roles .accent-tag { background:#e0ddf8; color:#4d3d82; }
    .feature-hero.shortlist { background:linear-gradient(135deg,#fff7ea,#ffffff); }
    .feature-hero.shortlist .accent-tag { background:#fbe5bf; color:#8a5a00; }
    .feature-hero.reviews { background:linear-gradient(135deg,#fdf1f5,#ffffff); }
    .feature-hero.reviews .accent-tag { background:#f4d8e3; color:#8b3556; }
    .panel-note { background:#f7fafc; border:1px dashed var(--line); border-radius:16px; padding:.85rem 1rem; color:var(--muted); margin-bottom:1rem; }
    .topline { display:flex; justify-content:space-between; align-items:center; gap:1rem; margin-bottom:1rem; }
    .subtle { color:var(--muted); font-size:.95rem; }
    .auth-shell { max-width:1080px; margin:0 auto; padding-top:1rem; }
    .auth-grid { display:grid; grid-template-columns:1fr 1fr; gap:1rem; }
    .auth-card { background:#fff; border:1px solid var(--line); border-radius:24px; padding:1.2rem; box-shadow:0 18px 36px rgba(16,33,50,.08); }
    .auth-hero { background:linear-gradient(145deg,#123f68,#0f3150); color:#fff; border-radius:26px; padding:1.4rem; margin-bottom:1rem; box-shadow:0 18px 36px rgba(18,63,104,.18); }
    .section-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:1rem; margin-bottom:1rem; }
    .family-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:1rem; margin-top:1rem; }
    .family-card { background:#fff; border:1px solid var(--line); border-radius:20px; padding:1rem; }
    .family-card.high { background:linear-gradient(180deg,#f6fbf8,#ffffff); }
    .family-card.medium { background:linear-gradient(180deg,#f8fbff,#ffffff); }
    .family-card.low { background:linear-gradient(180deg,#fff8f2,#ffffff); }
    .family-head { display:flex; justify-content:space-between; gap:1rem; align-items:flex-start; }
    .coverage-pill { display:inline-flex; align-items:center; justify-content:center; min-width:3.5rem; padding:.35rem .75rem; border-radius:999px; background:#edf2f7; color:var(--brand); font-weight:800; }
    .skill-stack { display:flex; flex-direction:column; gap:.75rem; margin-top:1rem; }
    .skill-row { background:#f7fafc; border:1px solid var(--line); border-radius:16px; padding:.75rem .8rem; }
    .skill-row-head { display:flex; justify-content:space-between; gap:.75rem; font-weight:700; color:var(--ink); margin-bottom:.35rem; }
    .tiny-bar { height:.42rem; border-radius:999px; background:#e7edf4; overflow:hidden; margin-bottom:.35rem; }
    .tiny-fill { height:100%; border-radius:999px; background:linear-gradient(90deg,#1a5a8f,#23a06b); }
    .profile-shell { background:#fff; border:1px solid var(--line); border-radius:24px; padding:1.2rem; box-shadow:0 18px 34px rgba(16,33,50,.08); }
    .profile-header { display:flex; justify-content:space-between; gap:1rem; align-items:flex-start; margin-bottom:1rem; }
    .detail-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:1rem; }
    .bullet-list { margin:0; padding-left:1rem; color:var(--ink); line-height:1.7; }
    .empty-state { background:#fff; border:1px dashed var(--line); border-radius:22px; padding:1.2rem; text-align:center; color:var(--muted); }
    @media (max-width:1080px) { .hero-grid, .metrics, .card-top, .section-grid, .auth-grid, .family-grid, .detail-grid, .topline { grid-template-columns:1fr; display:block; } .score-box { text-align:left; } }
    </style>
    """,
    unsafe_allow_html=True,
)

show_flash_messages()

portal_mode = st.session_state.get(PORTAL_KEY)
if portal_mode not in {"candidate", "company"}:
    render_portal_selection()
    st.stop()

if portal_mode == "candidate":
    render_candidate_portal()
    st.stop()

auth_session = st.session_state.get(AUTH_KEY)
if auth_session:
    try:
        auth_session = api_get("/auth/me")
        st.session_state[AUTH_KEY] = auth_session
    except APIRequestError:
        st.session_state.pop(AUTH_KEY, None)
        auth_session = None

if not auth_session:
    st.markdown(
        """
        <div class='auth-shell'>
          <div class='auth-hero'>
            <div class='eyebrow' style='color:#dbeafe'>PulseHire</div>
            <div class='hero-title' style='color:#fff'>Company hiring workspace</div>
            <div style='opacity:.9; line-height:1.7'>Create a private company workspace or sign in to continue. Your candidates, roles, and reviews stay separated by company.</div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    signin_col, signup_col = st.columns(2)
    with signin_col:
        st.markdown("<div class='auth-card'><div class='box-title'>Sign in</div><div class='muted'>Continue with your company workspace.</div></div>", unsafe_allow_html=True)
        with st.form("signin_form"):
            signin_company = st.text_input("Company name")
            signin_password = st.text_input("Password", type="password")
            signin_submit = st.form_submit_button("Sign in", use_container_width=True)
        if signin_submit:
            try:
                st.session_state[AUTH_KEY] = api_post(
                    "/auth/login",
                    json_payload={"company_name": signin_company, "password": signin_password},
                )
                st.rerun()
            except APIRequestError as exc:
                st.error(str(exc))
    with signup_col:
        st.markdown("<div class='auth-card'><div class='box-title'>Create workspace</div><div class='muted'>Set up a separate company workspace for your hiring team.</div></div>", unsafe_allow_html=True)
        with st.form("signup_form"):
            company_name = st.text_input("Company name")
            admin_name = st.text_input("Admin name")
            email = st.text_input("Work email")
            password = st.text_input("Password", type="password")
            register_submit = st.form_submit_button("Create workspace", use_container_width=True)
        if register_submit:
            try:
                st.session_state[AUTH_KEY] = api_post(
                    "/auth/register",
                    json_payload={
                        "company_name": company_name,
                        "admin_name": admin_name,
                        "email": email or None,
                        "password": password,
                    },
                )
                st.rerun()
            except APIRequestError as exc:
                st.error(str(exc))
    if st.button("Back to portal selection", use_container_width=True, key="company_back_to_selection"):
        st.session_state.pop(AUTH_KEY, None)
        st.session_state.pop(PORTAL_KEY, None)
        st.rerun()
    st.stop()

try:
    summary = api_get("/summary")
    jobs = api_get("/jobs")
    candidates = api_get("/candidates")
    feedback_entries = api_get("/feedback")
    recruiter_events = api_get("/events?audience=recruiter&limit=10")
except APIRequestError as exc:
    st.error(str(exc))
    st.stop()

pending_removed_feedback_ids = set(st.session_state.get("pending_removed_feedback_ids", []))
if pending_removed_feedback_ids:
    live_feedback_ids = {text(entry.get("feedback_id")) for entry in feedback_entries}
    pending_removed_feedback_ids = {feedback_id for feedback_id in pending_removed_feedback_ids if feedback_id in live_feedback_ids}
    feedback_entries = [
        entry for entry in feedback_entries if text(entry.get("feedback_id")) not in pending_removed_feedback_ids
    ]
    st.session_state["pending_removed_feedback_ids"] = sorted(pending_removed_feedback_ids)

job_labels = {
    job["job_id"]: job["title"] + (f" | {text(job.get('team'))}" if text(job.get("team")) else "")
    for job in jobs
}
job_options = ["__none__"] + [job["job_id"] for job in jobs]
selected_job_id = st.session_state.get("selected_job_id")
if selected_job_id not in job_labels:
    selected_job_id = jobs[0]["job_id"] if jobs else "__none__"
view_options = ["About", "Candidates", "Candidate details", "Roles", "Shortlist", "Reviews", "Analytics"]
current_view = st.session_state.get("workspace_view")
if current_view not in view_options:
    current_view = "About"

if selected_job_id == "__none__":
    selected_job_id = None

with st.sidebar:
    st.markdown(
        f"<div class='brand'><div class='box-title' style='color:#fff'>PulseHire</div><div style='opacity:.88'>{escape(text(auth_session.get('company_name'), 'Company workspace'))}</div><div style='opacity:.72; margin-top:.3rem'>{escape(text(auth_session.get('admin_name'), 'Admin'))}</div></div>",
        unsafe_allow_html=True,
    )
    current_view = st.radio("Sections", options=view_options, index=view_options.index(current_view), key="workspace_view")
    selected_job_option = selected_job_id if selected_job_id in job_options else "__none__"
    chosen = st.selectbox(
        "Selected role",
        options=job_options,
        index=job_options.index(selected_job_option),
        format_func=lambda value: "No role selected" if value == "__none__" else job_labels[value],
    )
    selected_job_id = None if chosen == "__none__" else chosen
    st.session_state["selected_job_id"] = selected_job_id
    if st.button("Switch portal", use_container_width=True):
        st.session_state.pop(AUTH_KEY, None)
        st.session_state.pop(PORTAL_KEY, None)
        clear_shortlist_answer()
        st.session_state.pop("scenario_preview", None)
        st.rerun()
    if st.button("Sign out", use_container_width=True):
        try:
            api_post("/auth/logout")
        except APIRequestError:
            pass
        st.session_state.pop(AUTH_KEY, None)
        clear_shortlist_answer()
        st.session_state.pop("scenario_preview", None)
        st.rerun()

if st.session_state.get("last_answer_job_id") != selected_job_id:
    clear_shortlist_answer()
    st.session_state.pop("scenario_preview", None)
st.session_state["last_answer_job_id"] = selected_job_id

selected_job = api_get(f"/jobs/{selected_job_id}") if selected_job_id else None
rankings_payload = api_get(f"/jobs/{selected_job_id}/rankings") if selected_job_id else {"rankings": []}
insights = api_get(f"/jobs/{selected_job_id}/insights") if selected_job_id else {}
rankings = rankings_payload.get("rankings", [])
ranking_by_candidate = {item["candidate"]["candidate_id"]: item for item in rankings}
workspace_candidates = dedupe_candidates(candidates, ranking_by_candidate)
if selected_job_id:
    scoped_ranked_candidates = dedupe_candidates([item["candidate"] for item in rankings], ranking_by_candidate)
    company_candidates = scoped_ranked_candidates
else:
    company_candidates = []
candidate_lookup = {candidate["candidate_id"]: candidate for candidate in workspace_candidates}
fit_counts = Counter(item.get("fit_band", "partial") for item in rankings)
shortlist_ready = fit_counts.get("excellent", 0) + fit_counts.get("strong", 0)
st.markdown(
    f"<div class='topline'><div><div class='box-title'>Hiring console</div><div class='subtle'>{escape(text(auth_session.get('company_name'), 'Company workspace'))}</div></div><div class='subtle'>{escape(text(selected_job.get('title') if selected_job else None, 'No role selected'))}</div></div>",
    unsafe_allow_html=True,
)

render_feature_banner(current_view)

candidate_options: dict[str, str] = {}
candidate_label_counts: Counter[str] = Counter()
for candidate in company_candidates:
    label = text(candidate.get("name"), "Candidate")
    title = text(candidate.get("current_title"))
    if title:
        label = f"{label} | {title}"
    candidate_label_counts[label] += 1
    if candidate_label_counts[label] > 1:
        label = f"{label} ({candidate_label_counts[label]})"
    candidate_options[label] = candidate["candidate_id"]
role_options = {"No role": ""}
role_options.update({label: job_id for job_id, label in job_labels.items()})

if current_view == "Candidates":
    candidate_stats = [
        ("Candidates", len(company_candidates), "Profiles for selected role"),
        ("Role matches", len(company_candidates), "Role-scoped pool"),
        ("Ready to advance", shortlist_ready, "Strong or excellent fit"),
    ]
    st.markdown(
        "<div class='section-grid'>"
        + "".join(
            f"<div class='metric'><div class='eyebrow'>{escape(label)}</div><div class='metric-value'>{value}</div><div class='muted'>{escape(note)}</div></div>"
            for label, value, note in candidate_stats
        )
        + "</div>",
        unsafe_allow_html=True,
    )
    st.markdown("<div class='box'><div class='box-title'>Add candidates</div><div class='muted'>Upload resumes to add candidates to this company workspace.</div></div>", unsafe_allow_html=True)
    uploads = st.file_uploader("Add resume files", type=UPLOAD_TYPES, accept_multiple_files=True, label_visibility="collapsed")
    action_col, note_col = st.columns([0.32, 0.68])
    with action_col:
        if st.button("Add candidates", use_container_width=True):
            if not selected_job_id:
                push_flash("error", "Please select role to rank candidate.")
            elif not uploads:
                push_flash("warning", "Choose one or more resume files first.")
            else:
                try:
                    result = api_post(
                        "/candidates/uploads",
                        files=[("files", (file.name, file.getvalue(), file.type or "application/octet-stream")) for file in uploads],
                    )
                    for item in result.get("results", []):
                        level = "success"
                        if item.get("status") == "rejected":
                            level = "warning"
                        elif item.get("status") == "unchanged":
                            level = "info"
                        push_flash(level, text(item.get("message"), "Candidate update saved."))
                except APIRequestError as exc:
                    push_flash("error", str(exc))
            st.rerun()
    with note_col:
        st.markdown("<div class='box'><div class='eyebrow'>Resume intake</div><div class='muted'>Select a role first, then upload resumes into the active hiring workflow. Unreadable or duplicate files are handled automatically.</div></div>", unsafe_allow_html=True)

    filter_left, filter_mid, filter_right, filter_toggle, filter_action = st.columns([1.2, 0.95, 0.85, 0.7, 0.9])
    search_text = filter_left.text_input("Search candidates", placeholder="Name, title, location, skill, or summary")
    fit_options = [band for band in FIT_ORDER if fit_counts.get(band, 0)]
    fit_filter = filter_mid.multiselect("Match band", options=fit_options, default=fit_options, disabled=not bool(selected_job_id and fit_options))
    sort_by = filter_right.selectbox("Sort by", ["Best match", "Recently updated", "A-Z"])
    shortlist_only = filter_toggle.checkbox("Shortlist only", value=False, disabled=not bool(selected_job_id))
    if filter_action.button("Open details", use_container_width=True):
        st.session_state["workspace_view"] = "Candidate details"
        st.rerun()

    if not selected_job_id:
        st.info("Select a role first to view only the candidates ranked for that role.")
        st.stop()

    ordered = company_candidates[:]
    if sort_by == "Recently updated":
        ordered.sort(key=lambda candidate: parse_stamp(candidate.get("last_updated")) or datetime.min.replace(tzinfo=UTC), reverse=True)
    elif sort_by == "A-Z":
        ordered.sort(key=lambda candidate: candidate["name"].lower())
    else:
        ordered.sort(key=lambda candidate: ranking_by_candidate.get(candidate["candidate_id"], {}).get("rank", 999))

    visible: list[tuple[dict[str, Any], dict[str, Any] | None]] = []
    for candidate in ordered:
        ranking = ranking_by_candidate.get(candidate["candidate_id"])
        haystack = " ".join(
            [
                text(candidate.get("name")),
                text(candidate.get("current_title")),
                text(candidate.get("location")),
                text(candidate.get("summary")),
                ", ".join(items(candidate.get("skills"))),
            ]
        ).lower()
        if search_text and search_text.lower() not in haystack:
            continue
        if fit_filter and ranking and ranking.get("fit_band") not in fit_filter:
            continue
        if shortlist_only and (not ranking or ranking.get("fit_band") not in {"excellent", "strong"}):
            continue
        visible.append((candidate, ranking))

    st.caption(f"Showing {len(visible)} candidate profile{'s' if len(visible) != 1 else ''}.")
    if not visible:
        st.info("Add resumes to start building the candidate list.")
    total_pages = max((len(visible) - 1) // PAGE_SIZE + 1, 1)
    page_number = 1
    if total_pages > 1:
        page_number = st.number_input("Page", min_value=1, max_value=total_pages, value=1, step=1)
    start = (page_number - 1) * PAGE_SIZE
    end = start + PAGE_SIZE
    displayed = visible[start:end]
    st.markdown("<div class='box'><div class='box-title'>Candidate list</div></div>", unsafe_allow_html=True)
    if not displayed:
        st.markdown("<div class='empty-state'>Add resumes to start building the candidate list.</div>", unsafe_allow_html=True)
    for candidate, ranking in displayed:
        st.markdown(candidate_card(candidate, ranking, bool(selected_job_id)), unsafe_allow_html=True)

if current_view == "Candidate details":
    if not selected_job_id:
        st.info("Select a role first to open the role-specific candidate review workspace.")
    elif not company_candidates:
        st.markdown("<div class='empty-state'>Add candidates first to open the detailed review workspace.</div>", unsafe_allow_html=True)
    else:
        detail_pairs = [(candidate, ranking_by_candidate.get(candidate["candidate_id"])) for candidate in company_candidates]
        detail_pairs.sort(
            key=lambda pair: (
                ranking_by_candidate.get(pair[0]["candidate_id"], {}).get("rank", 999),
                text(pair[0].get("name")).lower(),
            )
        )
        selected_candidate_id = st.session_state.get("selected_candidate_id")
        available_ids = [candidate["candidate_id"] for candidate, _ in detail_pairs]
        if selected_candidate_id not in available_ids:
            selected_candidate_id = available_ids[0]
        option_labels: list[str] = []
        option_label_counts: Counter[str] = Counter()
        option_ids: list[str] = []
        for candidate, ranking in detail_pairs:
            label = candidate_focus_label(candidate, ranking)
            option_label_counts[label] += 1
            if option_label_counts[label] > 1:
                label = f"{label} ({option_label_counts[label]})"
            option_labels.append(label)
            option_ids.append(candidate["candidate_id"])
        current_index = option_ids.index(selected_candidate_id)
        selected_label = st.selectbox("Candidate", option_labels, index=current_index)
        selected_candidate_id = option_ids[option_labels.index(selected_label)]
        st.session_state["selected_candidate_id"] = selected_candidate_id
        focus_candidate, focus_ranking = next(
            ((candidate, ranking) for candidate, ranking in detail_pairs if candidate["candidate_id"] == selected_candidate_id),
            (None, None),
        )

        if focus_candidate:
            focus_insight = {}
            verification_payload = {}
            candidate_documents = []
            candidate_conversations = []
            candidate_packet = {}
            if selected_job_id:
                try:
                    focus_insight = api_get(f"/jobs/{selected_job_id}/candidates/{focus_candidate['candidate_id']}/insight")
                except APIRequestError:
                    focus_insight = {}
                try:
                    verification_payload = api_get(f"/candidates/{focus_candidate['candidate_id']}/verification?job_id={selected_job_id}")
                except APIRequestError:
                    verification_payload = {}
                try:
                    candidate_documents = api_get(f"/candidates/{focus_candidate['candidate_id']}/documents?job_id={selected_job_id}")
                except APIRequestError:
                    candidate_documents = []
                try:
                    candidate_conversations = api_get(f"/candidates/{focus_candidate['candidate_id']}/conversations?job_id={selected_job_id}")
                except APIRequestError:
                    candidate_conversations = []
                try:
                    candidate_packet = api_get(f"/ats/jobs/{selected_job_id}/candidates/{focus_candidate['candidate_id']}/packet")
                except APIRequestError:
                    candidate_packet = {}
            focus_packet_ranking = {}
            if isinstance(candidate_packet, dict):
                focus_packet_ranking = candidate_packet.get("ranking") or {}
            active_ranking = focus_packet_ranking or (focus_ranking or {})
            detail_left, detail_right = st.columns([1.15, 0.85])
            with detail_left:
                st.markdown(
                    f"<div class='profile-shell'><div class='profile-header'><div><div class='eyebrow'>Candidate</div><div class='feature-title' style='font-size:2rem; margin:.2rem 0'>{escape(focus_candidate['name'])}</div><div class='muted'>{escape(text(focus_candidate.get('current_title'), 'Candidate profile'))} | {escape(text(focus_candidate.get('location'), 'Location flexible'))}</div></div><div class='coverage-pill'>{escape(FIT_LABELS.get(text(focus_ranking.get('fit_band') if focus_ranking else 'profile', 'profile'), 'Profile'))}</div></div></div>",
                    unsafe_allow_html=True,
                )
                detail_metrics = st.columns(3)
                if active_ranking:
                    detail_metrics[0].metric("Match score", f"{pct(active_ranking.get('breakdown', {}).get('total_score'))}%")
                    detail_metrics[1].metric("Confidence", f"{pct(active_ranking.get('breakdown', {}).get('confidence_score'))}%")
                    detail_metrics[2].metric("Stability", f"{pct(active_ranking.get('breakdown', {}).get('stability_score'))}%")
                    st.markdown(f"<div class='box' style='margin-top:1rem'><div class='box-title'>Decision summary</div><div class='body' style='margin-top:.45rem'>{escape(text(focus_insight.get('decision_signal') or active_ranking.get('decision_signal'), 'No decision guidance available yet.'))}</div></div>", unsafe_allow_html=True)
                    breakdown = active_ranking.get("breakdown", {})
                    score_rows = [
                        ("Retrieval evidence", pct(breakdown.get("retrieval_score"))),
                        ("Must-have fit", pct(breakdown.get("must_have_score"))),
                        ("Experience fit", pct(breakdown.get("experience_score"))),
                        ("Education fit", pct(breakdown.get("education_score"))),
                        ("Recruiter signal", pct((float(breakdown.get("feedback_score", 0.0)) + 1.0) / 2.0)),
                    ]
                    st.markdown(
                        "<div class='box'><div class='box-title'>Match score explanation</div><div class='table-wrap'><table><thead><tr><th>Signal</th><th>Score</th></tr></thead><tbody>"
                        + "".join(f"<tr><td>{escape(label)}</td><td>{value}%</td></tr>" for label, value in score_rows)
                        + "</tbody></table></div></div>",
                        unsafe_allow_html=True,
                    )
                else:
                    detail_metrics[0].metric("Profile completeness", f"{pct(focus_candidate.get('completeness_score'))}%")
                    detail_metrics[1].metric("Experience", f"{focus_candidate.get('years_experience', 0.0):.1f} yrs")
                    detail_metrics[2].metric("Skills", str(len(items(focus_candidate.get("skills")))))
                    st.info("Select a role in the sidebar to see role-specific scoring and shortlist reasoning.")

                info_left, info_right = st.columns(2)
                info_left.markdown(f"<div class='box'><div class='box-title'>Profile summary</div><div class='body' style='margin-top:.5rem'>{escape(text(focus_candidate.get('summary'), 'No summary was extracted from this file yet.'))}</div></div>", unsafe_allow_html=True)
                info_right.markdown(f"<div class='box'><div class='box-title'>Skills</div><div style='margin-top:.6rem'>{chips(items(focus_candidate.get('skills')), 'good', 'Skills not detected')}</div></div>", unsafe_allow_html=True)
                info_left.markdown(f"<div class='box'><div class='box-title'>Education</div><div class='body' style='margin-top:.5rem'>{escape(', '.join(items(focus_candidate.get('education'))) or 'Not detected')}</div></div>", unsafe_allow_html=True)
                info_right.markdown(f"<div class='box'><div class='box-title'>Projects</div><div class='body' style='margin-top:.5rem'>{escape(' | '.join(items(focus_candidate.get('projects'))[:4]) or 'No project details detected')}</div></div>", unsafe_allow_html=True)

                if active_ranking:
                    insight_left, insight_right = st.columns(2)
                    insight_left.markdown("<div class='box'><div class='box-title'>Why selected</div><ul class='bullet-list'>" + "".join(f"<li>{escape(item)}</li>" for item in items(focus_insight.get("why_selected") or active_ranking.get("why_selected"))[:5]) + "</ul></div>", unsafe_allow_html=True)
                    insight_right.markdown("<div class='box'><div class='box-title'>Missing skills</div><ul class='bullet-list'>" + "".join(f"<li>{escape(item)}</li>" for item in items(focus_insight.get('missing_skills') or active_ranking.get('breakdown', {}).get('missing_must_have_skills'))[:5]) + "</ul></div>", unsafe_allow_html=True)
                    insight_left.markdown("<div class='box'><div class='box-title'>What still needs validation</div><ul class='bullet-list'>" + "".join(f"<li>{escape(item)}</li>" for item in items(focus_insight.get('why_not_selected') or active_ranking.get('why_not_selected'))[:5]) + "</ul></div>", unsafe_allow_html=True)
                    insight_right.markdown("<div class='box'><div class='box-title'>Interview focus</div><ul class='bullet-list'>" + "".join(f"<li>{escape(item)}</li>" for item in items(focus_insight.get('interview_focus') or active_ranking.get('interview_focus'))[:5]) + "</ul></div>", unsafe_allow_html=True)

            with detail_right:
                st.markdown("<div class='box'><div class='box-title'>Profile actions</div></div>", unsafe_allow_html=True)
                show_detail_notice(focus_candidate["candidate_id"])
                replacement = st.file_uploader(
                    "Add resume",
                    type=UPLOAD_TYPES,
                    key=f"replace_{focus_candidate['candidate_id']}",
                    label_visibility="collapsed",
                )
                action_left, action_right = st.columns(2)
                if action_left.button("Add resume", key=f"replace_button_{focus_candidate['candidate_id']}", use_container_width=True):
                    if not replacement:
                        set_detail_notice("warning", f"Choose a resume file first for {focus_candidate['name']}.", focus_candidate["candidate_id"])
                    else:
                        try:
                            result = api_post(
                                f"/candidates/{focus_candidate['candidate_id']}/resume",
                                files=[("file", (replacement.name, replacement.getvalue(), replacement.type or "application/octet-stream"))],
                            )
                            set_detail_notice("success", text(result.get("message"), "Candidate profile refreshed."), focus_candidate["candidate_id"])
                        except APIRequestError as exc:
                            set_detail_notice("error", str(exc), focus_candidate["candidate_id"])
                    st.rerun()
                if action_right.button("Remove candidate", key=f"delete_button_{focus_candidate['candidate_id']}", use_container_width=True):
                    try:
                        result = api_delete(f"/candidates/{focus_candidate['candidate_id']}")
                        push_flash("success", text(result.get("message"), "Candidate removed."))
                    except APIRequestError as exc:
                        push_flash("error", str(exc))
                    st.rerun()

                if selected_job_id and rankings:
                    verification = verification_payload.get("verification_summary", {})
                    role_packet = candidate_packet.get("verification", {}) if isinstance(candidate_packet, dict) else {}
                    role_state = (role_packet.get("role_statuses") or {}).get(selected_job_id, {})
                    verification_status = text(role_state.get("verification_status"), "pending").replace("_", " ").title()
                    checks = verification.get("checks") or []
                    risk_flags = items(verification.get("risk_flags"))
                    proof_metrics = [
                        ("Skill proof files", verification.get("skill_proof_documents_count", 0)),
                        ("Education files", verification.get("education_proof_documents_count", 0)),
                        ("Photo", "Yes" if verification.get("profile_photo_uploaded") else "No"),
                    ]
                    verification_html = (
                        f"<div class='box'><div class='box-title'>Verification review</div><div class='muted'>Status {escape(verification_status)} | Proof score {pct(verification.get('verification_score', 0.0))}%</div>"
                        + "<div class='metrics'>"
                        + "".join(
                            f"<div class='metric'><div class='eyebrow'>{escape(label)}</div><div class='metric-value'>{value}</div></div>"
                            for label, value in proof_metrics
                        )
                        + "</div>"
                        f"<div style='margin-top:.7rem'>{chips(items(verification.get('verified_skills')), 'good', 'No verified skills yet')}</div>"
                        "<div class='section'>Open checks</div>"
                        f"<div>{chips(items(verification.get('unverified_skills')) + items(verification.get('pending_education')) + items(verification.get('pending_certifications')), 'risk', 'No open verification gaps')}</div>"
                    )
                    if text(role_state.get("verification_notes")):
                        verification_html += f"<div class='section'>Latest verification note</div><div class='body'>{escape(text(role_state.get('verification_notes')))}</div>"
                    if checks:
                        verification_html += "<div class='section'>Verification checks</div><ul class='bullet-list'>" + "".join(
                            f"<li>{escape(text(check.get('label')))}: {escape(text(check.get('detail')))}</li>" for check in checks[:5]
                        ) + "</ul>"
                    if risk_flags:
                        verification_html += "<div class='section'>Risk flags</div><ul class='bullet-list'>" + "".join(
                            f"<li>{escape(flag)}</li>" for flag in risk_flags[:5]
                        ) + "</ul>"
                    verification_html += "</div>"
                    st.markdown(verification_html, unsafe_allow_html=True)
                    if candidate_documents:
                        st.markdown("<div class='box'><div class='box-title'>Candidate documents</div></div>", unsafe_allow_html=True)
                        for document in candidate_documents[:8]:
                            st.markdown(
                                f"<div class='review'><strong>{escape(text(document.get('title'), document.get('file_name')))}</strong><br><span class='muted'>{escape(text(document.get('document_type')).replace('_', ' ').title())} | {escape(full_time(document.get('uploaded_at')))}</span><div class='body' style='margin-top:.45rem'>{escape(', '.join(items(document.get('tags'))) or 'No tags')}</div></div>",
                                unsafe_allow_html=True,
                            )
                    else:
                        st.info("No candidate-uploaded documents are attached to this role yet.")
                    with st.form(f"verification_review_form_{focus_candidate['candidate_id']}_{selected_job_id}", clear_on_submit=True):
                        verification_note = st.text_area(
                            "Verification note",
                            height=90,
                            placeholder="Explain why the documents were verified or why the candidate needs to upload clearer proof.",
                        )
                        review_decision = st.selectbox("Decision", ["verified", "rejected"], format_func=lambda value: value.title())
                        submit_verification = st.form_submit_button("Save verification review", use_container_width=True)
                    if submit_verification:
                        try:
                            result = api_post(
                                f"/candidates/{focus_candidate['candidate_id']}/verification/review",
                                json_payload={
                                    "job_id": selected_job_id,
                                    "decision": review_decision,
                                    "reviewer": text(auth_session.get("admin_name"), "Recruiter"),
                                    "notes": verification_note,
                                },
                            )
                            set_detail_notice("success", text(result.get("message"), "Verification updated."), focus_candidate["candidate_id"])
                        except APIRequestError as exc:
                            set_detail_notice("error", str(exc), focus_candidate["candidate_id"])
                        st.rerun()
                    st.markdown("<div class='box'><div class='box-title'>Candidate conversation</div></div>", unsafe_allow_html=True)
                    if candidate_conversations:
                        for entry in candidate_conversations[-6:]:
                            st.markdown(
                                f"<div class='review'><strong>{escape(text(entry.get('sender_name')))}</strong><br><span class='muted'>{escape(full_time(entry.get('created_at')))} | {escape(text(entry.get('sender_type')).title())}</span><div class='body' style='margin-top:.45rem'>{escape(text(entry.get('message')))}</div></div>",
                                unsafe_allow_html=True,
                            )
                    else:
                        st.info("No candidate conversation has been started for this role yet.")
                    with st.form(f"company_reply_form_{focus_candidate['candidate_id']}_{selected_job_id}", clear_on_submit=True):
                        reply_body = st.text_area(
                            "Reply to candidate",
                            height=90,
                            placeholder="Share a recruiter update, ask for clarification, or confirm next steps.",
                        )
                        send_reply = st.form_submit_button("Send reply", use_container_width=True)
                    if send_reply:
                        try:
                            result = api_post(
                                f"/candidates/{focus_candidate['candidate_id']}/conversations",
                                json_payload={
                                    "role_id": selected_job_id,
                                    "author": text(auth_session.get("admin_name"), "Recruiter"),
                                    "message": reply_body,
                                },
                            )
                            set_detail_notice("success", text(result.get("message"), "Reply sent to the candidate."), focus_candidate["candidate_id"])
                        except APIRequestError as exc:
                            set_detail_notice("error", str(exc), focus_candidate["candidate_id"])
                        st.rerun()
                    st.markdown("<div class='box'><div class='box-title'>Current shortlist</div></div>", unsafe_allow_html=True)
                    for item in rankings[: min(max(int(selected_job.get('hiring_target', 1) or 1), 1) + 1, len(rankings))]:
                        st.markdown(
                            f"<div class='box'><div class='eyebrow'>Rank #{item['rank']}</div><div class='box-title'>{escape(text(item['candidate'].get('name')))}</div><div class='muted'>{escape(text(item['candidate'].get('current_title'), 'Candidate profile'))}</div><div style='margin-top:.45rem'><strong>{pct(item.get('breakdown', {}).get('total_score'))}%</strong> match | <strong>{pct(item.get('breakdown', {}).get('confidence_score'))}%</strong> confidence</div></div>",
                            unsafe_allow_html=True,
                        )
                elif selected_job_id:
                    st.info("Candidate rankings will appear here once resumes are available.")

if current_view == "Roles":
    left, right = st.columns([1.1, 0.9])
    template_choice = st.selectbox("Role template", ["Current role"] + list(ROLE_TEMPLATES.keys()))
    defaults = (selected_job or {}) if template_choice == "Current role" else ROLE_TEMPLATES[template_choice]
    with left:
        st.markdown("<div class='box'><div class='box-title'>Role details</div></div>", unsafe_allow_html=True)
        with st.form("role_form"):
            title = st.text_input("Role title", value=text(defaults.get("title")))
            team = st.text_input("Team", value=text(defaults.get("team")))
            location = st.text_input("Location", value=text(defaults.get("location")))
            employment_type = st.text_input("Employment type", value=text(defaults.get("employment_type"), "Full-time"))
            hiring_target = st.number_input("Hiring target", min_value=1, value=max(int(defaults.get("hiring_target", 1) or 1), 1), step=1)
            min_years = st.number_input("Minimum experience", min_value=0.0, value=float(defaults.get("min_years_experience", 0.0) or 0.0), step=0.5)
            education_options = ["Flexible", "Bachelors", "Masters", "PhD"]
            education_choice = text(defaults.get("education_requirement"), "Flexible")
            if education_choice not in education_options:
                education_choice = "Flexible"
            education = st.selectbox("Education preference", education_options, index=education_options.index(education_choice))
            description = st.text_area("Role summary", value=text(defaults.get("description")), height=170)
            must_have = st.text_area("Must-have skills", value=", ".join(items(defaults.get("must_have_skills"))), height=90)
            nice_to_have = st.text_area("Nice-to-have skills", value=", ".join(items(defaults.get("nice_to_have_skills"))), height=80)
            responsibilities = st.text_area("Responsibilities", value="\n".join(items(defaults.get("responsibilities"))), height=100)
            save_role = st.form_submit_button("Save role", use_container_width=True)
        if save_role:
            try:
                result = api_post(
                    "/jobs",
                    json_payload={
                        "title": title,
                        "team": team or None,
                        "location": location or None,
                        "employment_type": employment_type or None,
                        "description": description,
                        "must_have_skills": split_csv(must_have),
                        "nice_to_have_skills": split_csv(nice_to_have),
                        "responsibilities": split_lines(responsibilities),
                        "hiring_target": int(hiring_target),
                        "min_years_experience": min_years,
                        "education_requirement": None if education == "Flexible" else education,
                    },
                )
                st.session_state["selected_job_id"] = result.get("job_id")
                push_flash("success", text(result.get("message"), "Role saved successfully."))
            except APIRequestError as exc:
                push_flash("error", str(exc))
            st.rerun()

    with right:
        if template_choice != "Current role":
            st.markdown(
                f"<div class='box'><div class='box-title'>{escape(template_choice)}</div><div class='body' style='margin-top:.5rem'>{escape(text(defaults.get('description')))}</div><div style='margin-top:.7rem'>{chips(items(defaults.get('must_have_skills')), 'good', 'No must-have skills')}</div></div>",
                unsafe_allow_html=True,
            )
        st.markdown("<div class='box'><div class='box-title'>Role document</div></div>", unsafe_allow_html=True)
        role_file = st.file_uploader("Role document", type=UPLOAD_TYPES, key="role_upload", label_visibility="collapsed")
        if st.button("Upload role document", use_container_width=True):
            if not role_file:
                push_flash("warning", "Choose a role document first.")
            else:
                try:
                    result = api_post("/jobs/uploads", files=[("file", (role_file.name, role_file.getvalue(), role_file.type or "application/octet-stream"))])
                    st.session_state["selected_job_id"] = result.get("job_id")
                    push_flash("success", text(result.get("message"), "Role document uploaded."))
                except APIRequestError as exc:
                    push_flash("error", str(exc))
            st.rerun()
        if selected_job:
            st.markdown(f"<div class='box'><div class='eyebrow'>Current role</div><div class='box-title'>{escape(selected_job['title'])}</div><div class='muted'>{escape(text(selected_job.get('team'), 'Team not specified'))}</div><div style='margin-top:.7rem'>{chips(items(selected_job.get('must_have_skills')), 'good', 'No must-have skills')}</div><div class='muted' style='margin-top:.7rem'>Hiring target {max(int(selected_job.get('hiring_target', 1) or 1), 1)} | Updated {escape(full_time(selected_job.get('last_updated')))}</div></div>", unsafe_allow_html=True)
            if st.button("Remove role", use_container_width=True):
                try:
                    result = api_delete(f"/jobs/{selected_job['job_id']}")
                    st.session_state["selected_job_id"] = None
                    push_flash("success", text(result.get("message"), "Role removed."))
                except APIRequestError as exc:
                    push_flash("error", str(exc))
                st.rerun()
        else:
            st.info("Create a role from the form or upload a job brief to start matching candidates.")

if current_view == "Shortlist":
    if not selected_job:
        st.info("Select or create a role to view match scores, shortlist movement, and decision support.")
    else:
        distribution = insights.get("fit_distribution", {})
        shortlist = insights.get("shortlist", [])
        stability_overview = insights.get("stability_overview", {})
        hiring_target = max(int(selected_job.get("hiring_target", insights.get("hiring_target", 1) or 1)), 1)
        stat_cols = st.columns(4)
        stat_cols[0].metric("Open seats", hiring_target)
        stat_cols[1].metric("Excellent", distribution.get("excellent", 0))
        stat_cols[2].metric("Strong", distribution.get("strong", 0))
        stat_cols[3].metric("Average score", f"{pct(insights.get('average_score', 0.0))}%")
        outlook_left, outlook_right = st.columns([1.1, 0.9])
        with outlook_left:
            st.markdown(f"<div class='box'><div class='box-title'>Shortlist outlook</div><div class='muted'>{escape(text(insights.get('headline'), 'No shortlist insight is available yet.'))}</div><div style='margin-top:.75rem'>{chips([text(insights.get('top_candidate', {}).get('name'), 'No lead candidate yet'), text(insights.get('top_candidate', {}).get('decision_signal'), 'Decision guidance appears here')], 'good', 'No lead candidate yet')}</div></div>", unsafe_allow_html=True)
            st.markdown("<div class='box'><div class='box-title'>Recommended next steps</div><ul>" + "".join(f"<li>{escape(item)}</li>" for item in items(insights.get("recommendations"))[:5]) + "</ul></div>", unsafe_allow_html=True)
            st.markdown("<div class='box'><div class='box-title'>Watchouts</div><ul>" + "".join(f"<li>{escape(item)}</li>" for item in items(insights.get("risk_register"))[:5]) + "</ul></div>", unsafe_allow_html=True)
        with outlook_right:
            timeline_html = "".join(f"<div class='timeline-item'><div>{escape(text(event.get('message'), 'Recent update'))}</div><div class='muted small'>{escape(clock(event.get('timestamp')))}</div></div>" for event in recruiter_events[:8]) or "<div class='muted'>New uploads and recruiter notes appear here automatically.</div>"
            st.markdown("<div class='box'><div class='box-title'>Recent activity</div><div class='timeline'>" + timeline_html + "</div></div>", unsafe_allow_html=True)
            st.markdown(
                "<div class='box'><div class='box-title'>Ranking stability</div>"
                f"<div class='muted'>Average shortlist stability: {pct(stability_overview.get('average_stability', 0.0))}%</div>"
                f"<div class='muted' style='margin-top:.45rem'>High-confidence candidates: {int(stability_overview.get('high_confidence_candidates', 0))}</div>"
                + (
                    "<ul>" + "".join(f"<li>{escape(item)}</li>" for item in items(stability_overview.get("volatile_candidates"))[:4]) + "</ul>"
                    if items(stability_overview.get("volatile_candidates"))
                    else "<div class='muted' style='margin-top:.65rem'>No unusually volatile candidates in the current shortlist.</div>"
                )
                + "</div>",
                unsafe_allow_html=True,
            )
        if shortlist:
            shortlist_html = "".join(
                f"<div class='metric'><div class='eyebrow'>Rank #{item['rank']}</div><div class='box-title'>{escape(text(item.get('name')))}</div><div class='muted'>{escape(text(item.get('decision_signal')))}</div><div style='margin-top:.5rem'><strong>{pct(item.get('score'))}%</strong> match | <strong>{pct(item.get('confidence_score'))}%</strong> confidence</div></div>"
                for item in shortlist[:hiring_target]
            )
            st.markdown(f"<div class='box'><div class='box-title'>Recommended shortlist</div><div class='muted'>Top {hiring_target} candidates for the current hiring plan.</div><div class='metrics' style='margin-top:1rem'>" + shortlist_html + "</div></div>", unsafe_allow_html=True)
        st.markdown(fit_matrix(selected_job, rankings), unsafe_allow_html=True)

        group_rows = insights.get("skill_group_coverage", [])
        if group_rows:
            st.markdown(skill_family_coverage(group_rows), unsafe_allow_html=True)

        if len(rankings) >= 2:
            compare_options = {f"{item['candidate']['name']} (#{item['rank']})": item["candidate"]["candidate_id"] for item in rankings[:6]}
            labels = list(compare_options.keys())
            compare_left, compare_right = st.columns(2)
            left_label = compare_left.selectbox("Compare candidate A", labels, key="compare_left")
            right_label = compare_right.selectbox("Compare candidate B", labels, index=1 if len(labels) > 1 else 0, key="compare_right")
            if compare_options[left_label] != compare_options[right_label]:
                try:
                    comparison = api_get(f"/jobs/{selected_job_id}/compare?left_candidate_id={compare_options[left_label]}&right_candidate_id={compare_options[right_label]}")
                    winner = comparison.get("winner", {})
                    runner = comparison.get("runner_up", {})
                    st.markdown(
                        "<div class='box'>"
                        f"<div class='box-title'>Candidate comparison</div><div class='muted'>{escape(text(comparison.get('recommendation'), 'Comparison unavailable.'))}</div>"
                        f"<div style='margin-top:.8rem'><strong>{escape(text(winner.get('name'), 'Lead candidate'))}</strong> | {pct(winner.get('score'))}%</div><ul>"
                        + "".join(f"<li>{escape(item)}</li>" for item in items(winner.get("reasons"))[:4])
                        + "</ul>"
                        f"<div style='margin-top:.65rem'><strong>{escape(text(runner.get('name'), 'Runner-up'))}</strong> | {pct(runner.get('score'))}%</div><ul>"
                        + "".join(f"<li>{escape(item)}</li>" for item in items(runner.get("tradeoffs"))[:4])
                        + "</ul></div>",
                        unsafe_allow_html=True,
                    )
                except APIRequestError as exc:
                    st.error(str(exc))

        st.markdown("<div class='box'><div class='box-title'>What-if analysis</div><div class='muted'>Adjust role requirements and preview how the shortlist would move before changing the live role.</div></div>", unsafe_allow_html=True)
        preview_must_have = st.text_area(
            "Adjusted must-have skills",
            value=", ".join(items(selected_job.get("must_have_skills"))),
            height=90,
            key="preview_must_have",
        )
        preview_nice = st.text_area(
            "Adjusted nice-to-have skills",
            value=", ".join(items(selected_job.get("nice_to_have_skills"))),
            height=80,
            key="preview_nice",
        )
        preview_years = st.number_input(
            "Adjusted minimum experience",
            min_value=0.0,
            value=float(selected_job.get("min_years_experience", 0.0) or 0.0),
            step=0.5,
            key="preview_years",
        )
        if st.button("Preview ranking impact", use_container_width=True):
            try:
                preview = api_post(
                    f"/jobs/{selected_job_id}/simulate",
                    json_payload={
                        "title": selected_job.get("title"),
                        "team": selected_job.get("team"),
                        "location": selected_job.get("location"),
                        "employment_type": selected_job.get("employment_type"),
                        "description": selected_job.get("description"),
                        "must_have_skills": split_csv(preview_must_have),
                        "nice_to_have_skills": split_csv(preview_nice),
                        "responsibilities": items(selected_job.get("responsibilities")),
                        "hiring_target": hiring_target,
                        "min_years_experience": preview_years,
                        "education_requirement": selected_job.get("education_requirement"),
                    },
                )
                st.session_state["scenario_preview"] = preview
            except APIRequestError as exc:
                push_flash("error", str(exc))
                st.session_state.pop("scenario_preview", None)
            st.rerun()
        preview = st.session_state.get("scenario_preview")
        if preview and selected_job_id:
            st.markdown(f"**Projected outcome**  \n{preview.get('headline', 'No scenario summary available.')}")
            projected = preview.get("changes") or []
            if projected:
                st.write("\n".join(
                    f"- {item['name']}: {('#' + str(item['previous_rank'])) if item.get('previous_rank') else 'new'} -> #{item['projected_rank']}"
                    for item in projected[:5]
                ))
            else:
                st.write("No major ranking position changes are projected for this scenario.")

if current_view == "About":
    st.markdown(
        "<div class='box'><div class='box-title'>How PulseHire helps recruiters</div><div class='body' style='margin-top:.55rem'>PulseHire is designed to help hiring teams move from role setup to shortlist decisions with live evidence. Recruiters can define roles, review ranked candidates, validate proof documents, compare finalists, and send decisions back to candidates without losing context between steps.</div></div>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<div class='section-grid'>"
        "<div class='metric'><div class='eyebrow'>Match scoring</div><div class='body'>Every role score is built from retrieval evidence, must-have fit, experience fit, education fit, and recruiter review signals.</div></div>"
        "<div class='metric'><div class='eyebrow'>Verification review</div><div class='body'>Skill proof, education proof, profile image, and unmatched documents are checked together so hiring teams know what is supported and what still needs validation.</div></div>"
        "<div class='metric'><div class='eyebrow'>Decision support</div><div class='body'>PulseHire highlights why a candidate is high on the list, what is missing, and what the interviewer should probe next.</div></div>"
        "</div>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<div class='box'><div class='box-title'>How match score is calculated</div><div class='table-wrap'><table><thead><tr><th>Signal</th><th>What it measures</th><th>How PulseHire checks it</th></tr></thead><tbody>"
        "<tr><td>Retrieval evidence</td><td>How strongly the resume supports the role brief.</td><td>Resume evidence is compared to the role using semantic, lexical, and structured retrieval signals.</td></tr>"
        "<tr><td>Must-have fit</td><td>Coverage of required skills.</td><td>Each must-have skill is checked against the candidate's normalized skill set and grouped skill families.</td></tr>"
        "<tr><td>Experience fit</td><td>How close the candidate is to the role's expected experience level.</td><td>Years of experience and role-relevant highlights are compared to the target requirement.</td></tr>"
        "<tr><td>Education fit</td><td>Whether the role's education preference is met.</td><td>Extracted education records are matched against the role's degree preference.</td></tr>"
        "<tr><td>Recruiter signal</td><td>How recruiter reviews influence the shortlist.</td><td>Saved recruiter reviews such as shortlist, interview recommended, hold, and reject are applied as live ranking signals.</td></tr>"
        "</tbody></table></div></div>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<div class='box'><div class='box-title'>How verification works</div><ul class='bullet-list'>"
        "<li>Profile photo checks whether the candidate attached an identity photo for the application.</li>"
        "<li>Skill proof checks whether uploaded certificates or tagged supporting files match claimed skills on the profile.</li>"
        "<li>Education proof checks whether education documents support the visible education claims.</li>"
        "<li>Certificate proof checks whether certification claims have matching uploaded evidence.</li>"
        "<li>Mismatch flags identify uploaded files whose tags do not map to any visible claim, so recruiters know what still needs manual review.</li>"
        "</ul></div>",
        unsafe_allow_html=True,
    )

if current_view == "Analytics":
    if not selected_job_id:
        st.info("Select a role first to open role-specific analytics.")
    else:
        role_packets = []
        for candidate in company_candidates:
            try:
                role_packets.append(api_get(f"/ats/jobs/{selected_job_id}/candidates/{candidate['candidate_id']}/packet"))
            except APIRequestError:
                continue
        role_feedback_entries = [entry for entry in feedback_entries if text(entry.get("job_id")) == selected_job_id]
        verified_packets = []
        pending_packets = []
        rejected_packets = []
        proof_scores: list[float] = []
        visible_scores: list[float] = []
        for packet in role_packets:
            verification_state = ((packet.get("verification", {}) or {}).get("role_statuses", {}) or {}).get(selected_job_id, {})
            decision = text(verification_state.get("verification_status"), "pending")
            proof_summary = ((packet.get("verification", {}) or {}).get("verification_summary") or {})
            proof_score = float(proof_summary.get("verification_score", 0.0) or 0.0)
            proof_scores.append(proof_score)
            if decision == "verified":
                verified_packets.append(packet)
                visible_scores.append(float((packet.get("ranking") or {}).get("breakdown", {}).get("total_score", 0.0) or 0.0))
            elif decision == "rejected":
                rejected_packets.append(packet)
            else:
                pending_packets.append(packet)
        profiles_with_photo = sum(1 for packet in role_packets if ((packet.get("verification", {}) or {}).get("profile_photo_document_id")))
        docs_attached = sum(1 for packet in role_packets if len((packet.get("verification", {}) or {}).get("document_ids", [])) > 0)
        open_proof_gaps = 0
        for packet in role_packets:
            verification_state = ((packet.get("verification", {}) or {}).get("role_statuses", {}) or {}).get(selected_job_id, {})
            if text(verification_state.get("verification_status"), "pending") != "verified":
                open_proof_gaps += 1
        metric_cols = st.columns(5)
        metric_cols[0].metric("Applicants", len(company_candidates))
        metric_cols[1].metric("Verified", len(verified_packets))
        metric_cols[2].metric("Pending review", len(pending_packets))
        metric_cols[3].metric("Rejected proof", len(rejected_packets))
        metric_cols[4].metric("Recruiter reviews", len(role_feedback_entries))
        insight_left, insight_right = st.columns([1.0, 1.0])
        with insight_left:
            st.markdown("<div class='box'><div class='box-title'>Verification health</div></div>", unsafe_allow_html=True)
            st.markdown(
                "<div class='metrics'>"
                + "".join(
                    f"<div class='metric'><div class='eyebrow'>{escape(label)}</div><div class='metric-value'>{value}</div><div class='muted'>{escape(note)}</div></div>"
                    for label, value, note in [
                        ("Average proof", f"{pct(sum(proof_scores) / len(proof_scores)) if proof_scores else 0}%", "Across this role"),
                        ("Profiles with photo", profiles_with_photo, "Role-linked applications"),
                        ("Docs attached", docs_attached, "Application packets"),
                    ]
                )
                + "</div>",
                unsafe_allow_html=True,
            )
        with insight_right:
            st.markdown("<div class='box'><div class='box-title'>Decision readiness</div></div>", unsafe_allow_html=True)
            st.markdown(
                "<div class='metrics'>"
                + "".join(
                    f"<div class='metric'><div class='eyebrow'>{escape(label)}</div><div class='metric-value'>{value}</div><div class='muted'>{escape(note)}</div></div>"
                    for label, value, note in [
                        ("Shortlist ready", sum(1 for item in rankings if item.get("fit_band") in {"excellent", "strong"}), "Current ranking"),
                        ("Average released score", f"{pct(sum(visible_scores) / len(visible_scores)) if visible_scores else 0}%", "Only verified profiles"),
                        ("Open proof gaps", open_proof_gaps, "Still awaiting review"),
                    ]
                )
                + "</div>",
                unsafe_allow_html=True,
            )
        st.markdown("<div class='box'><div class='box-title'>Role analytics</div></div>", unsafe_allow_html=True)
        if role_packets:
            role_rows = []
            for packet in role_packets:
                verification_state = ((packet.get("verification", {}) or {}).get("role_statuses", {}) or {}).get(selected_job_id, {})
                visible_match = "Hidden until verified"
                if text(verification_state.get("verification_status")) == "verified":
                    visible_match = f"{pct((packet.get('ranking') or {}).get('breakdown', {}).get('total_score', 0.0))}%"
                role_rows.append(
                    "<tr>"
                    f"<td>{escape(text(packet.get('candidate', {}).get('name')))}</td>"
                    f"<td>{escape(text(verification_state.get('verification_status'), 'pending').replace('_', ' ').title())}</td>"
                    f"<td>{len((packet.get('verification', {}) or {}).get('document_ids', []))}</td>"
                    f"<td>{sum(1 for entry in role_feedback_entries if text(entry.get('candidate_id')) == text(packet.get('candidate', {}).get('candidate_id')))}</td>"
                    f"<td>{escape(visible_match)}</td>"
                    "</tr>"
                )
            st.markdown(
                "<div class='table-wrap'><table><thead><tr><th>Candidate</th><th>Verification</th><th>Documents</th><th>Reviews</th><th>Released score</th></tr></thead><tbody>"
                + "".join(role_rows)
                + "</tbody></table></div>",
                unsafe_allow_html=True,
            )
        else:
            st.info("No role-scoped candidates are available yet for this role.")

if current_view == "Reviews":
    left, right = st.columns([1.05, 0.95])
    with left:
        st.markdown("<div class='box'><div class='box-title'>Add review</div></div>", unsafe_allow_html=True)
        with st.form("feedback_form", clear_on_submit=True):
            reviewer_name = st.text_input("Reviewer name", value=text(st.session_state.get("reviewer_name")))
            candidate_label = st.selectbox("Candidate", list(candidate_options.keys()) if candidate_options else ["No candidates available"], disabled=not bool(candidate_options))
            role_labels = list(role_options.keys())
            default_role_index = 0
            if selected_job_id:
                selected_label = next((label for label, job_id in role_options.items() if job_id == selected_job_id), None)
                if selected_label in role_labels:
                    default_role_index = role_labels.index(selected_label)
            role_label = st.selectbox("Role", role_labels, index=default_role_index)
            review_label = st.selectbox("Recommendation", list(REVIEW_OPTIONS.keys()))
            notes = st.text_area("Reviewer notes", height=130, placeholder="What stood out? What should the next interviewer focus on?")
            save_review = st.form_submit_button("Save review", use_container_width=True)
        if save_review:
            if not candidate_options:
                push_flash("warning", "Add at least one candidate before saving a review.")
            else:
                st.session_state["reviewer_name"] = reviewer_name
                try:
                    result = api_post("/feedback", json_payload={"candidate_id": candidate_options[candidate_label], "job_id": role_options[role_label] or None, "recruiter": reviewer_name or None, "label": REVIEW_OPTIONS[review_label], "notes": notes})
                    push_flash("success", text(result.get("message"), "Review saved."))
                except APIRequestError as exc:
                    push_flash("error", str(exc))
            st.rerun()
    with right:
        st.markdown("<div class='box'><div class='box-title'>Hiring question</div></div>", unsafe_allow_html=True)
        question = st.text_area(
            "Question",
            key="shortlist_question_input",
            placeholder="Example: Why is the current top candidate leading? What changed in the shortlist?",
            height=110,
            label_visibility="collapsed",
        )
        current_question = question.strip()
        if st.session_state.get("answer_question") and current_question != st.session_state.get("answer_question"):
            st.session_state.pop("answer_payload", None)
        if st.button("Ask shortlist", use_container_width=True):
            if not selected_job_id:
                push_flash("warning", "Select a role before asking for shortlist reasoning.")
                clear_shortlist_answer()
            elif not current_question:
                push_flash("warning", "Enter a hiring question first.")
                clear_shortlist_answer()
            else:
                try:
                    st.session_state["answer_payload"] = api_post(
                        f"/jobs/{selected_job_id}/ask",
                        json_payload={"question": current_question},
                    )
                    st.session_state["answer_question"] = current_question
                    st.session_state["answer_job_id"] = selected_job_id
                except APIRequestError as exc:
                    push_flash("error", str(exc))
                    clear_shortlist_answer()
            st.rerun()
        answer_payload = st.session_state.get("answer_payload", {})
        answer_job_id = st.session_state.get("answer_job_id")
        answer_question = st.session_state.get("answer_question")
        if selected_job_id and answer_payload and answer_job_id == selected_job_id and answer_question == current_question:
            st.markdown(f"<div class='box'><div class='eyebrow'>Answer</div><div class='body' style='margin-top:.45rem'>{escape(text(answer_payload.get('answer'), 'No answer available.'))}</div></div>", unsafe_allow_html=True)
            bullets = items(answer_payload.get("bullets"))
            if bullets:
                st.markdown("<div class='box'><div class='box-title'>Key points</div><ul>" + "".join(f"<li>{escape(item)}</li>" for item in bullets[:6]) + "</ul></div>", unsafe_allow_html=True)

    review_role_labels = ["All roles"] + list(job_labels.keys())
    review_filter_left, review_filter_right = st.columns(2)
    selected_review_job = review_filter_left.selectbox(
        "Review role filter",
        review_role_labels,
        format_func=lambda value: "All roles" if value == "All roles" else job_labels[value],
    )
    review_label_options = sorted({text(entry.get("label"), "neutral").replace("_", " ").title() for entry in feedback_entries})
    selected_review_labels = review_filter_right.multiselect("Recommendation filter", review_label_options, default=review_label_options)

    st.markdown("<div class='box'><div class='box-title'>Review history</div></div>", unsafe_allow_html=True)
    if not feedback_entries:
        st.info("Recruiter reviews will appear here once the team starts adding feedback.")
    else:
        visible_feedback = []
        for entry in feedback_entries:
            normalized_label = text(entry.get("label"), "neutral").replace("_", " ").title()
            if selected_review_job != "All roles" and text(entry.get("job_id")) != selected_review_job:
                continue
            if selected_review_labels and normalized_label not in selected_review_labels:
                continue
            visible_feedback.append(entry)

        if not visible_feedback:
            st.info("No recruiter reviews match the current filters.")

        for entry in visible_feedback[:10]:
            candidate_name = text(candidate_lookup.get(entry.get("candidate_id", ""), {}).get("name"), entry.get("candidate_id"))
            role_name = text(job_labels.get(entry.get("job_id", "")), "General review")
            label = text(entry.get("label"), "neutral").replace("_", " ").title()
            reviewer = text(entry.get("recruiter"), "Recruiter")
            review_card_col, review_action_col = st.columns([0.82, 0.18])
            review_card_col.markdown(
                f"<div class='review'><strong>{escape(candidate_name)}</strong> | {escape(role_name)}<br><span class='muted'>{escape(label)} | {escape(reviewer)} | {escape(full_time(entry.get('created_at')))}</span><div class='body' style='margin-top:.45rem'>{escape(text(entry.get('notes'), 'No note provided.'))}</div></div>",
                unsafe_allow_html=True,
            )
            if review_action_col.button("Remove review", key=f"remove_feedback_{entry['feedback_id']}", use_container_width=True):
                try:
                    result = api_delete(f"/feedback/{entry['feedback_id']}")
                    pending = set(st.session_state.get("pending_removed_feedback_ids", []))
                    pending.add(text(entry.get("feedback_id")))
                    st.session_state["pending_removed_feedback_ids"] = sorted(pending)
                    push_flash("success", text(result.get("message"), "Review removed."))
                except APIRequestError as exc:
                    push_flash("error", str(exc))
                st.rerun()
