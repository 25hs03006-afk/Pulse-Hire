from __future__ import annotations

import json
import logging
import threading
from typing import Any

from app.config import Settings
from app.models import CandidateProfile, FeedbackEntry, JobProfile
from app.services.datasets import sync_kaggle_datasets
from app.services.dataset_loader import ResumeDatasetLoader
from app.services.job_loader import JobDatasetLoader
from app.services.orchestrator import ScreeningOrchestrator
from app.services.parsers.extractors import parse_feedback_document
from app.services.state.store import RuntimeState

logger = logging.getLogger(__name__)


def _metadata_to_dict(metadata: Any) -> dict[str, Any]:
    if hasattr(metadata, "as_dict"):
        return metadata.as_dict()
    if isinstance(metadata, dict):
        return metadata
    return {}


def _envelope_success(payload_json: str, source_path: str, entity_kind: str) -> str:
    return json.dumps(
        {
            "ok": True,
            "entity_kind": entity_kind,
            "source_path": source_path,
            "payload": payload_json,
        }
    )


def _envelope_error(source_path: str, entity_kind: str, error: str) -> str:
    return json.dumps(
        {
            "ok": False,
            "entity_kind": entity_kind,
            "source_path": source_path,
            "error": error,
        }
    )


class PathwayRuntime:
    def __init__(self, settings: Settings, orchestrator: ScreeningOrchestrator, state: RuntimeState) -> None:
        self.settings = settings
        self.orchestrator = orchestrator
        self.state = state
        self._thread: threading.Thread | None = None
        self.resume_loader = ResumeDatasetLoader(settings=settings)
        self.job_loader = JobDatasetLoader(settings=settings)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._bootstrap, daemon=True, name="pathway-runtime")
        self._thread.start()

    def _bootstrap(self) -> None:
        self.state.set_pipeline_status("starting", {"message": "Bootstrapping Pathway runtime."})
        try:
            if self.settings.kaggle_auto_sync and self.settings.kaggle_username and self.settings.kaggle_key:
                sync_kaggle_datasets(settings=self.settings, preset_ids=["resume_text_primary", "resume_pdf_real", "job_descriptions"])
            self.resume_loader.sync_once()
            self.job_loader.sync_once()
        except Exception as exc:
            self.state.set_pipeline_status("error", {"message": f"Initial dataset sync failed: {exc}"})
            self.state.add_event(
                "pipeline_error",
                f"Initial dataset sync failed: {exc}",
                entity_kind="system",
                audience="system",
                severity="error",
            )
            logger.exception("Initial dataset sync failed")
            return
        self.resume_loader.start()
        self.job_loader.start()
        try:
            import pathway as pw
        except Exception as exc:
            self.state.set_pipeline_status("error", {"message": f"Pathway import failed: {exc}"})
            self.state.add_event("pipeline_error", f"Pathway import failed: {exc}", entity_kind="system", audience="system", severity="error")
            logger.exception("Pathway import failed")
            return

        try:
            resumes = pw.io.fs.read(
                path=str(self.settings.resume_stream_dir),
                format="binary",
                mode="streaming",
                with_metadata=True,
                refresh_interval=1,
            )
            jobs = pw.io.fs.read(
                path=str(self.settings.job_stream_dir),
                format="binary",
                mode="streaming",
                with_metadata=True,
                refresh_interval=1,
            )
            feedback = pw.io.fs.read(
                path=str(self.settings.feedback_dir),
                format="binary",
                mode="streaming",
                with_metadata=True,
                refresh_interval=1,
            )

            @pw.udf
            def to_candidate_payload(data: bytes, metadata: dict[str, Any]) -> str:
                metadata_dict = _metadata_to_dict(metadata)
                source_path = str(metadata_dict.get("path") or "candidate.json")
                try:
                    candidate = CandidateProfile.model_validate_json(data.decode("utf-8"))
                    return _envelope_success(candidate.model_dump_json(), source_path, "candidate")
                except Exception as exc:  # pragma: no cover - defensive runtime path
                    return _envelope_error(source_path, "candidate", str(exc))

            @pw.udf
            def to_job_payload(data: bytes, metadata: dict[str, Any]) -> str:
                metadata_dict = _metadata_to_dict(metadata)
                source_path = str(metadata_dict.get("path") or "job.json")
                try:
                    job = JobProfile.model_validate_json(data.decode("utf-8"))
                    return _envelope_success(job.model_dump_json(), source_path, "job")
                except Exception as exc:  # pragma: no cover - defensive runtime path
                    return _envelope_error(source_path, "job", str(exc))

            @pw.udf
            def to_feedback_payload(data: bytes, metadata: dict[str, Any]) -> str:
                metadata_dict = _metadata_to_dict(metadata)
                source_path = str(metadata_dict.get("path") or "feedback.pdf")
                try:
                    entries = parse_feedback_document(source_path, data, metadata_dict)
                    payload = json.dumps([entry.model_dump(mode="json") for entry in entries])
                    return _envelope_success(payload, source_path, "feedback")
                except Exception as exc:  # pragma: no cover - defensive runtime path
                    return _envelope_error(source_path, "feedback", str(exc))

            candidate_stream = resumes.select(payload=to_candidate_payload(pw.this.data, pw.this._metadata))
            job_stream = jobs.select(payload=to_job_payload(pw.this.data, pw.this._metadata))
            feedback_stream = feedback.select(payload=to_feedback_payload(pw.this.data, pw.this._metadata))

            pw.io.subscribe(candidate_stream, self._on_candidate_change)
            pw.io.subscribe(job_stream, self._on_job_change)
            pw.io.subscribe(feedback_stream, self._on_feedback_change)

            self.state.set_pipeline_status(
                "running",
                {
                    "resumes_dir": str(self.settings.resumes_dir),
                    "jobs_dir": str(self.settings.jobs_dir),
                    "feedback_dir": str(self.settings.feedback_dir),
                    "resume_stream_dir": str(self.settings.resume_stream_dir),
                    "job_stream_dir": str(self.settings.job_stream_dir),
                    "retrieval_backend": "hybrid semantic + lexical + structured reranking",
                    "message": "Pathway is continuously ingesting live folders and triggering revision-aware reranking.",
                },
            )
            self.state.add_event(
                "pipeline_running",
                "Pathway runtime is actively streaming resumes, jobs, and feedback.",
                entity_kind="system",
                audience="recruiter",
            )
            pw.run(monitoring_level=pw.MonitoringLevel.NONE)
        except Exception as exc:
            self.state.set_pipeline_status("error", {"message": str(exc)})
            self.state.add_event(
                "pipeline_error",
                f"Pathway runtime crashed: {exc}",
                entity_kind="system",
                audience="system",
                severity="error",
            )
            logger.exception("Pathway runtime crashed")

    def _decode_envelope(self, row: dict[str, Any]) -> dict[str, Any] | None:
        payload = row.get("payload")
        if not payload:
            return None
        try:
            return json.loads(payload)
        except json.JSONDecodeError:
            return None

    def _on_candidate_change(self, key: Any, row: dict[str, Any], time: int, is_addition: bool) -> None:
        envelope = self._decode_envelope(row)
        if not envelope:
            return
        source_path = envelope.get("source_path") or "resume.pdf"
        if not envelope.get("ok"):
            self.state.record_document_failure("candidate", str(source_path), str(envelope.get("error") or "Unknown parsing error"))
            return
        candidate = CandidateProfile.model_validate_json(envelope["payload"])
        if is_addition:
            self.orchestrator.handle_candidate_upsert(candidate)
        else:
            self.orchestrator.handle_candidate_remove(candidate.candidate_id)

    def _on_job_change(self, key: Any, row: dict[str, Any], time: int, is_addition: bool) -> None:
        envelope = self._decode_envelope(row)
        if not envelope:
            return
        source_path = envelope.get("source_path") or "job.pdf"
        if not envelope.get("ok"):
            self.state.record_document_failure("job", str(source_path), str(envelope.get("error") or "Unknown parsing error"))
            return
        job = JobProfile.model_validate_json(envelope["payload"])
        if is_addition:
            self.orchestrator.handle_job_upsert(job)
        else:
            self.orchestrator.handle_job_remove(job.job_id)

    def _on_feedback_change(self, key: Any, row: dict[str, Any], time: int, is_addition: bool) -> None:
        envelope = self._decode_envelope(row)
        if not envelope:
            return
        source_path = envelope.get("source_path") or "feedback.pdf"
        if not envelope.get("ok"):
            self.state.record_document_failure("feedback", str(source_path), str(envelope.get("error") or "Unknown parsing error"))
            return
        entries = [FeedbackEntry.model_validate(entry) for entry in json.loads(envelope["payload"])]
        if is_addition:
            self.orchestrator.handle_feedback_replace(str(source_path), entries)
        else:
            self.orchestrator.handle_feedback_remove(str(source_path))
