from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


def utc_now() -> datetime:
    return datetime.now(UTC)


class BaseDomainModel(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)


class ResumeEvidence(BaseDomainModel):
    snippet: str
    score: float = 0.0
    source_path: str | None = None
    section: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class CandidateProfile(BaseDomainModel):
    candidate_id: str
    name: str
    email: str | None = None
    phone: str | None = None
    location: str | None = None
    current_title: str | None = None
    summary: str = ""
    raw_text: str = ""
    skills: list[str] = Field(default_factory=list)
    skill_groups: dict[str, list[str]] = Field(default_factory=dict)
    certifications: list[str] = Field(default_factory=list)
    education: list[str] = Field(default_factory=list)
    experience_highlights: list[str] = Field(default_factory=list)
    projects: list[str] = Field(default_factory=list)
    years_experience: float = 0.0
    source_path: str
    source_name: str | None = None
    source_checksum: str | None = None
    source_version: int = 1
    completeness_score: float = 0.0
    duplicate_of: str | None = None
    duplicate_candidates: list[str] = Field(default_factory=list)
    last_updated: datetime = Field(default_factory=utc_now)


class JobProfile(BaseDomainModel):
    job_id: str
    title: str
    team: str | None = None
    location: str | None = None
    employment_type: str | None = None
    description: str = ""
    must_have_skills: list[str] = Field(default_factory=list)
    nice_to_have_skills: list[str] = Field(default_factory=list)
    skill_groups: dict[str, list[str]] = Field(default_factory=dict)
    responsibilities: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)
    hiring_target: int = 1
    min_years_experience: float = 0.0
    education_requirement: str | None = None
    source_path: str
    source_name: str | None = None
    source_checksum: str | None = None
    source_version: int = 1
    last_updated: datetime = Field(default_factory=utc_now)


class FeedbackEntry(BaseDomainModel):
    feedback_id: str
    candidate_id: str
    job_id: str | None = None
    recruiter: str | None = None
    label: str
    score_adjustment: float = 0.0
    notes: str = ""
    created_at: datetime = Field(default_factory=utc_now)
    source_path: str
    source_name: str | None = None
    source_version: int = 1


class RetrievalHit(BaseDomainModel):
    candidate_id: str
    rank: int
    score: float
    snippet: str
    source_path: str | None = None
    section: str | None = None
    matched_terms: list[str] = Field(default_factory=list)
    channel_scores: dict[str, float] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class RankingBreakdown(BaseDomainModel):
    retrieval_score: float = 0.0
    semantic_score: float = 0.0
    lexical_score: float = 0.0
    structured_score: float = 0.0
    must_have_score: float = 0.0
    nice_to_have_score: float = 0.0
    experience_score: float = 0.0
    education_score: float = 0.0
    keyword_score: float = 0.0
    recency_score: float = 0.0
    profile_quality_score: float = 0.0
    feedback_score: float = 0.0
    confidence_score: float = 0.0
    stability_score: float = 0.0
    grouped_skill_score: float = 0.0
    risk_penalty: float = 0.0
    total_score: float = 0.0
    matched_skills: list[str] = Field(default_factory=list)
    missing_must_have_skills: list[str] = Field(default_factory=list)
    matched_keywords: list[str] = Field(default_factory=list)
    missing_nice_to_have_skills: list[str] = Field(default_factory=list)
    matched_skill_groups: list[str] = Field(default_factory=list)
    missing_skill_groups: list[str] = Field(default_factory=list)


class CandidateRanking(BaseDomainModel):
    rank: int
    candidate: CandidateProfile
    breakdown: RankingBreakdown
    explanation: str
    evidence: list[ResumeEvidence] = Field(default_factory=list)
    score_delta: float = 0.0
    rank_delta: int = 0
    fit_band: Literal["excellent", "strong", "promising", "partial", "weak"] = "partial"
    strengths: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    interview_focus: list[str] = Field(default_factory=list)
    movement_summary: str = ""
    decision_signal: str = ""
    why_selected: list[str] = Field(default_factory=list)
    why_not_selected: list[str] = Field(default_factory=list)


class RankingSnapshot(BaseDomainModel):
    job_id: str
    generated_at: datetime = Field(default_factory=utc_now)
    source_revision: int = 0
    insight_summary: str = ""
    coverage_summary: dict[str, Any] = Field(default_factory=dict)
    rankings: list[CandidateRanking] = Field(default_factory=list)


class RecruiterQuestion(BaseDomainModel):
    question: str


class JobDraft(BaseDomainModel):
    title: str
    team: str | None = None
    location: str | None = None
    employment_type: str | None = None
    description: str
    must_have_skills: list[str] = Field(default_factory=list)
    nice_to_have_skills: list[str] = Field(default_factory=list)
    responsibilities: list[str] = Field(default_factory=list)
    hiring_target: int = 1
    min_years_experience: float = 0.0
    education_requirement: str | None = None


class FeedbackDraft(BaseDomainModel):
    candidate_id: str
    job_id: str | None = None
    recruiter: str | None = None
    label: str
    notes: str
    score_adjustment: float | None = None


class KaggleSyncRequest(BaseDomainModel):
    preset_ids: list[str] = Field(default_factory=list)
    dataset_slugs: list[str] = Field(default_factory=list)
    force: bool = False


class RecruiterAnswer(BaseDomainModel):
    answer: str
    bullets: list[str] = Field(default_factory=list)
    context: list[ResumeEvidence] = Field(default_factory=list)


class CompanyRegistration(BaseDomainModel):
    company_name: str
    admin_name: str
    email: str | None = None
    password: str


class LoginRequest(BaseDomainModel):
    company_name: str
    password: str


class AuthSession(BaseDomainModel):
    token: str
    workspace_id: str
    company_name: str
    admin_name: str
    email: str | None = None
    role: Literal["owner", "admin", "recruiter", "hiring_manager", "interviewer"] = "owner"
    issued_at: datetime = Field(default_factory=utc_now)
    expires_at: datetime = Field(default_factory=utc_now)


class CandidateRegistration(BaseDomainModel):
    full_name: str
    email: str
    password: str


class CandidateLoginRequest(BaseDomainModel):
    email: str
    password: str


class CandidateSession(BaseDomainModel):
    token: str
    candidate_account_id: str
    full_name: str
    email: str
    issued_at: datetime = Field(default_factory=utc_now)
    expires_at: datetime = Field(default_factory=utc_now)


class ATSRequisitionDraft(BaseDomainModel):
    job_id: str
    priority: Literal["low", "medium", "high", "critical"] = "medium"
    requested_headcount: int = 1
    requested_by: str | None = None
    hiring_manager: str | None = None
    budget_code: str | None = None
    stage_order: list[str] = Field(default_factory=list)
    notes: str | None = None


class CandidateStageDraft(BaseDomainModel):
    stage: str
    actor: str | None = None
    notes: str | None = None
    decision: str | None = None


class InterviewDraft(BaseDomainModel):
    job_id: str
    candidate_id: str
    stage: str
    interviewer: str
    scheduled_for: str
    mode: Literal["virtual", "onsite", "phone"] = "virtual"
    meeting_link: str | None = None
    agenda: list[str] = Field(default_factory=list)


class ScorecardDraft(BaseDomainModel):
    job_id: str
    candidate_id: str
    interviewer: str
    stage: str
    rubric_scores: dict[str, float] = Field(default_factory=dict)
    recommendation: Literal["strong_yes", "yes", "lean_yes", "hold", "lean_no", "no"] = "hold"
    strengths: list[str] = Field(default_factory=list)
    concerns: list[str] = Field(default_factory=list)
    notes: str = ""


class ApprovalDraft(BaseDomainModel):
    job_id: str
    approval_type: Literal["requisition", "shortlist", "offer"] = "requisition"
    requested_by: str
    approvers: list[str] = Field(default_factory=list)
    notes: str | None = None


class ApprovalSignoffDraft(BaseDomainModel):
    approver: str
    decision: Literal["approved", "rejected"]
    notes: str | None = None


class OfferDraft(BaseDomainModel):
    job_id: str
    candidate_id: str
    owner: str
    compensation: str
    status: Literal["draft", "sent", "accepted", "declined", "withdrawn"] = "draft"
    notes: str | None = None


class CollaborationCommentDraft(BaseDomainModel):
    job_id: str
    candidate_id: str | None = None
    author: str
    channel: Literal["role", "candidate", "offer"] = "candidate"
    message: str


class NotificationEntry(BaseDomainModel):
    notification_id: str
    audience_type: Literal["candidate", "company"] = "candidate"
    audience_id: str
    workspace_id: str | None = None
    application_id: str | None = None
    candidate_id: str | None = None
    role_id: str | None = None
    category: str
    title: str
    message: str
    severity: Literal["info", "success", "warning", "error"] = "info"
    read: bool = False
    created_at: datetime = Field(default_factory=utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)


class TimelineEvent(BaseDomainModel):
    event_id: str
    application_id: str
    candidate_account_id: str
    company_id: str
    company_candidate_id: str | None = None
    role_ids: list[str] = Field(default_factory=list)
    event_type: str
    title: str
    description: str
    created_at: datetime = Field(default_factory=utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)


class CandidateEducationEntry(BaseDomainModel):
    institution: str
    degree: str
    field: str | None = None
    start_year: str | None = None
    end_year: str | None = None
    grade: str | None = None


class CandidateExperienceEntry(BaseDomainModel):
    company: str
    title: str
    start_date: str | None = None
    end_date: str | None = None
    highlights: list[str] = Field(default_factory=list)


class CandidateProjectEntry(BaseDomainModel):
    name: str
    description: str
    technologies: list[str] = Field(default_factory=list)
    url: str | None = None


class CandidateCertificationEntry(BaseDomainModel):
    name: str
    issuer: str | None = None
    issued_on: str | None = None


class CandidateProfileDraft(BaseDomainModel):
    full_name: str
    email: str
    phone: str | None = None
    location: str | None = None
    headline: str | None = None
    summary: str = ""
    skills: list[str] = Field(default_factory=list)
    education: list[CandidateEducationEntry] = Field(default_factory=list)
    experience: list[CandidateExperienceEntry] = Field(default_factory=list)
    projects: list[CandidateProjectEntry] = Field(default_factory=list)
    certifications: list[CandidateCertificationEntry] = Field(default_factory=list)
    profile_photo_document_id: str | None = None


class CandidateApplicationDraft(BaseDomainModel):
    company_id: str
    role_ids: list[str] = Field(default_factory=list)
    resume_mode: Literal["upload", "builder"]
    profile: CandidateProfileDraft | None = None
    resume_document_id: str | None = None


class CandidateDocumentDraft(BaseDomainModel):
    company_id: str
    role_ids: list[str] = Field(default_factory=list)
    document_type: Literal[
        "resume",
        "profile_photo",
        "skill_certificate",
        "education_certificate",
        "supporting_document",
    ]
    title: str | None = None
    tags: list[str] = Field(default_factory=list)


class CandidateConversationDraft(BaseDomainModel):
    company_id: str
    role_id: str | None = None
    message: str


class RecruiterConversationDraft(BaseDomainModel):
    role_id: str | None = None
    author: str | None = None
    message: str


class VerificationReviewDraft(BaseDomainModel):
    job_id: str | None = None
    decision: Literal["verified", "rejected"]
    reviewer: str | None = None
    notes: str | None = None


class ConversationMessage(BaseDomainModel):
    message_id: str
    company_id: str
    candidate_account_id: str
    company_candidate_id: str | None = None
    application_id: str | None = None
    role_id: str | None = None
    sender_type: Literal["candidate", "company"] = "candidate"
    sender_name: str
    message: str
    created_at: datetime = Field(default_factory=utc_now)
    read_by_candidate: bool = False
    read_by_company: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class PipelineStatus(BaseDomainModel):
    state: str = "starting"
    started_at: datetime = Field(default_factory=utc_now)
    last_update: datetime = Field(default_factory=utc_now)
    details: dict[str, Any] = Field(default_factory=dict)


class ActivityEvent(BaseDomainModel):
    event_type: str
    message: str
    entity_id: str | None = None
    entity_kind: str | None = None
    audience: Literal["recruiter", "system"] = "recruiter"
    severity: Literal["info", "warning", "error"] = "info"
    details: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=utc_now)
