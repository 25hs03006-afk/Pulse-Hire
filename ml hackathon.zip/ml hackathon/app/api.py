from __future__ import annotations

import asyncio
import json
import re
import shutil
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Iterable

from fastapi import FastAPI, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import StreamingResponse

from app.config import get_settings
from app.models import (
    ApprovalDraft,
    ApprovalSignoffDraft,
    ATSRequisitionDraft,
    CandidateConversationDraft,
    CandidateProfile,
    CandidateApplicationDraft,
    CandidateDocumentDraft,
    CandidateStageDraft,
    CandidateLoginRequest,
    CandidateProfileDraft,
    CandidateRegistration,
    CollaborationCommentDraft,
    CompanyRegistration,
    ConversationMessage,
    FeedbackDraft,
    FeedbackEntry,
    InterviewDraft,
    JobDraft,
    JobProfile,
    KaggleSyncRequest,
    LoginRequest,
    OfferDraft,
    RecruiterConversationDraft,
    RecruiterQuestion,
    ScorecardDraft,
    VerificationReviewDraft,
)
from app.pathway_runtime import PathwayRuntime
from app.services.ats import ATSWorkflowStore
from app.services.audit import AuditLog
from app.services.auth import AuthManager
from app.services.candidate_portal import CandidatePortalStore
from app.services.datasets import (
    SUPPORTED_BUNDLE_TYPES,
    import_dataset_bundle,
    kaggle_dataset_catalog,
    public_dataset_catalog,
    sync_kaggle_datasets,
)
from app.services.job_loader import parse_job_records
from app.services.orchestrator import ScreeningOrchestrator
from app.services.parsers.extractors import (
    extract_text_from_document,
    has_readable_text,
    parse_feedback_document,
    parse_job_document,
    parse_resume_document,
    slugify_identifier,
)
from app.services.parsers.resume_parser import parse_resume_records
from app.services.ranking.engine import RankingService
from app.services.retrieval import DocumentRetriever
from app.services.state.store import RuntimeState
from app.services.uploads import resolve_candidate_upload_destination
from app.services.workspaces import (
    SAMPLE_WORKSPACE,
    belongs_to_workspace,
    infer_workspace_from_entity_id,
    normalize_workspace_id,
    scoped_entity_id,
    workspace_source_dir,
)

settings = get_settings()
runtime_state = RuntimeState()
ranking_service = RankingService(settings=settings)
retriever = DocumentRetriever(base_url=settings.vector_base_url, state=runtime_state)
orchestrator = ScreeningOrchestrator(state=runtime_state, retriever=retriever, ranking_service=ranking_service)
runtime = PathwayRuntime(settings=settings, orchestrator=orchestrator, state=runtime_state)
auth_manager = AuthManager(settings.cache_dir)
candidate_store = CandidatePortalStore(settings)
ats_store = ATSWorkflowStore(settings.platform_db_path)
audit_log = AuditLog(settings.platform_db_path)
DATASET_CATALOG_PATH = settings.catalog_dir / "public_dataset_catalog.json"


@asynccontextmanager
async def app_lifespan(_: FastAPI):
    runtime.start()
    _seed_existing_company_workspaces()
    _seed_existing_candidate_accounts()
    yield

app = FastAPI(
    title=settings.project_name,
    version="3.0.0",
    summary="Real-time resume screening with dynamic uploads, live ranking, and recruiter decision support.",
    lifespan=app_lifespan,
)


def text(value: object | None, fallback: str = "") -> str:
    if value is None:
        return fallback
    if isinstance(value, str):
        stripped = value.strip()
        return stripped if stripped else fallback
    rendered = str(value).strip()
    return rendered if rendered else fallback

DEMO_COMPANY_WORKSPACES: dict[str, list[dict[str, object]]] = {
    "aurora-analytics": [
        {
            "title": "Data Scientist",
            "team": "Decision Intelligence",
            "location": "Bengaluru",
            "employment_type": "Full-time",
            "description": "Turn customer and operational data into models, experiments, and decision systems for product teams.",
            "must_have_skills": ["Python", "SQL", "Machine Learning", "Statistics", "Experimentation"],
            "nice_to_have_skills": ["NLP", "Pandas", "Scikit-learn"],
            "responsibilities": ["Build predictive models", "Own experimentation design", "Present actionable insights"],
            "hiring_target": 2,
            "min_years_experience": 3.0,
            "education_requirement": "Masters",
        },
        {
            "title": "Analytics Engineer",
            "team": "Data Platform",
            "location": "Hyderabad",
            "employment_type": "Full-time",
            "description": "Model reliable datasets and analytics layers that power decision-making across product and revenue teams.",
            "must_have_skills": ["SQL", "dbt", "Python", "Data Modeling", "BI"],
            "nice_to_have_skills": ["Airflow", "Snowflake", "Looker"],
            "responsibilities": ["Build trusted analytics tables", "Partner with business teams", "Improve data quality"],
            "hiring_target": 1,
            "min_years_experience": 3.0,
            "education_requirement": "Bachelors",
        },
    ],
    "novaforge-systems": [
        {
            "title": "ML Platform Engineer",
            "team": "Platform Engineering",
            "location": "Pune",
            "employment_type": "Full-time",
            "description": "Scale model deployment, observability, and infrastructure reliability for ML teams.",
            "must_have_skills": ["Python", "Docker", "Kubernetes", "MLOps", "CI/CD"],
            "nice_to_have_skills": ["Terraform", "AWS", "Feature Stores"],
            "responsibilities": ["Maintain ML delivery workflows", "Improve deployment reliability", "Standardize platform tooling"],
            "hiring_target": 2,
            "min_years_experience": 4.0,
            "education_requirement": "Bachelors",
        },
        {
            "title": "Backend Engineer",
            "team": "Core Systems",
            "location": "Remote",
            "employment_type": "Full-time",
            "description": "Build reliable services and APIs for operational products with strong ownership of quality and observability.",
            "must_have_skills": ["Python", "FastAPI", "Redis", "PostgreSQL", "APIs"],
            "nice_to_have_skills": ["Kafka", "Docker", "Testing"],
            "responsibilities": ["Design service APIs", "Own operational reliability", "Support cross-team integrations"],
            "hiring_target": 2,
            "min_years_experience": 3.0,
            "education_requirement": "Bachelors",
        },
    ],
    "blueorbit-health": [
        {
            "title": "Product Manager",
            "team": "Care Intelligence",
            "location": "Mumbai",
            "employment_type": "Full-time",
            "description": "Lead roadmap decisions for analytics-heavy healthcare workflows and AI-assisted internal products.",
            "must_have_skills": ["Product Strategy", "Roadmapping", "Stakeholder Management", "Analytics"],
            "nice_to_have_skills": ["Healthcare", "B2B SaaS", "Experimentation"],
            "responsibilities": ["Own product roadmap", "Drive discovery", "Align cross-functional execution"],
            "hiring_target": 1,
            "min_years_experience": 5.0,
            "education_requirement": "Bachelors",
        },
        {
            "title": "UX Designer",
            "team": "Design",
            "location": "Bengaluru",
            "employment_type": "Full-time",
            "description": "Design clear operational experiences for care coordinators and recruiter-style review workflows.",
            "must_have_skills": ["Figma", "UX Research", "Interaction Design", "Design Systems"],
            "nice_to_have_skills": ["Accessibility", "Healthcare", "Prototyping"],
            "responsibilities": ["Design user journeys", "Prototype decision flows", "Improve usability"],
            "hiring_target": 1,
            "min_years_experience": 3.0,
            "education_requirement": "Bachelors",
        },
    ],
    "meridian-retail-ai": [
        {
            "title": "Applied AI Engineer",
            "team": "Growth Systems",
            "location": "Remote",
            "employment_type": "Full-time",
            "description": "Build applied AI experiences with strong evaluation discipline, orchestration, and product empathy.",
            "must_have_skills": ["Python", "LLMs", "Prompt Engineering", "APIs", "Evaluation"],
            "nice_to_have_skills": ["RAG", "LangChain", "Experimentation"],
            "responsibilities": ["Ship AI product features", "Measure model quality", "Partner with product managers"],
            "hiring_target": 2,
            "min_years_experience": 3.0,
            "education_requirement": "Bachelors",
        },
        {
            "title": "Growth Analyst",
            "team": "Revenue Intelligence",
            "location": "Gurugram",
            "employment_type": "Full-time",
            "description": "Analyze demand, conversion, and campaign data to shape go-to-market decisions.",
            "must_have_skills": ["SQL", "Excel", "Analytics", "Experimentation"],
            "nice_to_have_skills": ["Python", "Tableau", "Marketing Analytics"],
            "responsibilities": ["Build business dashboards", "Measure campaign impact", "Recommend growth actions"],
            "hiring_target": 1,
            "min_years_experience": 2.0,
            "education_requirement": "Bachelors",
        },
    ],
    "quantumnest-cloud": [
        {
            "title": "Cloud Reliability Engineer",
            "team": "Infrastructure",
            "location": "Chennai",
            "employment_type": "Full-time",
            "description": "Keep distributed systems reliable with strong observability, incident response, and automation discipline.",
            "must_have_skills": ["AWS", "Kubernetes", "Docker", "Observability", "SRE"],
            "nice_to_have_skills": ["Terraform", "Python", "Incident Management"],
            "responsibilities": ["Improve reliability", "Automate operations", "Lead incident reviews"],
            "hiring_target": 1,
            "min_years_experience": 4.0,
            "education_requirement": "Bachelors",
        },
        {
            "title": "Real-Time RAG Engineer",
            "team": "AI Platform",
            "location": "Bengaluru / Remote",
            "employment_type": "Full-time",
            "description": "Own the streaming retrieval stack for recruiter-facing AI products, from live ingestion to grounded ranking and decision support.",
            "must_have_skills": ["Python", "Pathway", "RAG", "FastAPI", "Docker"],
            "nice_to_have_skills": ["Kubernetes", "AWS", "Vector Search"],
            "responsibilities": ["Build live ingestion pipelines", "Maintain ranking quality", "Improve retrieval grounding"],
            "hiring_target": 2,
            "min_years_experience": 4.0,
            "education_requirement": "Bachelors",
        },
    ],
}


def _extract_bearer_token(request: Request) -> str | None:
    authorization = request.headers.get("Authorization", "").strip()
    if authorization.lower().startswith("bearer "):
        return authorization.split(" ", 1)[1].strip()
    return None


def _require_session(request: Request) -> dict:
    token = _extract_bearer_token(request)
    session = auth_manager.get_session(token)
    if not session:
        raise HTTPException(status_code=401, detail="Please sign in to access your company workspace.")
    return session.model_dump()


def _require_candidate_session(request: Request) -> dict:
    token = _extract_bearer_token(request)
    session = candidate_store.get_session(token)
    if not session:
        raise HTTPException(status_code=401, detail="Please sign in to access your candidate workspace.")
    return session.model_dump()


def _workspace_id(request: Request) -> str:
    return normalize_workspace_id(_require_session(request)["workspace_id"])


def _candidate_account_id(request: Request) -> str:
    return str(_require_candidate_session(request).get("candidate_account_id") or "")


def _audit_company(
    *,
    request: Request,
    action: str,
    entity_kind: str | None = None,
    entity_id: str | None = None,
    details: dict | None = None,
    status: str = "success",
) -> None:
    session = _require_session(request)
    audit_log.record(
        actor_type="company",
        actor_id=str(session.get("admin_name") or session.get("workspace_id")),
        workspace_id=str(session.get("workspace_id")),
        action=action,
        entity_kind=entity_kind,
        entity_id=entity_id,
        status=status,
        details=details,
    )


def _audit_candidate(
    *,
    request: Request,
    action: str,
    entity_kind: str | None = None,
    entity_id: str | None = None,
    details: dict | None = None,
    status: str = "success",
) -> None:
    session = _require_candidate_session(request)
    audit_log.record(
        actor_type="candidate",
        actor_id=str(session.get("candidate_account_id")),
        workspace_id=None,
        action=action,
        entity_kind=entity_kind,
        entity_id=entity_id,
        status=status,
        details=details,
    )


def _workspace_candidates(workspace_id: str) -> list[CandidateProfile]:
    candidates = [
        candidate
        for candidate in runtime_state.list_candidates()
        if belongs_to_workspace(entity_id=candidate.candidate_id, source_path=candidate.source_path, workspace_id=workspace_id)
    ]
    if candidates or normalize_workspace_id(workspace_id) == SAMPLE_WORKSPACE:
        return candidates
    return _materialize_workspace_candidates_from_storage(workspace_id)


def _materialize_workspace_candidates_from_storage(workspace_id: str) -> list[CandidateProfile]:
    workspace_id = normalize_workspace_id(workspace_id)
    if workspace_id == SAMPLE_WORKSPACE:
        return []
    workspace_root = workspace_source_dir(settings.resumes_dir, workspace_id)
    if not workspace_root.exists():
        return []

    hydrated: list[CandidateProfile] = []
    for source_path in sorted(path for path in workspace_root.rglob("*") if path.is_file()):
        try:
            raw_bytes = source_path.read_bytes()
            parsed_candidates = parse_resume_records(source_path.name, raw_bytes, {"path": str(source_path)})
        except Exception:
            continue
        for candidate in parsed_candidates:
            scoped_candidate_id = scoped_entity_id(workspace_id, candidate.candidate_id)
            stream_path = workspace_source_dir(settings.resume_stream_dir, workspace_id) / f"{scoped_candidate_id}.json"
            materialized = candidate.model_copy(
                update={
                    "candidate_id": scoped_candidate_id,
                    "source_path": str(stream_path),
                    "origin_source_path": str(source_path),
                    "source_name": source_path.name,
                    "source_mode": "workspace-bootstrap",
                }
            )
            hydrated.append(orchestrator.handle_candidate_upsert(materialized))

    _refresh_workspace_rankings(workspace_id)
    return hydrated


def _materialize_workspace_jobs_from_storage(workspace_id: str) -> list[JobProfile]:
    workspace_id = normalize_workspace_id(workspace_id)
    if workspace_id == "sample":
        return []
    workspace_root = workspace_source_dir(settings.jobs_dir, workspace_id)
    if not workspace_root.exists():
        return []

    hydrated: list[JobProfile] = []
    for source_path in sorted(path for path in workspace_root.rglob("*") if path.is_file()):
        try:
            raw_bytes = source_path.read_bytes()
            parsed_jobs = parse_job_records(source_path.name, raw_bytes, {"path": str(source_path)})
        except Exception:
            continue
        for job in parsed_jobs:
            scoped_job_id = scoped_entity_id(workspace_id, job.job_id)
            stream_path = workspace_source_dir(settings.job_stream_dir, workspace_id) / f"{scoped_job_id}.json"
            materialized = job.model_copy(
                update={
                    "job_id": scoped_job_id,
                    "source_path": str(stream_path),
                    "origin_source_path": str(source_path),
                    "source_name": source_path.name,
                    "source_mode": "workspace-bootstrap",
                }
            )
            hydrated.append(orchestrator.handle_job_upsert(materialized))

    for job in hydrated:
        orchestrator.refresh_job(job.job_id)
    return hydrated


def _workspace_jobs(workspace_id: str) -> list[JobProfile]:
    jobs = [
        job
        for job in runtime_state.list_jobs()
        if belongs_to_workspace(entity_id=job.job_id, source_path=job.source_path, workspace_id=workspace_id)
    ]
    if jobs or normalize_workspace_id(workspace_id) == SAMPLE_WORKSPACE:
        return jobs
    return _materialize_workspace_jobs_from_storage(workspace_id)


def _workspace_feedback(workspace_id: str) -> list[FeedbackEntry]:
    return [
        entry
        for entry in runtime_state.list_feedback()
        if belongs_to_workspace(entity_id=entry.candidate_id or entry.job_id, source_path=entry.source_path, workspace_id=workspace_id)
    ]


def _workspace_candidate(workspace_id: str, candidate_id: str) -> CandidateProfile | None:
    return next((candidate for candidate in _workspace_candidates(workspace_id) if candidate.candidate_id == candidate_id), None)


def _workspace_job(workspace_id: str, job_id: str) -> JobProfile | None:
    return next((job for job in _workspace_jobs(workspace_id) if job.job_id == job_id), None)


def _workspace_feedback_entry(workspace_id: str, feedback_id: str) -> FeedbackEntry | None:
    return next((entry for entry in _workspace_feedback(workspace_id) if entry.feedback_id == feedback_id), None)


def _company_roles_payload(workspace_id: str) -> list[dict]:
    payload = []
    for job in _workspace_jobs(workspace_id):
        payload.append(
            {
                "job_id": job.job_id,
                "title": job.title,
                "team": job.team,
                "location": job.location,
                "employment_type": job.employment_type,
                "must_have_skills": job.must_have_skills,
                "nice_to_have_skills": job.nice_to_have_skills,
                "hiring_target": job.hiring_target,
                "description": job.description,
            }
        )
    return payload


def _workspace_display_name(workspace_id: str) -> str:
    tokens = [token for token in normalize_workspace_id(workspace_id).split("-") if token]
    if not tokens:
        return "Company Workspace"
    return " ".join(token.upper() if len(token) <= 3 else token.capitalize() for token in tokens)


def _company_record(workspace_id: str) -> dict:
    workspace_id = normalize_workspace_id(workspace_id)
    company = auth_manager.get_company(workspace_id)
    if company:
        return {
            **company,
            "is_registered": True,
        }
    return {
        "workspace_id": workspace_id,
        "company_name": _workspace_display_name(workspace_id),
        "admin_name": "Workspace owner",
        "email": None,
        "role": "owner",
        "is_registered": False,
    }


def _discover_company_workspaces() -> list[str]:
    workspace_ids = {
        normalize_workspace_id(company["workspace_id"])
        for company in auth_manager.list_companies()
        if normalize_workspace_id(company["workspace_id"]) != SAMPLE_WORKSPACE
    }

    for job in runtime_state.list_jobs():
        workspace_id = normalize_workspace_id(infer_workspace_from_entity_id(job.job_id))
        if workspace_id != SAMPLE_WORKSPACE:
            workspace_ids.add(workspace_id)

    for root in (settings.jobs_dir, settings.job_stream_dir):
        if not root.exists():
            continue
        for child in root.iterdir():
            if not child.is_dir():
                continue
            workspace_id = normalize_workspace_id(child.name)
            if workspace_id == SAMPLE_WORKSPACE:
                continue
            if any(path.is_file() for path in child.rglob("*")):
                workspace_ids.add(workspace_id)

    return sorted(workspace_ids, key=lambda item: _company_record(item)["company_name"].lower())


def _candidate_application_dashboard(application: dict) -> dict:
    company_id = normalize_workspace_id(application.get("company_id"))
    company = auth_manager.get_company(company_id) or {"workspace_id": company_id, "company_name": company_id.title()}
    company_candidate_id = str(application.get("company_candidate_id") or "")
    candidate_account_id = str(application.get("candidate_account_id") or "")
    candidate_profile = _workspace_candidate(company_id, company_candidate_id) if company_candidate_id else None
    documents = candidate_store.documents_for_company_candidate(company_id, company_candidate_id) if company_candidate_id else []
    verification_summary = (
        candidate_store.build_verification_summary(candidate_profile=candidate_profile, documents=documents)
        if candidate_profile
        else application.get("verification_summary", {})
    )
    role_statuses = application.get("role_statuses") or {}
    conversation = candidate_store.list_messages(
        candidate_account_id=candidate_account_id,
        company_id=company_id,
    ) if candidate_account_id else []
    roles = []
    for role_id in application.get("role_ids", []):
        job = _workspace_job(company_id, role_id)
        if not job:
            continue
        role_state = dict(role_statuses.get(role_id) or {})
        insight = orchestrator.candidate_insight(role_id, application.get("company_candidate_id")) or {}
        feedback = [
            entry.model_dump(mode="json")
            for entry in _workspace_feedback(company_id)
            if entry.candidate_id == application.get("company_candidate_id") and (not entry.job_id or entry.job_id == role_id)
        ]
        ranking_snapshot = orchestrator.get_rankings(role_id)
        ranking = None
        if ranking_snapshot:
            ranking = next(
                (
                    item.model_dump(mode="json")
                    for item in ranking_snapshot.rankings
                    if item.candidate.candidate_id == application.get("company_candidate_id")
                ),
                None,
            )
        verification_status = text(role_state.get("verification_status"), "pending")
        score_visible = verification_status == "verified"
        roles.append(
            {
                "job_id": job.job_id,
                "title": job.title,
                "team": job.team,
                "match_score": ranking.get("breakdown", {}).get("total_score") if ranking and score_visible else None,
                "score_visible": score_visible,
                "rank": ranking.get("rank") if ranking else None,
                "status": feedback[0]["label"] if feedback else (role_state.get("status") or ("under_review" if ranking else "submitted")),
                "feedback": feedback,
                "recruiter_notes": [entry.get("notes") for entry in feedback if entry.get("notes")] or ([role_state.get("notes")] if role_state.get("notes") else []),
                "interview_focus": insight.get("interview_focus", []),
                "why_selected": insight.get("why_selected", []),
                "why_not_selected": insight.get("why_not_selected", []),
                "verification_summary": verification_summary,
                "verification_status": verification_status,
                "verification_notes": text(role_state.get("verification_notes")),
                "verification_reviewer": text(role_state.get("verification_reviewer")),
                "verification_updated_at": role_state.get("verification_updated_at"),
                "conversation": [message for message in conversation if not message.get("role_id") or message.get("role_id") == role_id],
            }
        )
    roles.sort(
        key=lambda role: (
            0 if text(role.get("verification_status"), "pending") == "verified" else 1,
            0 if role.get("score_visible") else 1,
            -(len(items := [note for note in (role.get("recruiter_notes") or []) if text(note)]) + len([entry for entry in (role.get("feedback") or []) if text(entry.get("notes"))])),
            -float(role.get("match_score") or 0.0),
            int(role.get("rank") or 9999),
            text(role.get("title")).lower(),
        )
    )
    return {
        "application_id": application.get("application_id"),
        "company": company,
        "company_candidate_id": application.get("company_candidate_id"),
        "role_ids": application.get("role_ids", []),
        "resume_version": application.get("resume_version", 1),
        "updated_at": application.get("updated_at"),
        "roles": roles,
        "documents": documents,
        "verification_summary": verification_summary,
        "conversation": conversation,
        "notifications": candidate_store.notifications_for_candidate(str(application.get("candidate_account_id"))),
        "timeline": candidate_store.timeline_for_candidate(str(application.get("candidate_account_id")), company_id),
    }


def _candidate_verification_summary(workspace_id: str, candidate_id: str, role_id: str | None = None) -> tuple[dict, list[dict]]:
    candidate = _workspace_candidate(workspace_id, candidate_id)
    if not candidate:
        return {}, []
    documents = candidate_store.documents_for_company_candidate(workspace_id, candidate_id, role_id=role_id)
    summary = candidate_store.build_verification_summary(candidate_profile=candidate, documents=documents)
    application = candidate_store.application_by_company_candidate(workspace_id, candidate_id)
    if application and application.get("verification_summary"):
        summary = {
            **application.get("verification_summary", {}),
            **summary,
        }
    return summary, documents


def _workspace_summary(workspace_id: str) -> dict:
    candidates = _workspace_candidates(workspace_id)
    jobs = _workspace_jobs(workspace_id)
    feedback_entries = _workspace_feedback(workspace_id)
    ranked_jobs = [job for job in jobs if runtime_state.get_ranking_snapshot(job.job_id)]
    recent_events = [
        event.model_dump(mode="json")
        for event in runtime_state.recent_events()
        if belongs_to_workspace(entity_id=event.entity_id, source_path=event.entity_id, workspace_id=workspace_id)
    ][:12]
    documents = [
        document
        for document in runtime_state.document_registry()
        if belongs_to_workspace(entity_id=document.get("entity_id"), source_path=document.get("path"), workspace_id=workspace_id)
    ][:20]
    failures = [
        failure
        for failure in runtime_state.recent_failures()
        if belongs_to_workspace(source_path=failure.get("path"), workspace_id=workspace_id)
    ][:5]
    completeness = [candidate.completeness_score for candidate in candidates]
    return {
        "pipeline": runtime_state.summary()["pipeline"],
        "counts": {
            "candidates": len(candidates),
            "jobs": len(jobs),
            "feedback_entries": len(feedback_entries),
            "ranked_jobs": len(ranked_jobs),
            "documents": len(documents),
        },
        "quality": {
            "revision": runtime_state.revision,
            "avg_profile_completeness": round(sum(completeness) / len(completeness), 4) if completeness else 0.0,
            "duplicate_profiles": sum(1 for candidate in candidates if candidate.duplicate_of),
            "documents_with_errors": len([item for item in documents if item.get("status") == "error"]),
        },
        "documents": documents,
        "recent_events": recent_events,
        "recent_failures": failures,
    }


def _workspace_analytics(workspace_id: str) -> dict:
    jobs = _workspace_jobs(workspace_id)
    candidates = _workspace_candidates(workspace_id)
    feedback_entries = _workspace_feedback(workspace_id)
    applications = candidate_store.applications_for_company(workspace_id)
    candidate_verifications = []
    for candidate in candidates:
        summary, _ = _candidate_verification_summary(workspace_id, candidate.candidate_id)
        if summary:
            candidate_verifications.append(summary)
    role_analytics = []
    status_counts: dict[str, int] = {}
    for application in applications:
        for role_id, payload in (application.get("role_statuses") or {}).items():
            status = str(payload.get("status") or "under_review")
            status_counts[status] = status_counts.get(status, 0) + 1
    if not status_counts:
        for application in applications:
            for role_id in application.get("role_ids", []):
                status_counts["submitted"] = status_counts.get("submitted", 0) + 1
    verification_scores = [float(summary.get("verification_score", 0.0) or 0.0) for summary in candidate_verifications]
    for job in jobs:
        snapshot = orchestrator.get_rankings(job.job_id)
        rankings = snapshot.rankings if snapshot else []
        fit_distribution: dict[str, int] = {}
        for item in rankings:
            fit_distribution[item.fit_band] = fit_distribution.get(item.fit_band, 0) + 1
        application_count = sum(1 for application in applications if job.job_id in (application.get("role_ids") or []))
        role_analytics.append(
            {
                "job_id": job.job_id,
                "title": job.title,
                "hiring_target": job.hiring_target,
                "application_submissions": application_count,
                "candidate_pool": len(rankings),
                "ranked_candidates": len(rankings),
                "shortlist_ready": sum(1 for item in rankings if item.fit_band in {"excellent", "strong"}),
                "average_match_score": round(
                    sum(item.breakdown.total_score for item in rankings) / len(rankings),
                    4,
                ) if rankings else 0.0,
                "fit_distribution": fit_distribution,
            }
        )
    return {
        "funnel": {
            "applications": len(applications),
            "candidates": len(candidates),
            "roles": len(jobs),
            "open_roles": len(jobs),
            "feedback_entries": len(feedback_entries),
            "status_counts": status_counts,
        },
        "verification": {
            "average_verification_score": round(sum(verification_scores) / len(verification_scores), 4) if verification_scores else 0.0,
            "profiles_with_documents": sum(1 for summary in candidate_verifications if int(summary.get("document_count", 0) or 0) > 0),
            "profiles_missing_photo": sum(1 for summary in candidate_verifications if not bool(summary.get("profile_photo_uploaded"))),
            "profiles_with_unverified_claims": sum(
                1
                for summary in candidate_verifications
                if summary.get("unverified_skills") or summary.get("pending_education") or summary.get("pending_certifications")
            ),
        },
        "roles": role_analytics,
        "quality": runtime_state.quality_metrics(),
    }


def _workspace_seed_name(workspace_id: str) -> str:
    return _workspace_display_name(workspace_id)


def _ensure_demo_company_workspaces() -> None:
    for workspace_id, jobs in DEMO_COMPANY_WORKSPACES.items():
        workspace_root = workspace_source_dir(settings.jobs_dir, workspace_id)
        existing_files = [path for path in workspace_root.glob("*") if path.is_file()]
        if existing_files:
            continue
        workspace_root.mkdir(parents=True, exist_ok=True)
        for job_document in jobs:
            payload = JobDraft.model_validate(job_document)
            destination = _job_document_path(payload.title, payload.team, workspace_id)
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.exists():
                continue
            destination.write_bytes(_serialize_job_draft(payload))


def _seed_existing_company_workspaces() -> list[dict]:
    _ensure_demo_company_workspaces()
    seeded = []
    for workspace_id in _discover_company_workspaces():
        record = auth_manager.ensure_seed_company(
            workspace_id=workspace_id,
            company_name=_workspace_seed_name(workspace_id),
        )
        seeded.append(record)
    return seeded


def _seed_existing_candidate_accounts() -> list[dict]:
    return candidate_store.ensure_seed_accounts_from_resumes()


def _candidate_identity(candidate_account_id: str) -> tuple[dict, dict]:
    return (
        candidate_store.get_account(candidate_account_id) or {},
        candidate_store.get_profile(candidate_account_id) or {},
    )


def _candidate_matches_account(candidate: CandidateProfile, account: dict, profile: dict) -> bool:
    account_email = str(account.get("email") or profile.get("email") or "").strip().lower()
    candidate_email = str(candidate.email or "").strip().lower()
    if account_email and candidate_email and account_email == candidate_email:
        return True
    account_name = slugify_identifier(str(account.get("full_name") or profile.get("full_name") or ""))
    candidate_name = slugify_identifier(candidate.name)
    return bool(account_name and candidate_name and account_name == candidate_name)


def _candidate_relevant_roles(workspace_id: str, candidate_id: str) -> list[str]:
    role_ids: list[str] = []
    feedback_role_ids = {
        entry.job_id
        for entry in _workspace_feedback(workspace_id)
        if entry.candidate_id == candidate_id and entry.job_id
    }
    for job in _workspace_jobs(workspace_id):
        snapshot = orchestrator.get_rankings(job.job_id)
        ranking_hit = bool(
            snapshot
            and any(item.candidate.candidate_id == candidate_id for item in snapshot.rankings)
        )
        if ranking_hit or job.job_id in feedback_role_ids:
            role_ids.append(job.job_id)
    return sorted(set(role_ids))


def _sync_linked_candidate_applications(candidate_account_id: str) -> list[dict]:
    account, profile = _candidate_identity(candidate_account_id)
    if not account and not profile:
        return candidate_store.candidate_applications(candidate_account_id)

    synced: list[dict] = []
    for workspace_id in _discover_company_workspaces():
        for candidate in _workspace_candidates(workspace_id):
            if not _candidate_matches_account(candidate, account, profile):
                continue
            role_ids = _candidate_relevant_roles(workspace_id, candidate.candidate_id)
            if not role_ids:
                continue
            synced.append(
                candidate_store.ensure_linked_application(
                    candidate_account_id=candidate_account_id,
                    company_id=workspace_id,
                    company_candidate_id=candidate.candidate_id,
                    role_ids=role_ids,
                    candidate_profile=candidate,
                )
            )
    return candidate_store.candidate_applications(candidate_account_id)


def _ensure_linked_application_for_company_candidate(
    *,
    workspace_id: str,
    candidate_id: str,
    role_ids: list[str] | None = None,
) -> dict | None:
    candidate = _workspace_candidate(workspace_id, candidate_id)
    if not candidate:
        return None
    account = candidate_store.find_account(full_name=candidate.name, email=candidate.email)
    if not account:
        return None
    relevant_role_ids = sorted(set((role_ids or []) + _candidate_relevant_roles(workspace_id, candidate_id)))
    if not relevant_role_ids:
        relevant_role_ids = [job.job_id for job in _workspace_jobs(workspace_id)[:1]]
    return candidate_store.ensure_linked_application(
        candidate_account_id=str(account.get("candidate_account_id")),
        company_id=workspace_id,
        company_candidate_id=candidate_id,
        role_ids=relevant_role_ids,
        candidate_profile=candidate,
    )


@app.post("/auth/register")
async def register_company(payload: CompanyRegistration) -> dict:
    if len(payload.password.strip()) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters long.")
    try:
        session = auth_manager.register_company(
            company_name=payload.company_name,
            admin_name=payload.admin_name,
            email=payload.email,
            password=payload.password,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit_log.record(
        actor_type="company",
        actor_id=session.admin_name,
        workspace_id=session.workspace_id,
        action="company_registered",
        entity_kind="workspace",
        entity_id=session.workspace_id,
        details={"email": session.email},
    )
    return session.model_dump()


@app.post("/auth/login")
async def login(payload: LoginRequest) -> dict:
    try:
        _seed_existing_company_workspaces()
        session = auth_manager.login(company_name=payload.company_name, password=payload.password)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    audit_log.record(
        actor_type="company",
        actor_id=session.admin_name,
        workspace_id=session.workspace_id,
        action="company_logged_in",
        entity_kind="workspace",
        entity_id=session.workspace_id,
    )
    return session.model_dump()


@app.get("/auth/me")
async def auth_me(request: Request) -> dict:
    return _require_session(request)


@app.post("/auth/logout")
async def auth_logout(request: Request) -> dict:
    token = _extract_bearer_token(request)
    session = auth_manager.get_session(token)
    auth_manager.logout(token)
    if session:
        audit_log.record(
            actor_type="company",
            actor_id=session.admin_name,
            workspace_id=session.workspace_id,
            action="company_logged_out",
            entity_kind="workspace",
            entity_id=session.workspace_id,
        )
    return {"message": "Signed out successfully."}


@app.post("/candidate/auth/register")
async def register_candidate(payload: CandidateRegistration) -> dict:
    try:
        session = candidate_store.register_candidate(
            full_name=payload.full_name,
            email=payload.email,
            password=payload.password,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    audit_log.record(
        actor_type="candidate",
        actor_id=session.candidate_account_id,
        action="candidate_registered",
        entity_kind="candidate_account",
        entity_id=session.candidate_account_id,
        details={"email": session.email},
    )
    return session.model_dump()


@app.post("/candidate/auth/login")
async def login_candidate(payload: CandidateLoginRequest) -> dict:
    try:
        _seed_existing_candidate_accounts()
        session = candidate_store.login_candidate(identifier=payload.email, password=payload.password)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    audit_log.record(
        actor_type="candidate",
        actor_id=session.candidate_account_id,
        action="candidate_logged_in",
        entity_kind="candidate_account",
        entity_id=session.candidate_account_id,
    )
    return session.model_dump()


@app.get("/candidate/auth/me")
async def candidate_auth_me(request: Request) -> dict:
    return _require_candidate_session(request)


@app.post("/candidate/auth/logout")
async def candidate_auth_logout(request: Request) -> dict:
    token = _extract_bearer_token(request)
    session = candidate_store.get_session(token)
    candidate_store.logout(token)
    if session:
        audit_log.record(
            actor_type="candidate",
            actor_id=session.candidate_account_id,
            action="candidate_logged_out",
            entity_kind="candidate_account",
            entity_id=session.candidate_account_id,
        )
    return {"message": "Signed out successfully."}


@app.get("/candidate/companies")
async def candidate_companies(request: Request, include_empty: bool = Query(default=False)) -> list[dict]:
    _require_candidate_session(request)
    _seed_existing_company_workspaces()
    companies = []
    for workspace_id in _discover_company_workspaces():
        company = _company_record(workspace_id)
        roles = _company_roles_payload(workspace_id)
        if not include_empty and not roles:
            continue
        companies.append(
            {
                **company,
                "roles_count": len(roles),
                "roles": roles,
            }
        )
    return companies


@app.get("/candidate/companies/{company_id}/roles")
async def candidate_company_roles(company_id: str, request: Request) -> dict:
    _require_candidate_session(request)
    _seed_existing_company_workspaces()
    workspace_id = normalize_workspace_id(company_id)
    company = _company_record(workspace_id)
    roles = _company_roles_payload(workspace_id)
    if not company.get("is_registered") and not roles:
        raise HTTPException(status_code=404, detail="Company workspace not found.")
    return {
        "company": company,
        "roles": roles,
    }


@app.get("/candidate/profile")
async def candidate_profile(request: Request) -> dict:
    session = _require_candidate_session(request)
    candidate_account_id = str(session["candidate_account_id"])
    synced_applications = _sync_linked_candidate_applications(candidate_account_id)
    profile = candidate_store.get_profile(candidate_account_id)
    return {
        "session": session,
        "profile": profile,
        "notifications": candidate_store.notifications_for_candidate(candidate_account_id),
        "timeline": candidate_store.timeline_for_candidate(candidate_account_id),
        "applications": [
            _candidate_application_dashboard(application)
            for application in synced_applications
        ],
    }


@app.post("/candidate/profile")
async def save_candidate_profile(payload: CandidateProfileDraft, request: Request) -> dict:
    session = _require_candidate_session(request)
    candidate_account_id = str(session["candidate_account_id"])
    profile = candidate_store.save_profile(candidate_account_id, payload)
    return {
        "message": "Profile saved.",
        "profile": profile,
    }


def _safe_filename(file_name: str | None, fallback_stem: str) -> str:
    original = Path(file_name or fallback_stem).name
    stem = slugify_identifier(Path(original).stem or fallback_stem)
    suffix = Path(original).suffix.lower()
    return f"{stem}{suffix}" if suffix else stem


def _delete_path(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink(missing_ok=True)


def _same_file_content(destination: Path, raw_bytes: bytes) -> bool:
    return destination.exists() and destination.is_file() and destination.read_bytes() == raw_bytes


def _ensure_allowed(file_name: str | None, allowed_suffixes: Iterable[str], label: str) -> str:
    suffix = Path(file_name or "").suffix.lower()
    allowed = {item.lower() for item in allowed_suffixes}
    if suffix not in allowed:
        supported = ", ".join(sorted(allowed))
        raise HTTPException(status_code=400, detail=f"{label} files must be one of: {supported}.")
    return suffix


def _ensure_size(raw_bytes: bytes, label: str) -> None:
    max_bytes = settings.max_upload_size_mb * 1024 * 1024
    if len(raw_bytes) > max_bytes:
        raise HTTPException(
            status_code=400,
            detail=f"{label} is too large. Please keep files below {settings.max_upload_size_mb} MB.",
        )


def _ensure_dataset_bundle_size(raw_bytes: bytes) -> None:
    max_bytes = settings.max_dataset_bundle_size_mb * 1024 * 1024
    if len(raw_bytes) > max_bytes:
        raise HTTPException(
            status_code=400,
            detail=f"Dataset bundles must stay below {settings.max_dataset_bundle_size_mb} MB.",
        )


def _ensure_readable_document(file_name: str, raw_bytes: bytes, label: str, minimum_characters: int) -> None:
    text = extract_text_from_document(file_name, raw_bytes)
    if not has_readable_text(text, minimum_characters=minimum_characters):
        raise HTTPException(
            status_code=400,
            detail=f"We could not read enough content from this {label}. Please upload a clearer file.",
        )


def _write_bytes(destination: Path, raw_bytes: bytes) -> str:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = settings.cache_dir / f"{destination.name}.{time.time_ns()}.tmp"
    temporary.parent.mkdir(parents=True, exist_ok=True)
    temporary.write_bytes(raw_bytes)
    temporary.replace(destination)
    return str(destination)


def _job_storage_stem(title: str, team: str | None = None) -> str:
    label = " ".join(part for part in [title, team] if part and part.strip())
    return slugify_identifier(label)


def _job_document_path(title: str, team: str | None = None, workspace_id: str = "sample") -> Path:
    return workspace_source_dir(settings.jobs_dir, workspace_id) / f"{_job_storage_stem(title, team)}.json"


def _preview_resume_records(file_name: str, raw_bytes: bytes, source_path: str | None = None) -> list[CandidateProfile]:
    try:
        return parse_resume_records(file_name, raw_bytes, {"path": source_path or file_name})
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail="We could not extract a usable candidate profile from this file. Please upload a clearer resume with visible skills, experience, or education details.",
        ) from exc


def _preview_job_records(file_name: str, raw_bytes: bytes, source_path: str | None = None) -> list[JobProfile]:
    try:
        return parse_job_records(file_name, raw_bytes, {"path": source_path or file_name})
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail="We could not extract a usable role profile from this file. Please upload a clearer job description.",
        ) from exc


def _candidate_storage_path(file_name: str, raw_bytes: bytes, suffix: str, workspace_id: str) -> tuple[Path, str, bool]:
    preview = _preview_resume_records(file_name, raw_bytes, file_name)[0]
    return resolve_candidate_upload_destination(
        preview=preview,
        suffix=suffix,
        resumes_dir=workspace_source_dir(settings.resumes_dir, workspace_id),
        existing_candidates=_workspace_candidates(workspace_id),
        raw_bytes=raw_bytes,
        workspace_id=workspace_id,
    )


def _job_storage_path(file_name: str, raw_bytes: bytes, suffix: str, workspace_id: str) -> tuple[Path, str]:
    preview = _preview_job_records(file_name, raw_bytes, file_name)[0]
    stem = _job_storage_stem(preview.title, preview.team)
    return workspace_source_dir(settings.jobs_dir, workspace_id) / f"{stem}{suffix}", scoped_entity_id(workspace_id, stem)


def _feedback_document_path(candidate_id: str, workspace_id: str) -> Path:
    stamp = int(time.time() * 1000)
    return workspace_source_dir(settings.feedback_dir, workspace_id) / f"feedback-{slugify_identifier(candidate_id)}-{stamp}.json"


def _merge_job_draft(existing: JobProfile, payload: JobDraft) -> JobProfile:
    simulated = parse_job_document(f"{existing.job_id}.json", _serialize_job_draft(payload), {"path": existing.source_path})
    return simulated.model_copy(update={"job_id": existing.job_id, "source_path": existing.source_path})


def _serialize_job_draft(payload: JobDraft) -> bytes:
    document = {
        "title": payload.title,
        "team": payload.team,
        "location": payload.location,
        "employment_type": payload.employment_type,
        "description": payload.description,
        "must_have_skills": payload.must_have_skills,
        "nice_to_have_skills": payload.nice_to_have_skills,
        "responsibilities": payload.responsibilities,
        "hiring_target": payload.hiring_target,
        "min_years_experience": payload.min_years_experience,
        "education_requirement": payload.education_requirement,
    }
    return json.dumps(document, indent=2).encode("utf-8")


def _serialize_feedback_draft(payload: FeedbackDraft) -> bytes:
    document = {
        "candidate_id": payload.candidate_id,
        "job_id": payload.job_id,
        "recruiter": payload.recruiter,
        "label": payload.label,
        "notes": payload.notes,
        "score_adjustment": payload.score_adjustment,
    }
    return json.dumps(document, indent=2).encode("utf-8")


def _serialize_feedback_entries(entries: list[FeedbackEntry]) -> bytes:
    payload = [
        {
            "feedback_id": entry.feedback_id,
            "candidate_id": entry.candidate_id,
            "job_id": entry.job_id,
            "recruiter": entry.recruiter,
            "label": entry.label,
            "score_adjustment": entry.score_adjustment,
            "notes": entry.notes,
            "created_at": entry.created_at.isoformat(),
        }
        for entry in entries
    ]
    return json.dumps(payload, indent=2).encode("utf-8")


def _candidate_upload_result(destination: Path, raw_bytes: bytes) -> dict:
    records = _preview_resume_records(str(destination), raw_bytes, str(destination))
    preview = records[0]
    return {
        "candidate_id": preview.candidate_id,
        "candidate_name": preview.name,
        "candidate_count": len(records),
        "path": str(destination),
    }


def _refresh_workspace_rankings(workspace_id: str, job_ids: Iterable[str] | None = None) -> None:
    target_ids = list(job_ids) if job_ids is not None else [job.job_id for job in _workspace_jobs(workspace_id)]
    for job_id in dict.fromkeys(target_ids):
        if _workspace_job(workspace_id, job_id):
            orchestrator.refresh_job(job_id)


def _hydrate_jobs_from_bytes(
    *,
    workspace_id: str,
    raw_source_path: str,
    raw_bytes: bytes,
    file_name: str,
    source_mode: str,
) -> list[JobProfile]:
    hydrated: list[JobProfile] = []
    for job in _preview_job_records(file_name, raw_bytes, raw_source_path):
        scoped_job_id = scoped_entity_id(workspace_id, job.job_id)
        stream_path = workspace_source_dir(settings.job_stream_dir, workspace_id) / f"{scoped_job_id}.json"
        materialized = job.model_copy(
            update={
                "job_id": scoped_job_id,
                "source_path": str(stream_path),
                "origin_source_path": raw_source_path,
                "source_name": Path(raw_source_path).name,
                "source_mode": source_mode,
            }
        )
        hydrated.append(orchestrator.handle_job_upsert(materialized))
    _refresh_workspace_rankings(workspace_id, [job.job_id for job in hydrated])
    return hydrated


def _hydrate_candidates_from_bytes(
    *,
    workspace_id: str,
    raw_source_path: str,
    raw_bytes: bytes,
    file_name: str,
    source_mode: str,
    preferred_candidate_id: str | None = None,
) -> list[CandidateProfile]:
    parsed_records = _preview_resume_records(file_name, raw_bytes, raw_source_path)
    hydrated: list[CandidateProfile] = []
    single_record = len(parsed_records) == 1
    for candidate in parsed_records:
        candidate_id = preferred_candidate_id if preferred_candidate_id and single_record else scoped_entity_id(workspace_id, candidate.candidate_id)
        stream_path = workspace_source_dir(settings.resume_stream_dir, workspace_id) / f"{candidate_id}.json"
        materialized = candidate.model_copy(
            update={
                "candidate_id": candidate_id,
                "source_path": str(stream_path),
                "origin_source_path": raw_source_path,
                "source_name": Path(raw_source_path).name,
                "source_mode": source_mode,
            }
        )
        hydrated.append(orchestrator.handle_candidate_upsert(materialized))
    _refresh_workspace_rankings(workspace_id)
    return hydrated


def _hydrate_feedback_from_bytes(
    *,
    workspace_id: str,
    raw_source_path: str,
    raw_bytes: bytes,
    file_name: str,
) -> list[FeedbackEntry]:
    entries = parse_feedback_document(file_name, raw_bytes, {"path": raw_source_path})
    hydrated_entries = orchestrator.handle_feedback_replace(raw_source_path, entries)
    targeted_job_ids = [entry.job_id for entry in hydrated_entries if entry.job_id]
    _refresh_workspace_rankings(workspace_id, targeted_job_ids or None)
    return hydrated_entries


def _parse_role_ids(raw_value: str | None) -> list[str]:
    value = (raw_value or "").strip()
    if not value:
        return []
    try:
        parsed = json.loads(value)
        if isinstance(parsed, list):
            return [str(item).strip() for item in parsed if str(item).strip()]
    except Exception:
        pass
    return [item.strip() for item in value.split(",") if item.strip()]


def _split_csv_values(raw_value: str | None) -> list[str]:
    return [item.strip() for item in (raw_value or "").split(",") if item.strip()]


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.project_name,
        "message": "PulseHire API is ready.",
        "retrieval_backend": retriever.statistics(),
    }


@app.get("/health")
async def health() -> dict:
    return {
        "pipeline": runtime_state.summary()["pipeline"],
        "retrieval": retriever.statistics(),
        "quality": runtime_state.quality_metrics(),
    }


@app.post("/candidate/documents")
async def upload_candidate_document(
    request: Request,
    company_id: str = Form(...),
    role_ids: str = Form(default=""),
    document_type: str = Form(...),
    title: str | None = Form(default=None),
    tags: str = Form(default=""),
    file: UploadFile = File(...),
) -> dict:
    session = _require_candidate_session(request)
    workspace_id = normalize_workspace_id(company_id)
    company = _company_record(workspace_id)
    valid_role_ids = {job.job_id for job in _workspace_jobs(workspace_id)}
    if not company.get("is_registered") and not valid_role_ids:
        raise HTTPException(status_code=404, detail="Company workspace not found.")
    selected_roles = _parse_role_ids(role_ids)
    invalid_roles = [role_id for role_id in selected_roles if role_id not in valid_role_ids]
    if invalid_roles:
        raise HTTPException(status_code=400, detail="One or more selected roles are no longer available.")

    raw_bytes = await file.read()
    candidate_account_id = str(session["candidate_account_id"])
    existing_application = candidate_store.candidate_application(candidate_account_id, workspace_id)
    company_candidate_id = existing_application.get("company_candidate_id") if existing_application else None

    if document_type == "resume":
        _ensure_allowed(file.filename, settings.resume_upload_types, "Resume")
        _ensure_size(raw_bytes, "Resume")
        _ensure_readable_document(file.filename or "resume", raw_bytes, "resume", minimum_characters=25)
    elif document_type == "profile_photo":
        _ensure_allowed(file.filename, {".png", ".jpg", ".jpeg"}, "Profile photo")
        _ensure_size(raw_bytes, "Profile photo")
    else:
        _ensure_allowed(file.filename, {".pdf", ".png", ".jpg", ".jpeg", ".docx"}, "Verification")
        _ensure_size(raw_bytes, "Verification file")

    document = candidate_store.save_document(
        candidate_account_id=candidate_account_id,
        company_id=workspace_id,
        role_ids=selected_roles,
        company_candidate_id=company_candidate_id,
        document_type=document_type,
        file_name=file.filename or f"{document_type}.bin",
        raw_bytes=raw_bytes,
        tags=_split_csv_values(tags),
        title=title,
        application_id=existing_application.get("application_id") if existing_application else None,
    )
    return {
        "message": "Document uploaded successfully.",
        "document": document,
    }


@app.get("/candidate/documents")
async def list_candidate_documents(request: Request, company_id: str | None = None) -> list[dict]:
    session = _require_candidate_session(request)
    documents = candidate_store.documents_for_candidate(str(session["candidate_account_id"]))
    if company_id:
        workspace_id = normalize_workspace_id(company_id)
        documents = [document for document in documents if document.get("company_id") == workspace_id]
    return documents


@app.get("/candidate/notifications")
async def candidate_notifications(request: Request) -> list[dict]:
    candidate_account_id = _candidate_account_id(request)
    return candidate_store.notifications_for_candidate(candidate_account_id)


@app.post("/candidate/notifications/{notification_id}/read")
async def mark_candidate_notification_read(notification_id: str, request: Request) -> dict:
    candidate_account_id = _candidate_account_id(request)
    notification = candidate_store.mark_notification_read(candidate_account_id, notification_id)
    if not notification:
        raise HTTPException(status_code=404, detail="Notification not found.")
    return {"message": "Notification updated.", "notification": notification}


@app.get("/candidate/conversations")
async def candidate_conversations(
    request: Request,
    company_id: str | None = None,
    role_id: str | None = None,
) -> list[dict]:
    candidate_account_id = _candidate_account_id(request)
    _sync_linked_candidate_applications(candidate_account_id)
    workspace_id = normalize_workspace_id(company_id) if company_id else None
    return candidate_store.list_messages(
        candidate_account_id=candidate_account_id,
        company_id=workspace_id,
        role_id=role_id,
    )


@app.post("/candidate/conversations")
async def post_candidate_conversation(payload: CandidateConversationDraft, request: Request) -> dict:
    session = _require_candidate_session(request)
    candidate_account_id = str(session["candidate_account_id"])
    _sync_linked_candidate_applications(candidate_account_id)
    workspace_id = normalize_workspace_id(payload.company_id)
    application = candidate_store.candidate_application(candidate_account_id, workspace_id)
    if not application:
        raise HTTPException(status_code=400, detail="Submit an application or link an existing company profile before messaging the recruiter.")
    role_id = payload.role_id or ((application.get("role_ids") or [None])[0])
    message = candidate_store.post_message(
        company_id=workspace_id,
        candidate_account_id=candidate_account_id,
        company_candidate_id=str(application.get("company_candidate_id") or ""),
        role_id=role_id,
        sender_type="candidate",
        sender_name=str(session.get("full_name") or "Candidate"),
        message=payload.message,
        application_id=str(application.get("application_id") or ""),
    )
    _audit_candidate(
        request=request,
        action="candidate_message_posted",
        entity_kind="conversation",
        entity_id=str(message.get("message_id")),
        details={"company_id": workspace_id, "role_id": role_id},
    )
    return {"message": "Your message has been shared with the hiring team.", "conversation": message}


@app.delete("/candidate/conversations/{message_id}")
async def delete_candidate_conversation(message_id: str, request: Request) -> dict:
    candidate_account_id = _candidate_account_id(request)
    try:
        deleted = candidate_store.delete_message(candidate_account_id=candidate_account_id, message_id=message_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if not deleted:
        raise HTTPException(status_code=404, detail="Message not found.")
    _audit_candidate(
        request=request,
        action="candidate_message_deleted",
        entity_kind="conversation",
        entity_id=message_id,
        details={"company_id": deleted.get("company_id"), "role_id": deleted.get("role_id")},
    )
    return {"message": "Message deleted successfully.", "message_id": message_id}


@app.post("/candidate/applications")
async def submit_candidate_application(payload: CandidateApplicationDraft, request: Request) -> dict:
    session = _require_candidate_session(request)
    company_id = normalize_workspace_id(payload.company_id)
    company = _company_record(company_id)
    valid_roles = {job.job_id for job in _workspace_jobs(company_id)}
    if not company.get("is_registered") and not valid_roles:
        raise HTTPException(status_code=404, detail="Company workspace not found.")
    if not payload.role_ids:
        raise HTTPException(status_code=400, detail="Select at least one role before submitting.")
    if any(role_id not in valid_roles for role_id in payload.role_ids):
        raise HTTPException(status_code=400, detail="One or more selected roles are not available anymore.")

    candidate_account_id = str(session["candidate_account_id"])
    resume_document = None
    if payload.resume_mode == "upload":
        if not payload.resume_document_id:
            raise HTTPException(status_code=400, detail="Upload a resume before submitting.")
        resume_document = next(
            (
                document
                for document in candidate_store.documents_for_candidate(candidate_account_id)
                if document.get("document_id") == payload.resume_document_id
                and document.get("company_id") == company_id
                and document.get("document_type") == "resume"
            ),
            None,
        )
        if not resume_document:
            raise HTTPException(status_code=404, detail="Resume document not found for this application.")
    elif not payload.profile:
        raise HTTPException(status_code=400, detail="Complete the resume builder before submitting.")

    if payload.profile:
        candidate_store.save_profile(candidate_account_id, payload.profile)

    try:
        application = candidate_store.upsert_application(
            candidate_account_id=candidate_account_id,
            company_id=company_id,
            role_ids=payload.role_ids,
            resume_mode=payload.resume_mode,
            profile_draft=payload.profile,
            resume_document=resume_document,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    stream_path = workspace_source_dir(settings.resume_stream_dir, company_id) / f"{application['company_candidate_id']}.json"
    if stream_path.exists():
        hydrated_candidate = CandidateProfile.model_validate_json(stream_path.read_text(encoding="utf-8"))
        orchestrator.handle_candidate_upsert(hydrated_candidate)
        _refresh_workspace_rankings(company_id, payload.role_ids)
    _audit_candidate(
        request=request,
        action="application_submitted",
        entity_kind="application",
        entity_id=str(application.get("application_id")),
        details={"company_id": company_id, "role_ids": payload.role_ids},
    )

    return {
        "message": "Application submitted. Match scores and recruiter feedback will appear automatically.",
        "application": _candidate_application_dashboard(application),
    }


@app.get("/candidate/applications")
async def candidate_applications(request: Request) -> list[dict]:
    candidate_account_id = _candidate_account_id(request)
    synced_applications = _sync_linked_candidate_applications(candidate_account_id)
    return [
        _candidate_application_dashboard(application)
        for application in synced_applications
    ]


@app.get("/summary")
async def summary(request: Request) -> dict:
    workspace_id = _workspace_id(request)
    payload = _workspace_summary(workspace_id)
    payload["vector_store"] = retriever.statistics()
    return payload


@app.get("/analytics/overview")
async def analytics_overview(request: Request) -> dict:
    return _workspace_analytics(_workspace_id(request))


@app.get("/audit")
async def audit_events(request: Request, limit: int = Query(default=100, ge=1, le=300)) -> list[dict]:
    return audit_log.list_events(workspace_id=_workspace_id(request), limit=limit)


@app.get("/events/stream")
async def stream_workspace_events(request: Request) -> StreamingResponse:
    workspace_id = _workspace_id(request)

    async def event_generator():
        last_revision = -1
        while True:
            if await request.is_disconnected():
                break
            summary_payload = _workspace_summary(workspace_id)
            revision = int(summary_payload.get("quality", {}).get("revision", 0))
            if revision != last_revision:
                event = {
                    "revision": revision,
                    "counts": summary_payload.get("counts", {}),
                    "quality": summary_payload.get("quality", {}),
                    "recent_events": summary_payload.get("recent_events", [])[:5],
                }
                yield f"event: workspace\ndata: {json.dumps(event)}\n\n"
                last_revision = revision
            else:
                yield "event: keepalive\ndata: {}\n\n"
            await asyncio.sleep(1.0)

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.get("/ats/requisitions")
async def list_requisitions(request: Request) -> list[dict]:
    workspace_id = _workspace_id(request)
    for job in _workspace_jobs(workspace_id):
        ats_store.ensure_requisition(workspace_id, job)
    return ats_store.list_requisitions(workspace_id)


@app.post("/ats/requisitions")
async def upsert_requisition(payload: ATSRequisitionDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    job = _workspace_job(workspace_id, payload.job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Role '{payload.job_id}' was not found.")
    requisition = ats_store.upsert_requisition(workspace_id, payload, job)
    _audit_company(request=request, action="requisition_saved", entity_kind="requisition", entity_id=payload.job_id)
    return requisition


@app.post("/ats/approvals")
async def create_approval(payload: ApprovalDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    if not _workspace_job(workspace_id, payload.job_id):
        raise HTTPException(status_code=404, detail=f"Role '{payload.job_id}' was not found.")
    approval = ats_store.request_approval(workspace_id, payload)
    _audit_company(request=request, action="approval_requested", entity_kind="approval", entity_id=approval["approval_id"])
    return approval


@app.post("/ats/approvals/{approval_id}/signoff")
async def signoff_approval(approval_id: str, payload: ApprovalSignoffDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    approval = ats_store.signoff_approval(workspace_id, approval_id, payload)
    if not approval:
        raise HTTPException(status_code=404, detail="Approval request was not found.")
    _audit_company(request=request, action="approval_signed", entity_kind="approval", entity_id=approval_id, details={"decision": payload.decision})
    return approval


@app.get("/ats/jobs/{job_id}/pipeline")
async def ats_pipeline(job_id: str, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    if not _workspace_job(workspace_id, job_id):
        raise HTTPException(status_code=404, detail=f"Role '{job_id}' was not found.")
    snapshot = orchestrator.get_rankings(job_id)
    rankings = snapshot.model_dump(mode="json").get("rankings", []) if snapshot else []
    return ats_store.pipeline_for_job(workspace_id, job_id, rankings)


@app.post("/ats/jobs/{job_id}/candidates/{candidate_id}/stage")
async def advance_candidate_stage(job_id: str, candidate_id: str, payload: CandidateStageDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    if not _workspace_job(workspace_id, job_id) or not _workspace_candidate(workspace_id, candidate_id):
        raise HTTPException(status_code=404, detail="Candidate or role was not found.")
    stage_state = ats_store.advance_candidate_stage(workspace_id, job_id, candidate_id, payload)
    _audit_company(
        request=request,
        action="candidate_stage_advanced",
        entity_kind="candidate_stage",
        entity_id=f"{job_id}:{candidate_id}",
        details={"stage": payload.stage, "decision": payload.decision},
    )
    if payload.decision:
        candidate_store.record_recruiter_feedback(
            company_id=workspace_id,
            company_candidate_id=candidate_id,
            role_id=job_id,
            label=payload.decision,
            notes=payload.notes or f"Moved to {payload.stage}.",
            recruiter=payload.actor,
        )
    return stage_state


@app.post("/ats/interviews")
async def schedule_interview(payload: InterviewDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    if not _workspace_job(workspace_id, payload.job_id) or not _workspace_candidate(workspace_id, payload.candidate_id):
        raise HTTPException(status_code=404, detail="Candidate or role was not found.")
    interview = ats_store.schedule_interview(workspace_id, payload)
    _audit_company(request=request, action="interview_scheduled", entity_kind="interview", entity_id=interview["interview_id"])
    return interview


@app.post("/ats/scorecards")
async def submit_scorecard(payload: ScorecardDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    if not _workspace_job(workspace_id, payload.job_id) or not _workspace_candidate(workspace_id, payload.candidate_id):
        raise HTTPException(status_code=404, detail="Candidate or role was not found.")
    scorecard = ats_store.submit_scorecard(workspace_id, payload)
    _audit_company(request=request, action="scorecard_submitted", entity_kind="scorecard", entity_id=scorecard["scorecard_id"])
    return scorecard


@app.post("/ats/offers")
async def create_offer(payload: OfferDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    if not _workspace_job(workspace_id, payload.job_id) or not _workspace_candidate(workspace_id, payload.candidate_id):
        raise HTTPException(status_code=404, detail="Candidate or role was not found.")
    offer = ats_store.create_offer(workspace_id, payload)
    _audit_company(request=request, action="offer_created", entity_kind="offer", entity_id=offer["offer_id"])
    return offer


@app.post("/ats/comments")
async def add_collaboration_comment(payload: CollaborationCommentDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    if not _workspace_job(workspace_id, payload.job_id):
        raise HTTPException(status_code=404, detail="Role was not found.")
    if payload.candidate_id and not _workspace_candidate(workspace_id, payload.candidate_id):
        raise HTTPException(status_code=404, detail="Candidate was not found.")
    comment = ats_store.add_thread_comment(workspace_id, payload)
    _audit_company(request=request, action="comment_added", entity_kind="comment", entity_id=comment["comment_id"])
    return comment


@app.get("/ats/jobs/{job_id}/candidates/{candidate_id}/packet")
async def candidate_packet(job_id: str, candidate_id: str, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    job = _workspace_job(workspace_id, job_id)
    candidate = _workspace_candidate(workspace_id, candidate_id)
    if not job or not candidate:
        raise HTTPException(status_code=404, detail="Candidate or role was not found.")
    packet = ats_store.candidate_packet(workspace_id, job_id, candidate_id)
    ranking_snapshot = orchestrator.get_rankings(job_id)
    ranking_payload = None
    if ranking_snapshot:
        ranking_payload = next(
            (
                item.model_dump(mode="json")
                for item in ranking_snapshot.rankings
                if item.candidate.candidate_id == candidate_id
            ),
            None,
        )
    verification_summary, documents = _candidate_verification_summary(workspace_id, candidate_id, role_id=job_id)
    application = candidate_store.application_by_company_candidate(workspace_id, candidate_id) or {}
    verification_payload = {
        **application,
        "verification_summary": verification_summary,
        "document_ids": [document.get("document_id") for document in documents if document.get("document_id")],
        "profile_photo_document_id": next(
            (document.get("document_id") for document in documents if document.get("document_type") == "profile_photo" and document.get("document_id")),
            application.get("profile_photo_document_id"),
        ),
    }
    packet["candidate"] = candidate.model_dump(mode="json")
    packet["job"] = job.model_dump(mode="json")
    packet["verification"] = verification_payload
    packet["documents"] = documents
    packet["ranking"] = ranking_payload
    insight = orchestrator.candidate_insight(job_id, candidate_id)
    if insight:
        packet["insight"] = insight
    return packet


@app.get("/events")
async def events(request: Request, audience: str = Query(default="recruiter"), limit: int = Query(default=12, ge=1, le=50)) -> list[dict]:
    workspace_id = _workspace_id(request)
    scoped_events = [
        event.model_dump(mode="json")
        for event in runtime_state.recent_events(audience if audience in {"recruiter", "system"} else None)
        if belongs_to_workspace(entity_id=event.entity_id, source_path=event.entity_id, workspace_id=workspace_id)
    ]
    return scoped_events[:limit]


@app.get("/jobs", response_model=list[JobProfile])
async def list_jobs(request: Request) -> list[JobProfile]:
    return _workspace_jobs(_workspace_id(request))


@app.get("/jobs/{job_id}", response_model=JobProfile)
async def get_job(job_id: str, request: Request) -> JobProfile:
    job = _workspace_job(_workspace_id(request), job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' was not found.")
    return job


@app.post("/jobs")
async def upsert_job_from_form(payload: JobDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    title = payload.title.strip()
    if not title:
        raise HTTPException(status_code=400, detail="Job title is required.")
    if len(re.sub(r"\W+", "", payload.description)) < 20:
        raise HTTPException(status_code=400, detail="Please provide a fuller job description before saving.")
    destination = _job_document_path(title, payload.team, workspace_id=workspace_id)
    job_id = scoped_entity_id(workspace_id, _job_storage_stem(title, payload.team))
    runtime.job_loader.restore_job(job_id)
    raw_bytes = _serialize_job_draft(payload)
    _write_bytes(destination, raw_bytes)
    hydrated_jobs = _hydrate_jobs_from_bytes(
        workspace_id=workspace_id,
        raw_source_path=str(destination),
        raw_bytes=raw_bytes,
        file_name=destination.name,
        source_mode="manual_form",
    )
    _audit_company(
        request=request,
        action="job_saved",
        entity_kind="job",
        entity_id=hydrated_jobs[0].job_id if hydrated_jobs else job_id,
        details={"job_ids": [job.job_id for job in hydrated_jobs]},
    )
    return {
        "message": "Role details saved. Candidate rankings will update automatically.",
        "job_id": hydrated_jobs[0].job_id if hydrated_jobs else job_id,
        "job_ids": [job.job_id for job in hydrated_jobs],
        "path": str(destination),
    }


@app.post("/jobs/uploads")
async def upload_job_file(request: Request, file: UploadFile = File(...)) -> dict:
    workspace_id = _workspace_id(request)
    raw_bytes = await file.read()
    suffix = _ensure_allowed(file.filename, settings.job_upload_types, "Job")
    _ensure_size(raw_bytes, "Job file")
    _ensure_readable_document(file.filename or "job", raw_bytes, "job description", minimum_characters=20)
    destination, job_id = _job_storage_path(file.filename or "job-brief", raw_bytes, suffix, workspace_id)
    runtime.job_loader.restore_job(job_id)
    if _same_file_content(destination, raw_bytes):
        hydrated_jobs = _hydrate_jobs_from_bytes(
            workspace_id=workspace_id,
            raw_source_path=str(destination),
            raw_bytes=raw_bytes,
            file_name=file.filename or destination.name,
            source_mode="manual_upload",
        )
        return {
            "message": "That role document is already available.",
            "status": "unchanged",
            "job_id": hydrated_jobs[0].job_id if hydrated_jobs else job_id,
            "job_ids": [job.job_id for job in hydrated_jobs],
            "path": str(destination),
        }
    _write_bytes(destination, raw_bytes)
    hydrated_jobs = _hydrate_jobs_from_bytes(
        workspace_id=workspace_id,
        raw_source_path=str(destination),
        raw_bytes=raw_bytes,
        file_name=file.filename or destination.name,
        source_mode="manual_upload",
    )
    _audit_company(
        request=request,
        action="job_uploaded",
        entity_kind="job",
        entity_id=hydrated_jobs[0].job_id if hydrated_jobs else job_id,
        details={"file_name": file.filename, "job_ids": [job.job_id for job in hydrated_jobs]},
    )
    return {
        "message": "Role document uploaded. Rankings will refresh automatically.",
        "status": "accepted",
        "job_id": hydrated_jobs[0].job_id if hydrated_jobs else job_id,
        "job_ids": [job.job_id for job in hydrated_jobs],
        "path": str(destination),
    }


@app.delete("/jobs/{job_id}")
async def delete_job(job_id: str, request: Request) -> dict:
    job = _workspace_job(_workspace_id(request), job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' was not found.")
    runtime.job_loader.suppress_job(job_id)
    _delete_path(Path(job.source_path))
    orchestrator.handle_job_remove(job_id)
    _audit_company(request=request, action="job_deleted", entity_kind="job", entity_id=job_id)
    return {"message": f"{job.title} was removed. The shortlist will update automatically."}


@app.get("/candidates", response_model=list[CandidateProfile])
async def list_candidates(request: Request) -> list[CandidateProfile]:
    return _workspace_candidates(_workspace_id(request))


@app.get("/candidates/{candidate_id}", response_model=CandidateProfile)
async def get_candidate(candidate_id: str, request: Request) -> CandidateProfile:
    candidate = _workspace_candidate(_workspace_id(request), candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate '{candidate_id}' was not found.")
    return candidate


@app.get("/candidates/{candidate_id}/documents")
async def recruiter_candidate_documents(candidate_id: str, request: Request, job_id: str | None = None) -> list[dict]:
    workspace_id = _workspace_id(request)
    candidate = _workspace_candidate(workspace_id, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate '{candidate_id}' was not found.")
    return candidate_store.documents_for_company_candidate(workspace_id, candidate_id, role_id=job_id)


@app.get("/candidates/{candidate_id}/verification")
async def recruiter_candidate_verification(candidate_id: str, request: Request, job_id: str | None = None) -> dict:
    workspace_id = _workspace_id(request)
    candidate = _workspace_candidate(workspace_id, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate '{candidate_id}' was not found.")
    verification_summary, documents = _candidate_verification_summary(workspace_id, candidate_id, role_id=job_id)
    return {
        "candidate_id": candidate_id,
        "verification_summary": verification_summary,
        "documents": documents,
    }


@app.get("/candidates/{candidate_id}/conversations")
async def recruiter_candidate_conversations(candidate_id: str, request: Request, job_id: str | None = None) -> list[dict]:
    workspace_id = _workspace_id(request)
    candidate = _workspace_candidate(workspace_id, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate '{candidate_id}' was not found.")
    linked_application = _ensure_linked_application_for_company_candidate(
        workspace_id=workspace_id,
        candidate_id=candidate_id,
        role_ids=[job_id] if job_id else None,
    )
    if not linked_application:
        return []
    return candidate_store.list_messages_for_company_candidate(
        company_id=workspace_id,
        company_candidate_id=candidate_id,
        role_id=job_id,
    )


@app.post("/candidates/{candidate_id}/conversations")
async def recruiter_candidate_reply(
    candidate_id: str,
    payload: RecruiterConversationDraft,
    request: Request,
) -> dict:
    workspace_id = _workspace_id(request)
    candidate = _workspace_candidate(workspace_id, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate '{candidate_id}' was not found.")
    linked_application = _ensure_linked_application_for_company_candidate(
        workspace_id=workspace_id,
        candidate_id=candidate_id,
        role_ids=[payload.role_id] if payload.role_id else None,
    )
    if not linked_application:
        raise HTTPException(status_code=404, detail="This candidate is not linked to a portal account yet.")
    session = _require_session(request)
    reply = candidate_store.post_message(
        company_id=workspace_id,
        candidate_account_id=str(linked_application.get("candidate_account_id") or ""),
        company_candidate_id=candidate_id,
        role_id=payload.role_id,
        sender_type="company",
        sender_name=str(payload.author or session.get("admin_name") or "Recruiter"),
        message=payload.message,
        application_id=str(linked_application.get("application_id") or ""),
    )
    _audit_company(
        request=request,
        action="recruiter_message_posted",
        entity_kind="conversation",
        entity_id=str(reply.get("message_id")),
        details={"candidate_id": candidate_id, "job_id": payload.role_id},
    )
    return {"message": "Reply sent to the candidate.", "conversation": reply}


@app.post("/candidates/{candidate_id}/verification/review")
async def recruiter_candidate_verification_review(
    candidate_id: str,
    payload: VerificationReviewDraft,
    request: Request,
) -> dict:
    workspace_id = _workspace_id(request)
    candidate = _workspace_candidate(workspace_id, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate '{candidate_id}' was not found.")
    linked_application = _ensure_linked_application_for_company_candidate(
        workspace_id=workspace_id,
        candidate_id=candidate_id,
        role_ids=[payload.job_id] if payload.job_id else None,
    )
    if not linked_application:
        raise HTTPException(status_code=404, detail="This candidate is not linked to a portal account yet.")
    session = _require_session(request)
    updated = candidate_store.record_verification_review(
        company_id=workspace_id,
        company_candidate_id=candidate_id,
        role_id=payload.job_id,
        decision=payload.decision,
        notes=text(payload.notes),
        reviewer=text(payload.reviewer, text(session.get("admin_name"), "Recruiter")),
    )
    if not updated:
        raise HTTPException(status_code=404, detail="Candidate application was not found.")
    _audit_company(
        request=request,
        action="verification_reviewed",
        entity_kind="verification",
        entity_id=candidate_id,
        details={"job_id": payload.job_id, "decision": payload.decision},
    )
    return {
        "message": "Verification updated and shared with the candidate.",
        "application": _candidate_application_dashboard(updated),
    }


@app.post("/candidates/uploads")
async def upload_candidates(request: Request, files: list[UploadFile] = File(...)) -> dict:
    workspace_id = _workspace_id(request)
    if not files:
        raise HTTPException(status_code=400, detail="Upload at least one resume.")
    results: list[dict] = []
    for upload in files:
        raw_bytes = await upload.read()
        try:
            suffix = _ensure_allowed(upload.filename, settings.resume_upload_types, "Resume")
            _ensure_size(raw_bytes, "Resume")
            _ensure_readable_document(upload.filename or "resume", raw_bytes, "resume", minimum_characters=25)
            destination, candidate_id, matched_existing = _candidate_storage_path(upload.filename or "candidate-resume", raw_bytes, suffix, workspace_id)
            runtime.resume_loader.restore_candidate(candidate_id)
            if _same_file_content(destination, raw_bytes):
                preview = _candidate_upload_result(destination, raw_bytes)
                _hydrate_candidates_from_bytes(
                    workspace_id=workspace_id,
                    raw_source_path=str(destination),
                    raw_bytes=raw_bytes,
                    file_name=upload.filename or destination.name,
                    source_mode="manual_upload",
                    preferred_candidate_id=candidate_id,
                )
                results.append(
                    {
                        **preview,
                        "status": "unchanged",
                        "message": f"{preview['candidate_name']} is already up to date.",
                    }
                )
                continue
            _write_bytes(destination, raw_bytes)
            hydrated_candidates = _hydrate_candidates_from_bytes(
                workspace_id=workspace_id,
                raw_source_path=str(destination),
                raw_bytes=raw_bytes,
                file_name=upload.filename or destination.name,
                source_mode="manual_upload",
                preferred_candidate_id=candidate_id,
            )
            preview = _candidate_upload_result(destination, raw_bytes)
            candidate_count = int(preview.get("candidate_count", 1))
            if candidate_count == 1:
                message = (
                    f"{preview['candidate_name']}'s profile was refreshed and is being ranked now."
                    if matched_existing
                    else f"{preview['candidate_name']} was added and is being ranked now."
                )
            else:
                message = (
                    f"{candidate_count} candidate profiles were refreshed from {upload.filename}."
                    if matched_existing
                    else f"{candidate_count} candidate profiles were added from {upload.filename}."
                )
            results.append(
                {
                    **preview,
                    "candidate_id": candidate_id,
                    "status": "accepted",
                    "message": message,
                }
            )
            _audit_company(
                request=request,
                action="candidate_uploaded",
                entity_kind="candidate",
                entity_id=(hydrated_candidates[0].candidate_id if hydrated_candidates else candidate_id),
                details={"file_name": upload.filename, "candidate_count": len(hydrated_candidates)},
            )
        except HTTPException as exc:
            results.append(
                {
                    "file_name": upload.filename,
                    "status": "rejected",
                    "message": exc.detail,
                }
            )
        except Exception:
            results.append(
                {
                    "file_name": upload.filename,
                    "status": "rejected",
                    "message": "This resume could not be processed. Please try another file or a clearer export.",
                }
            )
    return {"results": results}


@app.post("/candidates/{candidate_id}/resume")
async def replace_candidate_resume(candidate_id: str, request: Request, file: UploadFile = File(...)) -> dict:
    workspace_id = _workspace_id(request)
    candidate = _workspace_candidate(workspace_id, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate '{candidate_id}' was not found.")
    raw_bytes = await file.read()
    suffix = _ensure_allowed(file.filename, settings.resume_upload_types, "Resume")
    _ensure_size(raw_bytes, "Resume")
    _ensure_readable_document(file.filename or "resume", raw_bytes, "resume", minimum_characters=25)

    destination = workspace_source_dir(settings.resume_stream_dir, workspace_id) / f"{candidate_id}.json"
    parsed = _preview_resume_records(file.filename or "resume", raw_bytes, file.filename or "resume")[0]
    runtime.resume_loader.restore_candidate(candidate_id)
    updated_candidate = parsed.model_copy(
        update={
            "candidate_id": candidate_id,
            "source_path": str(destination),
            "origin_source_path": (candidate.model_extra or {}).get("origin_source_path", candidate.source_path),
            "source_mode": "manual_override",
        }
    )
    serialized_candidate = updated_candidate.model_dump_json(indent=2)
    if destination.exists() and destination.read_text(encoding="utf-8", errors="ignore") == serialized_candidate:
        orchestrator.handle_candidate_upsert(updated_candidate)
        _refresh_workspace_rankings(workspace_id)
        return {"message": f"{candidate.name}'s resume is already current.", "status": "unchanged", "path": str(destination)}
    runtime.resume_loader.suppress_candidate(candidate_id)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = settings.cache_dir / f"{destination.name}.{time.time_ns()}.tmp"
    temporary.parent.mkdir(parents=True, exist_ok=True)
    temporary.write_text(serialized_candidate, encoding="utf-8")
    temporary.replace(destination)
    orchestrator.handle_candidate_upsert(updated_candidate)
    _refresh_workspace_rankings(workspace_id)
    _audit_company(request=request, action="candidate_resume_replaced", entity_kind="candidate", entity_id=candidate_id)
    return {"message": f"{candidate.name}'s profile was refreshed and will rerank automatically.", "status": "accepted", "path": str(destination)}


@app.delete("/candidates/{candidate_id}")
async def delete_candidate(candidate_id: str, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    candidate = _workspace_candidate(workspace_id, candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate '{candidate_id}' was not found.")
    runtime.resume_loader.suppress_candidate(candidate_id)
    _delete_path(Path(candidate.source_path))
    orchestrator.handle_candidate_remove(candidate_id)
    _refresh_workspace_rankings(workspace_id)
    _audit_company(request=request, action="candidate_deleted", entity_kind="candidate", entity_id=candidate_id)
    return {"message": f"{candidate.name} was removed from the candidate list."}


@app.get("/feedback")
async def list_feedback(request: Request) -> list[dict]:
    return [entry.model_dump(mode="json") for entry in _workspace_feedback(_workspace_id(request))]


@app.delete("/feedback/{feedback_id}")
async def delete_feedback(feedback_id: str, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    feedback = _workspace_feedback_entry(workspace_id, feedback_id)
    if not feedback:
        raise HTTPException(status_code=404, detail=f"Review '{feedback_id}' was not found.")

    source_entries = [entry for entry in _workspace_feedback(workspace_id) if entry.source_path == feedback.source_path]
    remaining_entries = [entry for entry in source_entries if entry.feedback_id != feedback_id]
    source_path = Path(feedback.source_path)

    if not source_path.exists():
        orchestrator.handle_feedback_remove(feedback.source_path)
        _refresh_workspace_rankings(workspace_id, [entry.job_id for entry in source_entries if entry.job_id] or None)
        _audit_company(request=request, action="feedback_deleted", entity_kind="feedback", entity_id=feedback_id)
        return {"message": "Review removed. Candidate rankings will update automatically."}

    if not remaining_entries:
        _delete_path(source_path)
        orchestrator.handle_feedback_remove(feedback.source_path)
        _refresh_workspace_rankings(workspace_id, [entry.job_id for entry in source_entries if entry.job_id] or None)
        _audit_company(request=request, action="feedback_deleted", entity_kind="feedback", entity_id=feedback_id)
        return {"message": "Review removed. Candidate rankings will update automatically."}

    editable_suffixes = {".json", ".txt", ".yaml", ".yml"}
    if source_path.suffix.lower() not in editable_suffixes:
        raise HTTPException(
            status_code=400,
            detail="This review came from a bundled source file. Remove the original source file to remove all reviews from it.",
        )

    _write_bytes(source_path, _serialize_feedback_entries(remaining_entries))
    orchestrator.handle_feedback_replace(feedback.source_path, remaining_entries)
    _refresh_workspace_rankings(workspace_id, [entry.job_id for entry in remaining_entries if entry.job_id] or None)
    _audit_company(request=request, action="feedback_deleted", entity_kind="feedback", entity_id=feedback_id)
    return {"message": "Review removed. Candidate rankings will update automatically."}


@app.get("/datasets/catalog")
async def list_public_datasets() -> list[dict]:
    return public_dataset_catalog(DATASET_CATALOG_PATH)


@app.get("/datasets/kaggle")
async def list_kaggle_datasets() -> list[dict]:
    return kaggle_dataset_catalog()


@app.post("/datasets/kaggle/sync")
async def sync_kaggle_dataset_sources(payload: KaggleSyncRequest) -> dict:
    try:
        result = sync_kaggle_datasets(
            settings,
            preset_ids=payload.preset_ids,
            dataset_slugs=payload.dataset_slugs,
            force=payload.force,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Kaggle sync failed. {exc}") from exc
    result["message"] = result["message"] + " Live rankings will update automatically."
    return result


@app.post("/datasets/import-bundle")
async def upload_dataset_bundle(file: UploadFile = File(...)) -> dict:
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in SUPPORTED_BUNDLE_TYPES:
        raise HTTPException(status_code=400, detail="Dataset imports must be uploaded as a ZIP bundle.")
    raw_bytes = await file.read()
    _ensure_dataset_bundle_size(raw_bytes)
    try:
        return import_dataset_bundle(raw_bytes, file.filename or "dataset.zip", settings)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"We could not unpack this dataset bundle. {exc}") from exc


@app.post("/feedback")
async def add_feedback(payload: FeedbackDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    candidate = _workspace_candidate(workspace_id, payload.candidate_id)
    if not candidate:
        raise HTTPException(status_code=404, detail="Choose a valid candidate before saving recruiter notes.")
    if payload.job_id and not _workspace_job(workspace_id, payload.job_id):
        raise HTTPException(status_code=404, detail="Choose a valid role before saving recruiter notes.")
    if len(re.sub(r"\W+", "", payload.notes)) < 8:
        raise HTTPException(status_code=400, detail="Please add a more descriptive recruiter note.")
    destination = _feedback_document_path(payload.candidate_id, workspace_id)
    raw_bytes = _serialize_feedback_draft(payload)
    _write_bytes(destination, raw_bytes)
    _hydrate_feedback_from_bytes(
        workspace_id=workspace_id,
        raw_source_path=str(destination),
        raw_bytes=raw_bytes,
        file_name=destination.name,
    )
    _ensure_linked_application_for_company_candidate(
        workspace_id=workspace_id,
        candidate_id=payload.candidate_id,
        role_ids=[payload.job_id] if payload.job_id else None,
    )
    candidate_store.record_recruiter_feedback(
        company_id=workspace_id,
        company_candidate_id=payload.candidate_id,
        role_id=payload.job_id,
        label=payload.label,
        notes=payload.notes,
        recruiter=payload.recruiter,
    )
    _audit_company(
        request=request,
        action="feedback_added",
        entity_kind="feedback",
        entity_id=payload.candidate_id,
        details={"job_id": payload.job_id, "label": payload.label},
    )
    return {"message": "Recruiter notes saved. Ranking updates will follow automatically.", "path": str(destination)}


@app.post("/feedback/uploads")
async def upload_feedback_file(request: Request, file: UploadFile = File(...)) -> dict:
    workspace_id = _workspace_id(request)
    raw_bytes = await file.read()
    _ensure_allowed(file.filename, settings.feedback_upload_types, "Feedback")
    _ensure_size(raw_bytes, "Feedback file")
    _ensure_readable_document(file.filename or "feedback", raw_bytes, "feedback file", minimum_characters=10)
    destination = workspace_source_dir(settings.feedback_dir, workspace_id) / _safe_filename(file.filename, f"feedback-{int(time.time())}")
    if _same_file_content(destination, raw_bytes):
        hydrated_entries = _hydrate_feedback_from_bytes(
            workspace_id=workspace_id,
            raw_source_path=str(destination),
            raw_bytes=raw_bytes,
            file_name=file.filename or destination.name,
        )
        for entry in hydrated_entries:
            _ensure_linked_application_for_company_candidate(
                workspace_id=workspace_id,
                candidate_id=entry.candidate_id,
                role_ids=[entry.job_id] if entry.job_id else None,
            )
            candidate_store.record_recruiter_feedback(
                company_id=workspace_id,
                company_candidate_id=entry.candidate_id,
                role_id=entry.job_id,
                label=entry.label,
                notes=entry.notes,
                recruiter=entry.recruiter,
            )
        return {"message": "That feedback file is already available.", "status": "unchanged", "path": str(destination)}
    _write_bytes(destination, raw_bytes)
    hydrated_entries = _hydrate_feedback_from_bytes(
        workspace_id=workspace_id,
        raw_source_path=str(destination),
        raw_bytes=raw_bytes,
        file_name=file.filename or destination.name,
    )
    for entry in hydrated_entries:
        _ensure_linked_application_for_company_candidate(
            workspace_id=workspace_id,
            candidate_id=entry.candidate_id,
            role_ids=[entry.job_id] if entry.job_id else None,
        )
        candidate_store.record_recruiter_feedback(
            company_id=workspace_id,
            company_candidate_id=entry.candidate_id,
            role_id=entry.job_id,
            label=entry.label,
            notes=entry.notes,
            recruiter=entry.recruiter,
        )
    _audit_company(
        request=request,
        action="feedback_uploaded",
        entity_kind="feedback",
        entity_id=str(destination),
        details={"file_name": file.filename},
    )
    return {"message": "Feedback file uploaded. Candidate rankings will adapt automatically.", "status": "accepted", "path": str(destination)}


@app.get("/jobs/{job_id}/rankings")
async def get_rankings(job_id: str, request: Request) -> dict:
    if not _workspace_job(_workspace_id(request), job_id):
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' was not found.")
    snapshot = orchestrator.get_rankings(job_id)
    if not snapshot:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' was not found.")
    return snapshot.model_dump(mode="json")


@app.get("/jobs/{job_id}/insights")
async def get_job_insights(job_id: str, request: Request) -> dict:
    if not _workspace_job(_workspace_id(request), job_id):
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' was not found.")
    insights = orchestrator.job_insights(job_id)
    if not insights:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' was not found.")
    return insights


@app.get("/jobs/{job_id}/candidates/{candidate_id}/insight")
async def get_candidate_insight(job_id: str, candidate_id: str, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    if not _workspace_job(workspace_id, job_id) or not _workspace_candidate(workspace_id, candidate_id):
        raise HTTPException(status_code=404, detail=f"Candidate '{candidate_id}' was not found for role '{job_id}'.")
    insight = orchestrator.candidate_insight(job_id, candidate_id)
    if not insight:
        raise HTTPException(status_code=404, detail=f"Candidate '{candidate_id}' was not found for role '{job_id}'.")
    return insight


@app.get("/jobs/{job_id}/compare")
async def compare_candidates(job_id: str, left_candidate_id: str, right_candidate_id: str, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    if not _workspace_job(workspace_id, job_id):
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' was not found.")
    if not _workspace_candidate(workspace_id, left_candidate_id) or not _workspace_candidate(workspace_id, right_candidate_id):
        raise HTTPException(status_code=404, detail="Could not compare the requested candidates for this role.")
    comparison = orchestrator.compare(job_id, left_candidate_id, right_candidate_id)
    if not comparison:
        raise HTTPException(status_code=404, detail="Could not compare the requested candidates for this role.")
    return comparison


@app.post("/jobs/{job_id}/ask")
async def ask_about_job(job_id: str, payload: RecruiterQuestion, request: Request) -> dict:
    if not _workspace_job(_workspace_id(request), job_id):
        raise HTTPException(status_code=404, detail=f"Role '{job_id}' was not found.")
    answer = orchestrator.answer_question(job_id, payload.question)
    if answer is None:
        raise HTTPException(status_code=404, detail=f"Role '{job_id}' was not found.")
    return answer.model_dump(mode="json")


@app.post("/jobs/{job_id}/simulate")
async def simulate_job(job_id: str, payload: JobDraft, request: Request) -> dict:
    workspace_id = _workspace_id(request)
    current_job = _workspace_job(workspace_id, job_id)
    if not current_job:
        raise HTTPException(status_code=404, detail=f"Role '{job_id}' was not found.")
    simulated_job = _merge_job_draft(current_job, payload)
    current_snapshot = orchestrator.get_rankings(job_id)
    simulated_snapshot = ranking_service.rank_job(
        job=simulated_job,
        candidates=_workspace_candidates(workspace_id),
        feedback_entries=[
            entry
            for entry in _workspace_feedback(workspace_id)
            if not entry.job_id or entry.job_id == job_id
        ],
        retrieval_hits=retriever.query_for_job(simulated_job, k=settings.retrieval_top_k, workspace_id=workspace_id),
        previous_snapshot=current_snapshot,
        source_revision=runtime_state.revision,
    )
    current_positions = {
        item.candidate.candidate_id: item.rank
        for item in (current_snapshot.rankings if current_snapshot else [])
    }
    changes = []
    for item in simulated_snapshot.rankings[:6]:
        previous_rank = current_positions.get(item.candidate.candidate_id)
        if previous_rank != item.rank:
            changes.append(
                {
                    "candidate_id": item.candidate.candidate_id,
                    "name": item.candidate.name,
                    "previous_rank": previous_rank,
                    "projected_rank": item.rank,
                    "score": item.breakdown.total_score,
                }
            )
    return {
        "job_id": job_id,
        "headline": simulated_snapshot.insight_summary,
        "projected_rankings": simulated_snapshot.model_dump(mode="json")["rankings"][:6],
        "changes": changes,
        "preview_job": {
            "title": simulated_job.title,
            "must_have_skills": simulated_job.must_have_skills,
            "nice_to_have_skills": simulated_job.nice_to_have_skills,
            "hiring_target": simulated_job.hiring_target,
            "min_years_experience": simulated_job.min_years_experience,
            "education_requirement": simulated_job.education_requirement,
        },
    }


# Compatibility endpoints for existing integrations.
@app.post("/ingest/resume")
async def upload_resume_legacy(request: Request, file: UploadFile = File(...)) -> dict:
    result = await upload_candidates(request, [file])
    return result["results"][0]


@app.post("/ingest/job")
async def upload_job_legacy(request: Request, file: UploadFile = File(...)) -> dict:
    return await upload_job_file(request, file)


@app.post("/ingest/feedback")
async def upload_feedback_legacy(request: Request, file: UploadFile = File(...)) -> dict:
    return await upload_feedback_file(request, file)
