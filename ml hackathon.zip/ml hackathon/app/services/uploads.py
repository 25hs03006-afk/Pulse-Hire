from __future__ import annotations

import hashlib
from pathlib import Path

from app.models import CandidateProfile
from app.services.parsers.extractors import slugify_identifier
from app.services.workspaces import scoped_entity_id


def _identity_hash(*parts: str | None) -> str:
    payload = "||".join(part.strip().lower() for part in parts if part and part.strip())
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()[:8] if payload else hashlib.sha1(b"candidate").hexdigest()[:8]


def _find_existing_candidate_match(preview: CandidateProfile, existing_candidates: list[CandidateProfile]) -> CandidateProfile | None:
    preview_name = (preview.name or "").strip().lower()
    preview_location = (preview.location or "").strip().lower()
    preview_title = (preview.current_title or "").strip().lower()
    preview_email = (preview.email or "").strip().lower()
    preview_phone = (preview.phone or "").strip()
    same_name_candidates = [
        existing
        for existing in existing_candidates
        if (existing.name or "").strip().lower() == preview_name and preview_name
    ]

    for existing in existing_candidates:
        existing_name = (existing.name or "").strip().lower()
        existing_location = (existing.location or "").strip().lower()
        existing_title = (existing.current_title or "").strip().lower()
        existing_email = (existing.email or "").strip().lower()
        existing_phone = (existing.phone or "").strip()

        same_email = bool(preview_email and existing_email and preview_email == existing_email)
        same_phone = bool(preview_phone and existing_phone and preview_phone == existing_phone)
        same_name_and_location = bool(preview_name and existing_name and preview_name == existing_name and preview_location and preview_location == existing_location)
        same_name_and_title = bool(preview_name and existing_name and preview_name == existing_name and preview_title and preview_title == existing_title)
        same_name_unique = bool(preview_name and existing_name and preview_name == existing_name and len(same_name_candidates) == 1)

        if same_email or same_phone or same_name_and_location or same_name_and_title or same_name_unique:
            return existing
    return None


def resolve_candidate_upload_destination(
    *,
    preview: CandidateProfile,
    suffix: str,
    resumes_dir: Path,
    existing_candidates: list[CandidateProfile],
    raw_bytes: bytes,
    workspace_id: str = "sample",
) -> tuple[Path, str, bool]:
    if suffix != ".csv":
        existing = _find_existing_candidate_match(preview, existing_candidates)
        if existing:
            return resumes_dir / f"{existing.candidate_id}{suffix}", existing.candidate_id, True

    display_name = preview.name if preview.name and preview.name != "Unknown Candidate" else "candidate"
    base_stem = slugify_identifier(display_name or "candidate")
    fingerprint = _identity_hash(
        preview.email,
        preview.phone,
        preview.name,
        preview.location,
        preview.current_title,
    )
    candidate_id = f"{base_stem}-{fingerprint}"

    if any(candidate.candidate_id == candidate_id and candidate.name.strip().lower() != preview.name.strip().lower() for candidate in existing_candidates):
        candidate_id = f"{base_stem}-{hashlib.sha1(raw_bytes).hexdigest()[:8]}"

    candidate_id = scoped_entity_id(workspace_id, candidate_id)
    return resumes_dir / f"{candidate_id}{suffix}", candidate_id, False
