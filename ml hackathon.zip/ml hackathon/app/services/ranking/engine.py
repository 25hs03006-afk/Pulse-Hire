from __future__ import annotations

from collections import defaultdict
from datetime import UTC, datetime
from typing import Iterable

from app.config import Settings
from app.models import (
    CandidateProfile,
    CandidateRanking,
    FeedbackEntry,
    JobProfile,
    RankingBreakdown,
    RankingSnapshot,
    ResumeEvidence,
    RetrievalHit,
)
from app.services.skills import grouped_overlap


def _as_lower_set(items: Iterable[str]) -> set[str]:
    return {item.lower().strip() for item in items if item and item.strip()}


def _score_overlap(candidate_items: Iterable[str], job_items: Iterable[str]) -> tuple[float, list[str], list[str]]:
    candidate_set = _as_lower_set(candidate_items)
    original_job_items = [item for item in job_items if item]
    job_set = _as_lower_set(original_job_items)
    if not job_set:
        return 1.0, [], []
    matched = sorted(item for item in original_job_items if item.lower().strip() in candidate_set)
    missing = sorted(item for item in original_job_items if item.lower().strip() not in candidate_set)
    return len(matched) / max(len(job_set), 1), matched, missing


def _score_experience(candidate: CandidateProfile, job: JobProfile) -> float:
    if not job.min_years_experience:
        return 1.0 if candidate.years_experience > 0 else 0.45
    ratio = candidate.years_experience / job.min_years_experience
    if ratio >= 1:
        return min(1.0, 0.82 + (ratio - 1) * 0.09)
    return max(0.0, ratio)


def _score_education(candidate: CandidateProfile, job: JobProfile) -> float:
    if not job.education_requirement:
        return 1.0
    requirement = job.education_requirement.lower()
    candidate_text = " ".join(candidate.education).lower()
    if requirement == "phd":
        return 1.0 if "phd" in candidate_text or "doctor" in candidate_text else 0.2
    if requirement == "masters":
        return 1.0 if any(token in candidate_text for token in ("master", "m.tech", "m.s", "mba", "phd", "doctor")) else 0.35
    if requirement == "bachelors":
        return 1.0 if any(token in candidate_text for token in ("bachelor", "b.tech", "b.e", "b.s", "master", "phd")) else 0.45
    return 0.5


def _score_keywords(candidate: CandidateProfile, job: JobProfile) -> tuple[float, list[str]]:
    if not job.keywords:
        return 0.5, []
    candidate_text = " ".join(
        candidate.skills
        + candidate.experience_highlights
        + candidate.projects
        + [candidate.summary, candidate.raw_text[:1000]]
    ).lower()
    matched = sorted([keyword for keyword in job.keywords if keyword and keyword.lower() in candidate_text])
    return min(1.0, len(matched) / max(len(job.keywords), 1)), matched[:8]


def _aggregate_feedback(feedback_entries: list[FeedbackEntry]) -> float:
    if not feedback_entries:
        return 0.0
    now = datetime.now(UTC)
    total_weight = 0.0
    weighted = 0.0
    for entry in feedback_entries:
        age_days = max((now - entry.created_at.astimezone(UTC)).total_seconds() / 86400, 0.0)
        decay = max(0.55, 1.0 - min(age_days, 30) / 80.0)
        weighted += entry.score_adjustment * decay
        total_weight += decay
    score = weighted / total_weight if total_weight else 0.0
    return max(-1.0, min(1.0, score))


def _score_recency(candidate: CandidateProfile) -> float:
    age_days = max((datetime.now(UTC) - candidate.last_updated.astimezone(UTC)).total_seconds() / 86400, 0.0)
    if age_days <= 7:
        return 1.0
    if age_days <= 30:
        return max(0.75, 1.0 - (age_days - 7) / 92.0)
    if age_days <= 180:
        return max(0.45, 0.75 - (age_days - 30) / 300.0)
    return 0.35


def _score_profile_quality(candidate: CandidateProfile) -> float:
    if candidate.completeness_score:
        return candidate.completeness_score
    signals = [
        bool(candidate.summary.strip()),
        bool(candidate.current_title),
        bool(candidate.skills),
        bool(candidate.education),
        bool(candidate.experience_highlights),
        candidate.years_experience > 0,
    ]
    return sum(1 for item in signals if item) / len(signals)


def _fit_band(total_score: float) -> str:
    if total_score >= 0.84:
        return "excellent"
    if total_score >= 0.72:
        return "strong"
    if total_score >= 0.58:
        return "promising"
    if total_score >= 0.44:
        return "partial"
    return "weak"


def _decision_signal(total_score: float, missing_skills: list[str], feedback_score: float) -> str:
    if total_score >= 0.82 and not missing_skills and feedback_score >= -0.05:
        return "Move to interview"
    if total_score >= 0.70 and len(missing_skills) <= 1:
        return "Shortlist for recruiter review"
    if total_score >= 0.55:
        return "Keep warm for targeted follow-up"
    return "Hold until fit improves"


def _confidence_score(
    *,
    retrieval_score: float,
    must_have_score: float,
    grouped_skill_score: float,
    profile_quality: float,
    evidence_count: int,
) -> float:
    evidence_score = min(1.0, evidence_count / 2.0)
    return max(
        0.0,
        min(
            1.0,
            retrieval_score * 0.32
            + must_have_score * 0.28
            + grouped_skill_score * 0.12
            + profile_quality * 0.18
            + evidence_score * 0.10,
        ),
    )


def _stability_score(
    *,
    confidence_score: float,
    must_have_score: float,
    profile_quality: float,
    risk_penalty: float,
    total_score: float,
    previous_total: float,
    has_previous_rank: bool,
) -> float:
    change_penalty = min(0.20, abs(total_score - previous_total) * 1.6) if has_previous_rank else 0.06
    base = (
        confidence_score * 0.45
        + must_have_score * 0.20
        + profile_quality * 0.20
        + max(0.0, 1.0 - min(risk_penalty / 0.30, 1.0)) * 0.15
    )
    return max(0.0, min(1.0, base - change_penalty))


def _strengths(
    candidate: CandidateProfile,
    matched_skills: list[str],
    matched_skill_groups: list[str],
    matched_keywords: list[str],
    experience_score: float,
    feedback_score: float,
    profile_quality: float,
    confidence_score: float,
) -> list[str]:
    strengths: list[str] = []
    if matched_skills:
        strengths.append("Core skills aligned: " + ", ".join(matched_skills[:4]))
    if matched_skill_groups:
        strengths.append("Skill families aligned across " + ", ".join(matched_skill_groups[:3]))
    if experience_score >= 0.9:
        strengths.append(f"Experience depth meets or exceeds the role target at {candidate.years_experience:.1f} years")
    if matched_keywords:
        strengths.append("Relevant delivery evidence found for " + ", ".join(matched_keywords[:4]))
    if feedback_score > 0.12:
        strengths.append("Recruiter feedback is directionally positive")
    if profile_quality >= 0.75:
        strengths.append("Resume profile is well structured and information-rich")
    if confidence_score >= 0.75:
        strengths.append("Decision confidence is high because the evidence and structured fit agree")
    return strengths[:4]


def _risks(
    missing_skills: list[str],
    missing_skill_groups: list[str],
    missing_optional: list[str],
    feedback_score: float,
    profile_quality: float,
    candidate: CandidateProfile,
    confidence_score: float,
) -> list[str]:
    risks: list[str] = []
    if missing_skills:
        risks.append("Still missing critical requirements: " + ", ".join(missing_skills[:4]))
    elif missing_skill_groups:
        risks.append("Coverage is still thin across " + ", ".join(missing_skill_groups[:3]))
    elif missing_optional:
        risks.append("Optional skill depth could improve in " + ", ".join(missing_optional[:3]))
    if feedback_score < -0.08:
        risks.append("Recent recruiter feedback introduces caution")
    if profile_quality < 0.55:
        risks.append("Resume detail is incomplete, reducing confidence in the ranking")
    if confidence_score < 0.48:
        risks.append("Evidence confidence is still modest, so this rank should be validated in interview")
    if candidate.duplicate_of:
        risks.append("Potential duplicate profile detected in the live pool")
    return risks[:4]


def _interview_focus(
    missing_skills: list[str],
    missing_optional: list[str],
    matched_keywords: list[str],
    candidate: CandidateProfile,
) -> list[str]:
    prompts: list[str] = []
    if missing_skills:
        prompts.append("Probe depth in " + ", ".join(missing_skills[:3]))
    elif missing_optional:
        prompts.append("Validate growth potential in " + ", ".join(missing_optional[:3]))
    if matched_keywords:
        prompts.append("Ask for measurable outcomes tied to " + ", ".join(matched_keywords[:3]))
    if candidate.projects:
        prompts.append("Use project work to test production ownership and execution quality")
    return prompts[:3] or ["Validate hands-on experience with the role's production constraints"]


def _movement_summary(
    candidate_id: str,
    rank: int,
    total_score: float,
    previous_rank: int,
    previous_total: float,
    previous_breakdown: RankingBreakdown | None,
    current_breakdown: RankingBreakdown,
) -> tuple[float, int, str]:
    score_delta = round(total_score - previous_total, 4)
    rank_delta = 0 if previous_rank == 0 else previous_rank - rank
    if previous_rank == 0:
        return score_delta, rank_delta, "Newly entered the live ranking after the latest ingestion update."
    if score_delta == 0 and rank_delta == 0:
        return score_delta, rank_delta, "Position held steady against the rest of the live candidate pool."
    reasons: list[str] = []
    if previous_breakdown:
        component_changes = {
            "retrieval evidence": current_breakdown.retrieval_score - previous_breakdown.retrieval_score,
            "must-have coverage": current_breakdown.must_have_score - previous_breakdown.must_have_score,
            "experience fit": current_breakdown.experience_score - previous_breakdown.experience_score,
            "feedback signal": current_breakdown.feedback_score - previous_breakdown.feedback_score,
            "profile quality": current_breakdown.profile_quality_score - previous_breakdown.profile_quality_score,
        }
        for label, value in sorted(component_changes.items(), key=lambda item: abs(item[1]), reverse=True):
            if abs(value) >= 0.02:
                reasons.append(f"{label} {'improved' if value > 0 else 'softened'}")
            if len(reasons) == 2:
                break
    change_bits: list[str] = []
    if rank_delta > 0:
        change_bits.append(f"Moved up {rank_delta} place(s)")
    elif rank_delta < 0:
        change_bits.append(f"Moved down {abs(rank_delta)} place(s)")
    if score_delta:
        change_bits.append(f"score changed by {score_delta:+.2f}")
    if reasons:
        change_bits.append("because " + " and ".join(reasons))
    return score_delta, rank_delta, ". ".join(change_bits) + "." if change_bits else "Snapshot refreshed."


def _build_explanation(
    candidate: CandidateProfile,
    job: JobProfile,
    breakdown: RankingBreakdown,
    strengths: list[str],
    risks: list[str],
    evidence: list[ResumeEvidence],
    feedback_entries: list[FeedbackEntry],
) -> str:
    segments: list[str] = []
    if strengths:
        segments.append(strengths[0] + ".")
    if breakdown.missing_must_have_skills:
        segments.append("Critical gaps remain in " + ", ".join(breakdown.missing_must_have_skills[:3]) + ".")
    elif breakdown.matched_skills:
        segments.append("Must-have coverage is strong across " + ", ".join(breakdown.matched_skills[:4]) + ".")
    segments.append(
        f"Experience fit is {candidate.years_experience:.1f} years against a {job.min_years_experience:.1f}-year target."
    )
    if feedback_entries:
        latest = sorted(feedback_entries, key=lambda entry: entry.created_at)[-1]
        segments.append(f"Latest recruiter signal: {latest.label.replace('_', ' ')}.")
    if evidence:
        segments.append(f"Grounding evidence from the {evidence[0].section or 'profile'} section supports this rank.")
    if risks and not breakdown.missing_must_have_skills:
        segments.append(risks[0] + ".")
    if breakdown.confidence_score >= 0.75:
        segments.append("Decision confidence is high.")
    elif breakdown.confidence_score <= 0.45:
        segments.append("Decision confidence is still building.")
    return " ".join(segment for segment in segments if segment).strip()


def _snapshot_summary(job: JobProfile, rankings: list[CandidateRanking]) -> tuple[str, dict[str, object]]:
    if not rankings:
        return "No candidates are currently available for this role.", {}
    top = rankings[0]
    strong_count = sum(1 for item in rankings if item.fit_band in {"excellent", "strong"})
    coverage = {
        "strong_candidates": strong_count,
        "average_score": round(sum(item.breakdown.total_score for item in rankings) / len(rankings), 4),
        "top_candidate": top.candidate.name,
        "top_score": top.breakdown.total_score,
        "critical_gap_candidates": [
            item.candidate.name for item in rankings if item.breakdown.missing_must_have_skills
        ][:5],
    }
    summary = (
        f"{top.candidate.name} currently leads for {job.title} with a {top.fit_band} fit. "
        f"{strong_count} candidate(s) are presently in the interview-ready band."
    )
    return summary, coverage


class RankingService:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def rank_job(
        self,
        job: JobProfile,
        candidates: list[CandidateProfile],
        feedback_entries: list[FeedbackEntry],
        retrieval_hits: list[RetrievalHit],
        previous_snapshot: RankingSnapshot | None = None,
        *,
        source_revision: int = 0,
    ) -> RankingSnapshot:
        hits_by_candidate: dict[str, list[RetrievalHit]] = defaultdict(list)
        feedback_by_candidate: dict[str, list[FeedbackEntry]] = defaultdict(list)
        previous_ranks: dict[str, tuple[int, float, RankingBreakdown]] = {}

        if previous_snapshot:
            for previous in previous_snapshot.rankings:
                previous_ranks[previous.candidate.candidate_id] = (
                    previous.rank,
                    previous.breakdown.total_score,
                    previous.breakdown,
                )

        for hit in retrieval_hits:
            hits_by_candidate[hit.candidate_id].append(hit)

        for feedback in feedback_entries:
            if feedback.job_id and feedback.job_id != job.job_id:
                continue
            feedback_by_candidate[feedback.candidate_id].append(feedback)

        scored_rankings: list[CandidateRanking] = []
        for candidate in candidates:
            must_have_score, matched_skills, missing_skills = _score_overlap(candidate.skills, job.must_have_skills)
            nice_to_have_score, _, missing_optional = _score_overlap(candidate.skills, job.nice_to_have_skills)
            grouped_skill_score, matched_skill_groups, missing_skill_groups = grouped_overlap(
                candidate.skills,
                job.must_have_skills,
            )
            experience_score = _score_experience(candidate, job)
            education_score = _score_education(candidate, job)
            keyword_score, matched_keywords = _score_keywords(candidate, job)
            recency_score = _score_recency(candidate)
            profile_quality = _score_profile_quality(candidate)

            candidate_hits = hits_by_candidate.get(candidate.candidate_id, [])
            retrieval_score = 0.0
            semantic_score = 0.0
            lexical_score = 0.0
            structured_score = 0.0
            evidence: list[ResumeEvidence] = []
            for hit in candidate_hits[:3]:
                retrieval_score = max(retrieval_score, hit.score)
                semantic_score = max(semantic_score, float(hit.channel_scores.get("semantic", 0.0)))
                lexical_score = max(lexical_score, float(hit.channel_scores.get("lexical", 0.0)))
                structured_score = max(structured_score, float(hit.channel_scores.get("structured", 0.0)))
                evidence.append(
                    ResumeEvidence(
                        snippet=hit.snippet,
                        score=hit.score,
                        source_path=hit.source_path,
                        section=hit.section,
                        metadata=hit.metadata | {"matched_terms": hit.matched_terms},
                    )
                )

            feedback_score = _aggregate_feedback(feedback_by_candidate.get(candidate.candidate_id, []))
            weighted_total = (
                retrieval_score * self.settings.score_weight_retrieval
                + must_have_score * self.settings.score_weight_must_have
                + nice_to_have_score * self.settings.score_weight_nice_to_have
                + experience_score * self.settings.score_weight_experience
                + education_score * self.settings.score_weight_education
                + keyword_score * self.settings.score_weight_keyword
                + max(0.0, feedback_score + 1.0) / 2.0 * self.settings.score_weight_feedback
            )
            confidence_score = _confidence_score(
                retrieval_score=retrieval_score,
                must_have_score=must_have_score,
                grouped_skill_score=grouped_skill_score,
                profile_quality=profile_quality,
                evidence_count=len(evidence),
            )
            enrichment_bonus = recency_score * 0.03 + profile_quality * 0.04 + structured_score * 0.03 + grouped_skill_score * 0.02
            risk_penalty = min(0.28, len(missing_skills) * 0.055)
            if candidate.duplicate_of:
                risk_penalty += 0.04
            if profile_quality < 0.5:
                risk_penalty += 0.03
            total_score = max(0.0, min(1.0, weighted_total + enrichment_bonus - risk_penalty))
            previous_rank, previous_score, previous_breakdown = previous_ranks.get(
                candidate.candidate_id,
                (0, 0.0, None),
            )
            if previous_rank:
                inertia = 0.08 if abs(total_score - previous_score) < 0.12 else 0.03
                total_score = total_score * (1.0 - inertia) + previous_score * inertia
            stability_score = _stability_score(
                confidence_score=confidence_score,
                must_have_score=must_have_score,
                profile_quality=profile_quality,
                risk_penalty=risk_penalty,
                total_score=total_score,
                previous_total=previous_score,
                has_previous_rank=bool(previous_rank),
            )
            breakdown = RankingBreakdown(
                retrieval_score=round(retrieval_score, 4),
                semantic_score=round(semantic_score, 4),
                lexical_score=round(lexical_score, 4),
                structured_score=round(structured_score, 4),
                must_have_score=round(must_have_score, 4),
                nice_to_have_score=round(nice_to_have_score, 4),
                experience_score=round(experience_score, 4),
                education_score=round(education_score, 4),
                keyword_score=round(keyword_score, 4),
                recency_score=round(recency_score, 4),
                profile_quality_score=round(profile_quality, 4),
                feedback_score=round(feedback_score, 4),
                confidence_score=round(confidence_score, 4),
                stability_score=round(stability_score, 4),
                grouped_skill_score=round(grouped_skill_score, 4),
                risk_penalty=round(risk_penalty, 4),
                total_score=round(total_score, 4),
                matched_skills=matched_skills[:8],
                missing_must_have_skills=missing_skills[:8],
                matched_keywords=matched_keywords[:8],
                missing_nice_to_have_skills=missing_optional[:8],
                matched_skill_groups=matched_skill_groups[:6],
                missing_skill_groups=missing_skill_groups[:6],
            )

            strengths = _strengths(
                candidate,
                matched_skills=matched_skills,
                matched_skill_groups=matched_skill_groups,
                matched_keywords=matched_keywords,
                experience_score=experience_score,
                feedback_score=feedback_score,
                profile_quality=profile_quality,
                confidence_score=confidence_score,
            )
            risks = _risks(
                missing_skills=missing_skills,
                missing_skill_groups=missing_skill_groups,
                missing_optional=missing_optional,
                feedback_score=feedback_score,
                profile_quality=profile_quality,
                candidate=candidate,
                confidence_score=confidence_score,
            )
            interview_focus = _interview_focus(
                missing_skills=missing_skills,
                missing_optional=missing_optional,
                matched_keywords=matched_keywords,
                candidate=candidate,
            )
            ranking = CandidateRanking(
                rank=0,
                candidate=candidate,
                breakdown=breakdown,
                explanation=_build_explanation(
                    candidate=candidate,
                    job=job,
                    breakdown=breakdown,
                    strengths=strengths,
                    risks=risks,
                    evidence=evidence,
                    feedback_entries=feedback_by_candidate.get(candidate.candidate_id, []),
                ),
                evidence=evidence,
                score_delta=round(breakdown.total_score - previous_score, 4),
                rank_delta=0 if not previous_rank else previous_rank,
                fit_band=_fit_band(total_score),
                strengths=strengths,
                risks=risks,
                interview_focus=interview_focus,
                decision_signal=_decision_signal(total_score, missing_skills, feedback_score),
                why_selected=strengths[:3] or ["Evidence and structured fit align for this role."],
                why_not_selected=risks[:3] or ["No material blockers are currently visible."],
            )
            ranking.movement_summary = ""
            scored_rankings.append(ranking)

        scored_rankings.sort(
            key=lambda item: (
                item.breakdown.total_score,
                item.breakdown.must_have_score,
                item.breakdown.retrieval_score,
                item.breakdown.confidence_score,
                item.breakdown.stability_score,
                item.breakdown.profile_quality_score,
                item.candidate.years_experience,
                item.candidate.name,
            ),
            reverse=True,
        )

        for index, ranking in enumerate(scored_rankings[: self.settings.ranking_top_k], start=1):
            previous_rank, previous_score, previous_breakdown = previous_ranks.get(
                ranking.candidate.candidate_id,
                (0, 0.0, None),
            )
            ranking.rank = index
            score_delta, rank_delta, movement_summary = _movement_summary(
                ranking.candidate.candidate_id,
                index,
                ranking.breakdown.total_score,
                previous_rank,
                previous_score,
                previous_breakdown,
                ranking.breakdown,
            )
            ranking.score_delta = score_delta
            ranking.rank_delta = rank_delta
            ranking.movement_summary = movement_summary

        final_rankings = scored_rankings[: self.settings.ranking_top_k]
        insight_summary, coverage_summary = _snapshot_summary(job, final_rankings)
        return RankingSnapshot(
            job_id=job.job_id,
            source_revision=source_revision,
            insight_summary=insight_summary,
            coverage_summary=coverage_summary,
            rankings=final_rankings,
        )
