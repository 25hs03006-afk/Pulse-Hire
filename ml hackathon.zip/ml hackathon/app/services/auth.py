from __future__ import annotations

import secrets
from datetime import UTC, datetime, timedelta
from pathlib import Path
from threading import RLock
import re

from app.models import AuthSession
from app.services.security import hash_password, password_needs_rehash, verify_password
from app.services.sqlite_store import SQLiteJsonStore
from app.services.workspaces import SAMPLE_WORKSPACE, normalize_workspace_id


SESSION_TTL = timedelta(hours=12)


def _utc_now() -> datetime:
    return datetime.now(UTC)


def seed_company_password(company_name: str) -> str:
    compact = re.sub(r"[^A-Za-z0-9]+", "", company_name or "").strip() or "Company"
    return f"{compact}@201588"


class AuthManager:
    def __init__(self, root_dir: Path) -> None:
        self._root_dir = root_dir / "auth"
        self._root_dir.mkdir(parents=True, exist_ok=True)
        self._store = SQLiteJsonStore(self._root_dir / "auth.db")
        self._lock = RLock()
        self._companies_namespace = "companies"
        self._sessions_namespace = "company_sessions"

    def _load_companies(self) -> dict[str, dict]:
        return self._store.get_namespace(self._companies_namespace)

    def _save_companies(self, companies: dict[str, dict]) -> None:
        self._store.replace_namespace(self._companies_namespace, companies)

    def _load_sessions(self) -> dict[str, dict]:
        return self._store.get_namespace(self._sessions_namespace)

    def _save_session(self, session: AuthSession) -> None:
        self._store.set(self._sessions_namespace, session.token, session.model_dump(mode="json"))

    def register_company(self, *, company_name: str, admin_name: str, email: str | None, password: str) -> AuthSession:
        workspace_id = normalize_workspace_id(company_name)
        if workspace_id == SAMPLE_WORKSPACE:
            raise ValueError("That company name is reserved. Please choose a different workspace name.")
        with self._lock:
            companies = self._load_companies()
            existing = companies.get(workspace_id)
            if existing and not bool(existing.get("seeded")):
                raise ValueError("A company workspace with that name already exists.")
            companies[workspace_id] = self._build_company_record(
                workspace_id=workspace_id,
                company_name=company_name,
                admin_name=admin_name,
                email=email,
                password=password,
                seeded=False,
            )
            self._save_companies(companies)
            return self._create_session(companies[workspace_id])

    def _build_company_record(
        self,
        *,
        workspace_id: str,
        company_name: str,
        admin_name: str,
        email: str | None,
        password: str,
        seeded: bool,
    ) -> dict:
        salt = secrets.token_hex(12)
        return {
            "workspace_id": workspace_id,
            "company_name": company_name.strip(),
            "admin_name": admin_name.strip(),
            "email": (email or "").strip() or None,
            "salt": salt,
            "password_hash": hash_password(password, salt),
            "role": "owner",
            "seeded": seeded,
        }

    def ensure_seed_company(
        self,
        *,
        workspace_id: str,
        company_name: str | None = None,
        admin_name: str | None = None,
        email: str | None = None,
    ) -> dict:
        normalized = normalize_workspace_id(workspace_id)
        if normalized == SAMPLE_WORKSPACE:
            raise ValueError("Sample workspace cannot be used for a seeded company account.")
        display_name = (company_name or normalized.replace("-", " ").title()).strip()
        with self._lock:
            companies = self._load_companies()
            existing = companies.get(normalized)
            if existing:
                return existing
            record = self._build_company_record(
                workspace_id=normalized,
                company_name=display_name,
                admin_name=(admin_name or "Workspace owner"),
                email=email or f"owner@{normalized}.pulsehire.local",
                password=seed_company_password(display_name),
                seeded=True,
            )
            companies[normalized] = record
            self._save_companies(companies)
            return record

    def login(self, *, company_name: str, password: str) -> AuthSession:
        workspace_id = normalize_workspace_id(company_name)
        with self._lock:
            companies = self._load_companies()
            record = companies.get(workspace_id)
            if not record:
                raise ValueError("Company workspace not found.")
            if not verify_password(password, record.get("salt"), record["password_hash"]):
                raise ValueError("Incorrect password.")
            if password_needs_rehash(str(record["password_hash"])):
                record["password_hash"] = hash_password(password, record.get("salt"))
                companies[workspace_id] = record
                self._save_companies(companies)
            return self._create_session(record)

    def _create_session(self, record: dict) -> AuthSession:
        token = secrets.token_urlsafe(32)
        issued_at = _utc_now()
        session = AuthSession(
            token=token,
            workspace_id=record["workspace_id"],
            company_name=record["company_name"],
            admin_name=record["admin_name"],
            email=record.get("email"),
            role=str(record.get("role") or "owner"),
            issued_at=issued_at,
            expires_at=issued_at + SESSION_TTL,
        )
        self._save_session(session)
        return session

    def get_session(self, token: str | None) -> AuthSession | None:
        if not token:
            return None
        with self._lock:
            payload = self._load_sessions().get(token)
            if not payload:
                return None
            session = AuthSession.model_validate(payload)
            if session.expires_at <= _utc_now():
                self._store.delete(self._sessions_namespace, token)
                return None
            refreshed = session.model_copy(update={"expires_at": _utc_now() + SESSION_TTL})
            self._save_session(refreshed)
            return refreshed.model_copy(deep=True)

    def logout(self, token: str | None) -> None:
        if not token:
            return
        with self._lock:
            self._store.delete(self._sessions_namespace, token)

    def delete_company(self, workspace_id: str) -> bool:
        normalized = normalize_workspace_id(workspace_id)
        with self._lock:
            companies = self._load_companies()
            if normalized not in companies:
                return False
            companies.pop(normalized, None)
            self._save_companies(companies)
            sessions = self._load_sessions()
            for token, payload in list(sessions.items()):
                if str(payload.get("workspace_id")) == normalized:
                    self._store.delete(self._sessions_namespace, token)
            return True

    def list_companies(self) -> list[dict]:
        with self._lock:
            companies = self._load_companies()
            return [
                {
                    "workspace_id": record["workspace_id"],
                    "company_name": record["company_name"],
                    "admin_name": record["admin_name"],
                    "email": record.get("email"),
                    "role": record.get("role", "owner"),
                    "seeded": bool(record.get("seeded")),
                }
                for record in sorted(companies.values(), key=lambda item: item.get("company_name", "").lower())
            ]

    def get_company(self, workspace_id: str) -> dict | None:
        with self._lock:
            companies = self._load_companies()
            record = companies.get(normalize_workspace_id(workspace_id))
            if not record:
                return None
            return {
                "workspace_id": record["workspace_id"],
                "company_name": record["company_name"],
                "admin_name": record["admin_name"],
                "email": record.get("email"),
                "role": record.get("role", "owner"),
                "seeded": bool(record.get("seeded")),
            }
