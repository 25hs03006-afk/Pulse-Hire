"""Service layer for PulseHire."""
