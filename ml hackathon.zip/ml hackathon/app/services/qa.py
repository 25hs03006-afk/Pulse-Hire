from __future__ import annotations

from app.models import CandidateRanking, JobProfile, RankingSnapshot, RecruiterAnswer, ResumeEvidence


def _context_from_rankings(snapshot: RankingSnapshot, top_n: int = 3) -> list[ResumeEvidence]:
    return [evidence for item in snapshot.rankings[:top_n] for evidence in item.evidence[:1]]


def _find_candidate(rankings: list[CandidateRanking], question: str) -> CandidateRanking | None:
    lower = question.lower()
    for item in rankings:
        if item.candidate.name.lower() in lower or item.candidate.candidate_id.lower() in lower:
            return item
    return None


def _feedback_lines(insights: dict) -> list[str]:
    summary = insights.get("feedback_summary") or {}
    lines: list[str] = []
    for name, payload in summary.items():
        labels = ", ".join(payload.get("labels") or []) or "no recent review labels"
        net = float(payload.get("net_signal") or 0.0)
        lines.append(f"{name}: {labels}; net recruiter signal {net:+.2f}")
    return lines


def _coverage_lines(insights: dict) -> list[str]:
    rows = insights.get("coverage") or []
    lines: list[str] = []
    for row in rows[:5]:
        covered = ", ".join(row.get("covered_candidates") or []) or "none yet"
        ratio = float(row.get("coverage_ratio") or 0.0) * 100
        lines.append(f"{row.get('skill')}: {ratio:.0f}% coverage across shortlisted candidates; covered by {covered}")
    return lines


def _candidate_answer(candidate: CandidateRanking, job: JobProfile) -> RecruiterAnswer:
    bullets = candidate.strengths[:3] + candidate.risks[:2] + candidate.interview_focus[:2]
    return RecruiterAnswer(
        answer=(
            f"{candidate.candidate.name} is currently ranked #{candidate.rank} for {job.title}. "
            f"{candidate.explanation}"
        ),
        bullets=bullets,
        context=candidate.evidence[:2],
    )


def answer_recruiter_question(
    question: str,
    job: JobProfile,
    snapshot: RankingSnapshot,
    insights: dict | None = None,
) -> RecruiterAnswer:
    rankings = snapshot.rankings
    insights = insights or {}
    lower = question.lower().strip()
    if not rankings:
        return RecruiterAnswer(answer="No candidates are indexed for this role yet.")

    candidate = _find_candidate(rankings, lower)
    top = rankings[0]
    runner = rankings[1] if len(rankings) > 1 else None

    if candidate is not None:
        if any(token in lower for token in ("why not", "why isn't", "why isnt", "concern", "risk", "weakness", "gap")):
            bullets = candidate.risks[:4] or ["No major risk flags are currently recorded."]
            return RecruiterAnswer(
                answer=(
                    f"{candidate.candidate.name} is ranked #{candidate.rank} because their profile has "
                    f"{'some open risks' if candidate.risks else 'no major blockers'}, but {candidate.decision_signal.lower()}."
                ),
                bullets=bullets + candidate.interview_focus[:2],
                context=candidate.evidence[:2],
            )
        return _candidate_answer(candidate, job)

    if any(token in lower for token in ("what changed", "latest update", "moved", "changed")):
        movers = insights.get("movement_digest") or []
        if not movers:
            return RecruiterAnswer(
                answer="The latest update did not materially change the shortlist order.",
                bullets=["No candidate crossed the movement threshold in the current snapshot."],
                context=_context_from_rankings(snapshot, top_n=1),
            )
        return RecruiterAnswer(
            answer=f"The shortlist changed after the latest update for {job.title}.",
            bullets=[item.get("movement_summary") or f"{item.get('name')} changed position." for item in movers[:4]],
            context=_context_from_rankings(snapshot),
        )

    if any(token in lower for token in ("compare", "versus", "vs")) and runner is not None:
        return RecruiterAnswer(
            answer=(
                f"{top.candidate.name} currently leads over {runner.candidate.name} for {job.title} "
                f"because {top.decision_signal.lower()} and shows stronger evidence coverage."
            ),
            bullets=[
                f"{top.candidate.name}: " + "; ".join(top.strengths[:2] or ["higher overall fit"]),
                f"{runner.candidate.name}: " + "; ".join((runner.risks[:2] or runner.interview_focus[:2] or ["close second choice"])),
            ],
            context=top.evidence[:1] + runner.evidence[:1],
        )

    if any(token in lower for token in ("feedback", "review", "signal", "recruiter note")):
        lines = _feedback_lines(insights)
        return RecruiterAnswer(
            answer="Here is the current recruiter-review impact on the shortlist.",
            bullets=lines or ["No recruiter reviews are influencing this shortlist yet."],
            context=_context_from_rankings(snapshot, top_n=2),
        )

    if any(token in lower for token in ("confidence", "certain", "confidence score")):
        return RecruiterAnswer(
            answer=f"Here is the current confidence view for the {job.title} shortlist.",
            bullets=[
                f"{item.candidate.name}: {item.breakdown.confidence_score:.2f} confidence, {item.breakdown.stability_score:.2f} stability."
                for item in rankings[:5]
            ],
            context=_context_from_rankings(snapshot, top_n=2),
        )

    if any(token in lower for token in ("coverage", "skill coverage", "must-have", "must have")):
        return RecruiterAnswer(
            answer=f"Here is the current requirement coverage view for {job.title}.",
            bullets=_coverage_lines(insights) or ["Coverage details are not available yet."],
            context=_context_from_rankings(snapshot, top_n=2),
        )

    if any(token in lower for token in ("gap", "missing", "weakness", "risk")):
        return RecruiterAnswer(
            answer="Here is the current gap view across the shortlist.",
            bullets=[
                f"{item.candidate.name}: "
                + (", ".join(item.breakdown.missing_must_have_skills[:4]) or "no major must-have gaps")
                for item in rankings[:5]
            ],
            context=_context_from_rankings(snapshot),
        )

    if any(token in lower for token in ("stable", "stability", "volatile", "shift")):
        stability_overview = insights.get("stability_overview") or {}
        volatile = ", ".join(stability_overview.get("volatile_candidates") or []) or "none"
        return RecruiterAnswer(
            answer=f"The shortlist for {job.title} is currently {'stable' if float(stability_overview.get('average_stability', 0.0)) >= 0.6 else 'still moving'} overall.",
            bullets=[
                f"Average stability: {float(stability_overview.get('average_stability', 0.0)):.2f}",
                f"High-confidence candidates: {int(stability_overview.get('high_confidence_candidates', 0))}",
                f"Most volatile profiles right now: {volatile}",
            ],
            context=_context_from_rankings(snapshot, top_n=2),
        )

    if any(token in lower for token in ("strength", "strongest", "best fit", "why is the top candidate", "why is the current top candidate", "leader")):
        return RecruiterAnswer(
            answer=(
                f"{top.candidate.name} is currently the leading candidate for {job.title}. "
                f"{top.explanation}"
            ),
            bullets=top.strengths[:4] + top.interview_focus[:2],
            context=top.evidence[:2],
        )

    if any(token in lower for token in ("how many", "count", "interview-ready", "interview ready", "shortlist")):
        fit_distribution = insights.get("fit_distribution") or {}
        return RecruiterAnswer(
            answer=f"There are {sum(fit_distribution.get(label, 0) for label in ('excellent', 'strong'))} interview-ready candidates for {job.title}.",
            bullets=[
                f"Excellent: {fit_distribution.get('excellent', 0)}",
                f"Strong: {fit_distribution.get('strong', 0)}",
                f"Promising: {fit_distribution.get('promising', 0)}",
                f"Partial: {fit_distribution.get('partial', 0)}",
            ],
            context=_context_from_rankings(snapshot),
        )

    if any(token in lower for token in ("top", "best", "who should", "recommend")):
        return RecruiterAnswer(
            answer=f"Top recommendations for {job.title}: {snapshot.insight_summary}",
            bullets=[
                f"{item.candidate.name} (rank {item.rank}, score {item.breakdown.total_score:.2f}): {item.decision_signal}."
                for item in rankings[:3]
            ],
            context=_context_from_rankings(snapshot),
        )

    return RecruiterAnswer(
        answer=(
            f"For {job.title}, the strongest current signal is that {top.candidate.name} leads the shortlist. "
            f"{snapshot.insight_summary}"
        ),
        bullets=[
            f"Top candidate: {top.candidate.name} with score {top.breakdown.total_score:.2f}.",
            f"Decision signal: {top.decision_signal}.",
            *(top.strengths[:2] or ["Strong role alignment is visible in the current evidence."]),
        ],
        context=top.evidence[:2],
    )
