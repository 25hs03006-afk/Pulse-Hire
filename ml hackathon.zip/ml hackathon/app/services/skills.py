from __future__ import annotations

from collections import defaultdict
from typing import Iterable

CANONICAL_SKILLS: dict[str, set[str]] = {
    "Python": {"python", "py"},
    "SQL": {"sql", "postgres", "postgresql", "mysql", "sqlite"},
    "Java": {"java"},
    "JavaScript": {"javascript", "js"},
    "TypeScript": {"typescript", "ts"},
    "React": {"react", "reactjs", "react.js"},
    "Node.js": {"node", "nodejs", "node.js"},
    "FastAPI": {"fastapi"},
    "Streamlit": {"streamlit"},
    "REST APIs": {"rest api", "rest apis", "restful api", "restful apis", "api development"},
    "Microservices": {"microservice", "microservices"},
    "Redis": {"redis"},
    "Docker": {"docker"},
    "Kubernetes": {"kubernetes", "k8s"},
    "AWS": {"aws", "amazon web services"},
    "Azure": {"azure"},
    "GCP": {"gcp", "google cloud", "google cloud platform"},
    "Git": {"git"},
    "Linux": {"linux"},
    "CI/CD": {"ci/cd", "continuous integration", "continuous delivery", "continuous deployment"},
    "Pathway": {"pathway"},
    "RAG": {"rag", "retrieval augmented generation", "retrieval-augmented generation"},
    "LLMs": {"llm", "llms", "large language models", "generative ai"},
    "LangChain": {"langchain"},
    "LlamaIndex": {"llamaindex"},
    "Vector Search": {"vector search", "vector database", "vector index", "faiss", "chroma", "pinecone", "weaviate"},
    "Machine Learning": {"machine learning", "ml"},
    "Deep Learning": {"deep learning"},
    "NLP": {"nlp", "natural language processing"},
    "MLOps": {"mlops", "machine learning operations"},
    "PyTorch": {"pytorch"},
    "TensorFlow": {"tensorflow"},
    "Scikit-learn": {"scikit-learn", "sklearn"},
    "Pandas": {"pandas"},
    "NumPy": {"numpy"},
    "Spark": {"spark", "pyspark"},
    "Kafka": {"kafka"},
    "Airflow": {"airflow"},
    "dbt": {"dbt"},
    "ETL": {"etl", "elt"},
    "Data Pipelines": {"data pipeline", "data pipelines", "stream processing", "batch processing"},
    "A/B Testing": {"a/b testing", "ab testing", "experimentation"},
    "Product Strategy": {"product strategy", "roadmapping", "roadmap", "prioritization"},
    "Stakeholder Management": {"stakeholder management", "stakeholder communication"},
    "User Research": {"user research", "ux research"},
    "Figma": {"figma"},
    "UI Design": {"ui design", "visual design", "interface design"},
    "UX Design": {"ux design", "interaction design", "wireframing", "prototyping"},
    "Tableau": {"tableau"},
    "Power BI": {"power bi"},
}

SKILL_GROUPS: dict[str, set[str]] = {
    "Programming": {"Python", "SQL", "Java", "JavaScript", "TypeScript"},
    "Backend": {"FastAPI", "REST APIs", "Microservices", "React", "Node.js", "Redis", "Streamlit"},
    "Cloud & Platform": {"Docker", "Kubernetes", "AWS", "Azure", "GCP", "Git", "Linux", "CI/CD"},
    "AI & Retrieval": {"Pathway", "RAG", "LLMs", "LangChain", "LlamaIndex", "Vector Search", "Machine Learning", "Deep Learning", "NLP", "MLOps"},
    "ML Tooling": {"PyTorch", "TensorFlow", "Scikit-learn", "Pandas", "NumPy", "Spark"},
    "Data Engineering": {"Kafka", "Airflow", "dbt", "ETL", "Data Pipelines", "Tableau", "Power BI"},
    "Product": {"A/B Testing", "Product Strategy", "Stakeholder Management"},
    "Design": {"User Research", "Figma", "UI Design", "UX Design"},
}


def _canonical_alias_map() -> dict[str, str]:
    mapping: dict[str, str] = {}
    for canonical, aliases in CANONICAL_SKILLS.items():
        mapping[canonical.lower()] = canonical
        for alias in aliases:
            mapping[alias.lower()] = canonical
    return mapping


ALIAS_TO_SKILL = _canonical_alias_map()


def canonicalize_skill(value: str | None) -> str | None:
    if not value:
        return None
    cleaned = " ".join(value.strip().replace("/", " / ").split())
    normalized = cleaned.lower()
    variants = [
        normalized,
        normalized.replace(" / ", "/"),
        normalized.replace(".", ""),
        normalized.replace("-", " "),
        normalized.replace(".", "").replace("-", " ").replace(" / ", "/"),
    ]
    for variant in variants:
        if variant in ALIAS_TO_SKILL:
            return ALIAS_TO_SKILL[variant]
    title_value = cleaned.title()
    return title_value if len(title_value) <= 40 else None


def normalize_skills(values: Iterable[str]) -> list[str]:
    normalized: set[str] = set()
    for value in values:
        canonical = canonicalize_skill(value)
        if canonical:
            normalized.add(canonical)
    return sorted(normalized)


def group_skills(values: Iterable[str]) -> dict[str, list[str]]:
    grouped: dict[str, list[str]] = defaultdict(list)
    normalized = normalize_skills(values)
    for skill in normalized:
        for group_name, group_skills in SKILL_GROUPS.items():
            if skill in group_skills:
                grouped[group_name].append(skill)
                break
        else:
            grouped["Other"].append(skill)
    return {group: sorted(items) for group, items in grouped.items()}


def grouped_overlap(candidate_skills: Iterable[str], target_skills: Iterable[str]) -> tuple[float, list[str], list[str]]:
    target_groups = set(group_skills(target_skills))
    candidate_groups = set(group_skills(candidate_skills))
    if not target_groups:
        return 1.0, [], []
    matched = sorted(target_groups & candidate_groups)
    missing = sorted(target_groups - candidate_groups)
    return len(matched) / max(len(target_groups), 1), matched, missing
