from __future__ import annotations

import json
import os
import re
import shutil
import zipfile
from io import BytesIO
from pathlib import Path

from app.config import Settings

SUPPORTED_BUNDLE_TYPES = {".zip"}
KAGGLE_DATASET_PRESETS = [
    {
        "id": "resume_text_primary",
        "label": "Resume Dataset",
        "slug": "snehaanbhawal/resume-dataset",
        "kind": "resumes",
        "notes": "Large Kaggle resume corpus with CSV text records and resume categories.",
    },
    {
        "id": "resume_pdf_real",
        "label": "Resume PDF Dataset",
        "slug": "hadikp/resume-data-pdf",
        "kind": "resumes",
        "notes": "Real-world PDF resumes for parser and layout stress testing.",
    },
    {
        "id": "resume_structured_large",
        "label": "Structured Resume Dataset",
        "slug": "suriyaganesh/resume-dataset-structured",
        "kind": "resumes",
        "notes": "High-volume structured resume data useful for scale and diversity.",
    },
    {
        "id": "job_descriptions",
        "label": "Job Descriptions Dataset",
        "slug": "jayakishan225/job-descriptions-dataset",
        "kind": "jobs",
        "notes": "Multi-role job description corpus for the live role system.",
    },
]


def _slugify(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return normalized or "dataset"


def public_dataset_catalog(catalog_path: Path) -> list[dict]:
    if not catalog_path.exists():
        return []
    try:
        payload = json.loads(catalog_path.read_text(encoding="utf-8"))
    except Exception:
        return []
    return payload if isinstance(payload, list) else []


def kaggle_dataset_catalog() -> list[dict]:
    return [dict(item) for item in KAGGLE_DATASET_PRESETS]


def _safe_members(bundle: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    members: list[zipfile.ZipInfo] = []
    for member in bundle.infolist():
        name = Path(member.filename)
        if member.is_dir():
            continue
        if name.is_absolute():
            continue
        if ".." in name.parts:
            continue
        members.append(member)
    return members


def _allowed_suffixes(settings: Settings) -> set[str]:
    return {
        *settings.resume_upload_types,
        *settings.job_upload_types,
        *settings.feedback_upload_types,
        ".jsonl",
    }


def _infer_stream(member_path: Path, settings: Settings) -> str | None:
    suffix = member_path.suffix.lower()
    lowered_parts = {part.lower() for part in member_path.parts}
    stem = member_path.stem.lower()
    if suffix not in _allowed_suffixes(settings):
        return None
    if lowered_parts & {"resumes", "resume", "candidates", "candidate", "cv", "cvs"}:
        return "resumes"
    if lowered_parts & {"jobs", "job", "roles", "role", "descriptions", "descs", "jd"}:
        return "jobs"
    if lowered_parts & {"feedback", "reviews", "signals"}:
        return "feedback"
    if any(token in stem for token in ("feedback", "review", "signal")):
        return "feedback"
    if any(token in stem for token in ("job", "role", "description", "jd")):
        return "jobs"
    return "resumes"


def _stream_root(stream_name: str, settings: Settings) -> Path:
    return {
        "resumes": settings.resumes_dir,
        "jobs": settings.jobs_dir,
        "feedback": settings.feedback_dir,
    }[stream_name]


def _copy_if_changed(source: Path, destination: Path) -> bool:
    destination.parent.mkdir(parents=True, exist_ok=True)
    source_bytes = source.read_bytes()
    if destination.exists() and destination.is_file() and destination.read_bytes() == source_bytes:
        return False
    destination.write_bytes(source_bytes)
    return True


def _destination_name(member_path: Path, prefix: str | None = None) -> str:
    name = member_path.name
    return f"{_slugify(prefix)}-{name}" if prefix else name


def _expand_nested_archives(root: Path) -> None:
    for archive_path in list(root.rglob("*.zip")):
        target = archive_path.with_suffix("")
        if target.exists():
            continue
        target.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive_path) as archive:
            for member in _safe_members(archive):
                destination = target / Path(member.filename).name
                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(member) as source, destination.open("wb") as sink:
                    sink.write(source.read())


def import_dataset_directory(
    source_root: Path,
    settings: Settings,
    *,
    stream_hint: str | None = None,
    name_prefix: str | None = None,
) -> dict:
    _expand_nested_archives(source_root)
    counts = {"resumes": 0, "jobs": 0, "feedback": 0, "ignored": 0}
    imported_files: list[str] = []
    for source_path in sorted(path for path in source_root.rglob("*") if path.is_file()):
        if source_path.suffix.lower() == ".zip":
            counts["ignored"] += 1
            continue
        stream_name = stream_hint or _infer_stream(source_path.relative_to(source_root), settings)
        if stream_name is None:
            counts["ignored"] += 1
            continue
        destination = _stream_root(stream_name, settings) / _destination_name(source_path, name_prefix)
        changed = _copy_if_changed(source_path, destination)
        if changed:
            imported_files.append(str(destination))
        counts[stream_name] += 1
    return {
        "counts": counts,
        "imported_files": imported_files[:50],
        "message": (
            f"Imported {counts['resumes']} resumes, {counts['jobs']} job files, and "
            f"{counts['feedback']} feedback files."
        ),
    }


def import_dataset_bundle(bundle_bytes: bytes, bundle_name: str, settings: Settings) -> dict:
    extracted_root = settings.staging_dir / "imports" / Path(bundle_name).stem
    if extracted_root.exists():
        shutil.rmtree(extracted_root)
    extracted_root.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(BytesIO(bundle_bytes)) as archive:
        for member in _safe_members(archive):
            destination = extracted_root / member.filename
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member) as source, destination.open("wb") as sink:
                sink.write(source.read())

    payload = import_dataset_directory(extracted_root, settings, name_prefix=Path(bundle_name).stem)
    return {
        "bundle_name": bundle_name,
        **payload,
        "message": payload["message"] + " Live rankings will update automatically.",
    }


def _resolve_kaggle_selection(preset_ids: list[str] | None, dataset_slugs: list[str] | None) -> list[dict]:
    selected: list[dict] = []
    presets_by_id = {item["id"]: item for item in KAGGLE_DATASET_PRESETS}
    for preset_id in preset_ids or []:
        preset = presets_by_id.get(preset_id)
        if preset:
            selected.append(dict(preset))
    for slug in dataset_slugs or []:
        slug = slug.strip()
        if not slug:
            continue
        selected.append(
            {
                "id": _slugify(slug),
                "label": slug,
                "slug": slug,
                "kind": "mixed",
                "notes": "Custom Kaggle dataset source.",
            }
        )
    if selected:
        return selected
    return [dict(item) for item in KAGGLE_DATASET_PRESETS]


def _load_kaggle_api(settings: Settings):
    if not settings.kaggle_username or not settings.kaggle_key:
        raise RuntimeError("Kaggle credentials are not configured. Set KAGGLE_USERNAME and KAGGLE_KEY first.")
    os.environ["KAGGLE_USERNAME"] = settings.kaggle_username
    os.environ["KAGGLE_KEY"] = settings.kaggle_key
    try:
        from kaggle.api.kaggle_api_extended import KaggleApi
    except Exception as exc:  # pragma: no cover - dependency/runtime guard
        raise RuntimeError("The Kaggle API package is not installed in this environment.") from exc
    api = KaggleApi()
    api.authenticate()
    return api


def sync_kaggle_datasets(
    settings: Settings,
    *,
    preset_ids: list[str] | None = None,
    dataset_slugs: list[str] | None = None,
    force: bool = False,
) -> dict:
    api = _load_kaggle_api(settings)
    selected = _resolve_kaggle_selection(preset_ids, dataset_slugs)
    aggregate_counts = {"resumes": 0, "jobs": 0, "feedback": 0, "ignored": 0}
    imported_files: list[str] = []
    sources: list[dict] = []

    for source in selected:
        slug = source["slug"]
        source_root = settings.kaggle_root / _slugify(slug)
        source_root.mkdir(parents=True, exist_ok=True)
        api.dataset_download_files(slug, path=str(source_root), unzip=True, quiet=False, force=force)
        payload = import_dataset_directory(
            source_root,
            settings,
            stream_hint=None if source.get("kind") == "mixed" else source.get("kind"),
            name_prefix=_slugify(slug),
        )
        for key in aggregate_counts:
            aggregate_counts[key] += int(payload["counts"].get(key, 0))
        imported_files.extend(payload["imported_files"])
        sources.append(
            {
                "id": source["id"],
                "label": source["label"],
                "slug": slug,
                "counts": payload["counts"],
            }
        )

    return {
        "sources": sources,
        "counts": aggregate_counts,
        "imported_files": imported_files[:100],
        "message": (
            f"Kaggle sync completed with {aggregate_counts['resumes']} resumes, "
            f"{aggregate_counts['jobs']} jobs, and {aggregate_counts['feedback']} feedback files imported."
        ),
    }
