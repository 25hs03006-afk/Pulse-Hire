from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass
from typing import Iterable

import httpx

from app.models import CandidateProfile, JobProfile, RetrievalHit
from app.services.parsers.extractors import candidate_id_from_path, format_candidate_document
from app.services.skills import group_skills
from app.services.state.store import RuntimeState
from app.services.workspaces import belongs_to_workspace, infer_workspace_from_entity_id

try:  # pragma: no cover - optional runtime path
    from sentence_transformers import SentenceTransformer
except Exception:  # pragma: no cover - fallback path
    SentenceTransformer = None

TOKEN_PATTERN = re.compile(r"[a-z0-9+#./-]+")
HASH_EMBED_DIMENSIONS = 256


def _tokenize(text: str) -> list[str]:
    return TOKEN_PATTERN.findall(text.lower())


def _hashed_embedding(text: str) -> list[float]:
    vector = [0.0] * HASH_EMBED_DIMENSIONS
    for token in _tokenize(text):
        digest = hashlib.sha256(token.encode("utf-8")).digest()
        index = int.from_bytes(digest[:4], "big") % HASH_EMBED_DIMENSIONS
        sign = 1.0 if digest[4] % 2 == 0 else -1.0
        weight = 1.0 + min(len(token), 16) / 16.0
        vector[index] += sign * weight
    norm = math.sqrt(sum(value * value for value in vector)) or 1.0
    return [value / norm for value in vector]


def _cosine_similarity(left: list[float], right: list[float]) -> float:
    return max(0.0, sum(lhs * rhs for lhs, rhs in zip(left, right)))


def _normalize_terms(items: Iterable[str]) -> set[str]:
    return {item.lower().strip() for item in items if item and item.strip()}


def _idf_weights(candidates: list[CandidateProfile]) -> dict[str, float]:
    doc_count = max(len(candidates), 1)
    counts: dict[str, int] = {}
    for candidate in candidates:
        terms = set(_tokenize(format_candidate_document(candidate)))
        for term in terms:
            counts[term] = counts.get(term, 0) + 1
    return {
        term: math.log(1.0 + (doc_count + 1) / (count + 1)) + 1.0
        for term, count in counts.items()
    }


@dataclass(slots=True)
class SearchPlan:
    text: str
    title_terms: set[str]
    required_skills: set[str]
    preferred_skills: set[str]
    keywords: set[str]
    location_terms: set[str]
    min_years_experience: float
    education_requirement: str | None

    @property
    def query_terms(self) -> set[str]:
        return {
            *self.title_terms,
            *self.required_skills,
            *self.preferred_skills,
            *self.keywords,
            *self.location_terms,
            *_tokenize(self.text),
        }


def _search_plan_from_job(job: JobProfile) -> SearchPlan:
    return SearchPlan(
        text="\n".join(
            part
            for part in [
                job.title,
                job.description,
                "Must-have skills: " + ", ".join(job.must_have_skills),
                "Nice-to-have skills: " + ", ".join(job.nice_to_have_skills),
                "Keywords: " + ", ".join(job.keywords),
            ]
            if part and part.strip()
        ),
        title_terms=set(_tokenize(job.title)),
        required_skills=_normalize_terms(job.must_have_skills),
        preferred_skills=_normalize_terms(job.nice_to_have_skills),
        keywords=_normalize_terms(job.keywords),
        location_terms=set(_tokenize(job.location or "")),
        min_years_experience=job.min_years_experience,
        education_requirement=job.education_requirement,
    )


def _search_plan_from_query(query: str) -> SearchPlan:
    return SearchPlan(
        text=query,
        title_terms=set(),
        required_skills=set(),
        preferred_skills=set(),
        keywords=set(_tokenize(query)),
        location_terms=set(),
        min_years_experience=0.0,
        education_requirement=None,
    )


def _candidate_sections(candidate: CandidateProfile) -> list[tuple[str, str]]:
    sections = [
        ("summary", candidate.summary),
        ("skills", ", ".join(candidate.skills)),
        ("experience", " ".join(candidate.experience_highlights)),
        ("projects", " ".join(candidate.projects)),
        ("education", " ".join(candidate.education)),
        ("profile", format_candidate_document(candidate)),
    ]
    return [(name, value.strip()) for name, value in sections if value and value.strip()]


def _weighted_overlap(query_terms: set[str], candidate_terms: set[str], weights: dict[str, float]) -> tuple[float, list[str]]:
    if not query_terms:
        return 0.0, []
    matched = sorted(query_terms & candidate_terms)
    numerator = sum(weights.get(term, 1.0) for term in matched)
    denominator = sum(weights.get(term, 1.0) for term in query_terms) or 1.0
    return numerator / denominator, matched


def _coverage_score(candidate_terms: set[str], target_terms: set[str]) -> tuple[float, list[str]]:
    if not target_terms:
        return 1.0, []
    matched = sorted(target_terms & candidate_terms)
    return len(matched) / max(len(target_terms), 1), matched


def _experience_alignment(candidate: CandidateProfile, min_years: float) -> float:
    if min_years <= 0:
        return 1.0 if candidate.years_experience > 0 else 0.45
    ratio = candidate.years_experience / min_years if min_years else 1.0
    if ratio >= 1.0:
        return min(1.0, 0.82 + (ratio - 1.0) * 0.08)
    return max(0.0, ratio)


def _education_alignment(candidate: CandidateProfile, requirement: str | None) -> float:
    if not requirement:
        return 1.0
    lowered = " ".join(candidate.education).lower()
    requirement = requirement.lower()
    if requirement == "phd":
        return 1.0 if any(token in lowered for token in ("phd", "doctor")) else 0.2
    if requirement == "masters":
        return 1.0 if any(token in lowered for token in ("master", "m.tech", "m.s", "mba", "phd", "doctor")) else 0.35
    if requirement == "bachelors":
        return 1.0 if any(token in lowered for token in ("bachelor", "b.tech", "b.e", "b.s", "master", "phd")) else 0.45
    return 0.5


def _location_alignment(candidate: CandidateProfile, location_terms: set[str]) -> float:
    if not location_terms:
        return 0.5
    candidate_terms = set(_tokenize(candidate.location or ""))
    return 1.0 if location_terms & candidate_terms else 0.0


class DocumentRetriever:
    def __init__(self, base_url: str | None = None, timeout_seconds: float = 15.0, state: RuntimeState | None = None) -> None:
        self.base_url = (base_url or "").rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.state = state
        self._embedding_cache: dict[str, list[float]] = {}
        self._embedder = SentenceTransformer("BAAI/bge-small-en-v1.5") if SentenceTransformer is not None else None

    def _embed_text(self, cache_key: str, text: str) -> list[float]:
        if cache_key in self._embedding_cache:
            return self._embedding_cache[cache_key]
        if self._embedder is not None:  # pragma: no cover - optional runtime path
            vector = [float(value) for value in self._embedder.encode(text, normalize_embeddings=True).tolist()]
        else:
            vector = _hashed_embedding(text)
        self._embedding_cache[cache_key] = vector
        return vector

    def query_for_job(self, job: JobProfile, k: int = 8, workspace_id: str | None = None) -> list[RetrievalHit]:
        plan = _search_plan_from_job(job)
        workspace_id = workspace_id or infer_workspace_from_entity_id(job.job_id)
        return self._query_local_state(plan, k, workspace_id=workspace_id) if self.state is not None else self.query(plan.text, k=k)

    def query(self, query: str, k: int = 8) -> list[RetrievalHit]:
        if self.state is not None:
            return self._query_local_state(_search_plan_from_query(query), k)

        try:
            response = httpx.post(
                f"{self.base_url}/v1/query",
                json={"query": query, "k": k},
                timeout=self.timeout_seconds,
            )
            response.raise_for_status()
            payload = response.json()
        except Exception:
            return []

        hits: list[RetrievalHit] = []
        for index, item in enumerate(payload, start=1):
            metadata = item.get("metadata") or {}
            source_path = (
                metadata.get("path")
                or item.get("path")
                or metadata.get("source")
                or item.get("source_path")
            )
            candidate_id = metadata.get("candidate_id")
            if not candidate_id and source_path:
                candidate_id = candidate_id_from_path(str(source_path))
            if not candidate_id:
                candidate_id = f"unknown-{index}"
            raw_score = item.get("score")
            if raw_score is None and item.get("dist") is not None:
                raw_score = 1.0 / (1.0 + float(item["dist"]))
            if raw_score is None and item.get("distance") is not None:
                raw_score = 1.0 / (1.0 + float(item["distance"]))
            if raw_score is None:
                raw_score = 1.0 / index
            snippet = item.get("text") or item.get("chunk") or item.get("document") or item.get("content") or ""
            hits.append(
                RetrievalHit(
                    candidate_id=str(candidate_id),
                    rank=index,
                    score=float(raw_score),
                    snippet=str(snippet),
                    source_path=str(source_path) if source_path else None,
                    metadata=dict(metadata),
                )
            )
        return hits

    def statistics(self) -> dict[str, object]:
        if self.state is not None:
            candidates = self.state.list_candidates()
            documents = self.state.document_registry()
            return {
                "backend": "hybrid_semantic_structured",
                "indexed_candidates": len(candidates),
                "indexed_documents": len(documents),
                "state_revision": self.state.revision,
                "status": "ready" if candidates else "warming",
            }
        try:
            response = httpx.get(f"{self.base_url}/v1/statistics", timeout=self.timeout_seconds)
            response.raise_for_status()
            return response.json()
        except Exception:
            return {}

    def list_indexed_documents(self) -> list[dict]:
        if self.state is not None:
            return self.state.document_registry()
        try:
            response = httpx.post(
                f"{self.base_url}/v2/list_documents",
                json={"keys": ["path", "modified_at"]},
                timeout=self.timeout_seconds,
            )
            response.raise_for_status()
            payload = response.json()
            return payload if isinstance(payload, list) else []
        except Exception:
            return []

    def _query_local_state(self, plan: SearchPlan, k: int, workspace_id: str | None = None) -> list[RetrievalHit]:
        if self.state is None:
            return []
        candidates = self.state.list_candidates()
        if workspace_id:
            candidates = [
                candidate
                for candidate in candidates
                if belongs_to_workspace(entity_id=candidate.candidate_id, source_path=candidate.source_path, workspace_id=workspace_id)
            ]
        if not candidates:
            return []

        weights = _idf_weights(candidates)
        query_vector = self._embed_text(f"query::{hashlib.sha1(plan.text.encode('utf-8')).hexdigest()}", plan.text)
        job_family_terms = set(group_skills([*plan.required_skills, *plan.preferred_skills]).keys())
        hits: list[tuple[float, RetrievalHit]] = []

        for candidate in candidates:
            candidate_skill_terms = _normalize_terms(candidate.skills)
            profile_terms = set(_tokenize(format_candidate_document(candidate)))
            required_score, required_matches = _coverage_score(candidate_skill_terms, plan.required_skills)
            preferred_score, preferred_matches = _coverage_score(candidate_skill_terms, plan.preferred_skills)
            keyword_score, keyword_matches = _weighted_overlap(plan.keywords or plan.query_terms, profile_terms, weights)
            title_score, _ = _weighted_overlap(plan.title_terms, set(_tokenize(candidate.current_title or "")), weights)
            location_score = _location_alignment(candidate, plan.location_terms)
            experience_score = _experience_alignment(candidate, plan.min_years_experience)
            education_score = _education_alignment(candidate, plan.education_requirement)

            best_score = 0.0
            best_hit: RetrievalHit | None = None
            best_semantic = 0.0
            best_lexical = 0.0

            for section_name, section_text in _candidate_sections(candidate):
                section_terms = set(_tokenize(section_text))
                section_cache_key = f"{candidate.candidate_id}:{candidate.source_checksum or candidate.last_updated.isoformat()}:{section_name}"
                semantic_score = _cosine_similarity(query_vector, self._embed_text(section_cache_key, section_text))
                lexical_score, matched_terms = _weighted_overlap(plan.query_terms, section_terms, weights)
                family_overlap = len(set(candidate.skill_groups.keys()) & job_family_terms) if candidate.skill_groups else 0
                structured_score = (
                    required_score * 0.45
                    + preferred_score * 0.10
                    + keyword_score * 0.10
                    + title_score * 0.10
                    + location_score * 0.08
                    + experience_score * 0.12
                    + education_score * 0.05
                )
                if candidate.skill_groups and plan.required_skills:
                    structured_score = min(1.0, structured_score + min(0.08, family_overlap * 0.02))
                hybrid_score = semantic_score * 0.36 + lexical_score * 0.29 + structured_score * 0.35
                if hybrid_score <= best_score:
                    continue
                best_score = hybrid_score
                best_semantic = semantic_score
                best_lexical = lexical_score
                snippet = section_text[:420]
                highlight_terms = sorted(set(matched_terms + required_matches + preferred_matches + keyword_matches))[:8]
                best_hit = RetrievalHit(
                    candidate_id=candidate.candidate_id,
                    rank=0,
                    score=round(min(1.0, hybrid_score), 4),
                    snippet=snippet,
                    source_path=candidate.source_path,
                    section=section_name,
                    matched_terms=highlight_terms,
                    channel_scores={
                        "semantic": round(semantic_score, 4),
                        "lexical": round(lexical_score, 4),
                        "structured": round(structured_score, 4),
                    },
                    metadata={
                        "candidate_id": candidate.candidate_id,
                        "candidate_name": candidate.name,
                        "skills": candidate.skills,
                        "path": candidate.source_path,
                        "last_updated": candidate.last_updated.isoformat(),
                        "section": section_name,
                    },
                )

            if best_hit is None:
                continue

            # Use the best section score, but strengthen candidates that align structurally even when the wording differs.
            final_score = min(
                1.0,
                best_score * 0.72
                + required_score * 0.12
                + preferred_score * 0.04
                + keyword_score * 0.04
                + experience_score * 0.04
                + max(best_semantic, best_lexical) * 0.04,
            )
            best_hit.score = round(final_score, 4)
            best_hit.channel_scores["semantic"] = round(best_semantic, 4)
            best_hit.channel_scores["lexical"] = round(best_lexical, 4)
            hits.append((final_score, best_hit))

        hits.sort(key=lambda item: (item[0], item[1].candidate_id), reverse=True)
        ranked_hits: list[RetrievalHit] = []
        for index, (_, hit) in enumerate(hits[:k], start=1):
            hit.rank = index
            ranked_hits.append(hit)
        return ranked_hits
