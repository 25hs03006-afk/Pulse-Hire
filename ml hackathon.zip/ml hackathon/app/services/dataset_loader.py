from __future__ import annotations

import hashlib
import json
import threading
import time
from pathlib import Path

from app.config import Settings
from app.models import CandidateProfile
from app.services.parsers.resume_parser import build_synthetic_candidate, parse_resume_records
from app.services.workspaces import SAMPLE_WORKSPACE, infer_workspace_from_entity_id, infer_workspace_from_relative_root, scoped_entity_id

FIRST_NAMES = [
    "Aarav",
    "Aditi",
    "Ananya",
    "Arjun",
    "Diya",
    "Ishaan",
    "Karthik",
    "Meera",
    "Neha",
    "Nikhil",
    "Priya",
    "Rahul",
    "Rhea",
    "Rohan",
    "Sana",
    "Siddharth",
    "Tanya",
    "Varun",
    "Vikram",
    "Zoya",
]

LAST_NAMES = [
    "Agarwal",
    "Banerjee",
    "Chopra",
    "Desai",
    "Gupta",
    "Iyer",
    "Joshi",
    "Kapoor",
    "Menon",
    "Nair",
    "Patel",
    "Rao",
    "Reddy",
    "Shah",
    "Sharma",
    "Singh",
    "Srinivasan",
    "Varma",
    "Verma",
    "Yadav",
]

LOCATIONS = [
    "Bengaluru, India",
    "Hyderabad, India",
    "Mumbai, India",
    "Pune, India",
    "Chennai, India",
    "Remote",
]

CANDIDATE_TEMPLATES = [
    {
        "family": "software",
        "title": "Software Engineer",
        "skills": ["Python", "REST APIs", "Docker", "Git", "CI/CD", "SQL", "Microservices"],
        "summary": "Builds production software systems, backend services, and resilient engineering workflows.",
        "education": ["B.Tech in Computer Science"],
        "experience": [
            "Built and maintained production APIs for high-volume user traffic.",
            "Improved service reliability, deployment speed, and observability.",
            "Collaborated across engineering, product, and operations teams.",
        ],
    },
    {
        "family": "data_science",
        "title": "Data Scientist",
        "skills": ["Python", "SQL", "Machine Learning", "Pandas", "Scikit-learn", "A/B Testing"],
        "summary": "Develops machine learning models, evaluation workflows, and analytical decision systems.",
        "education": ["M.S. in Data Science"],
        "experience": [
            "Built classification and forecasting models for business decisions.",
            "Designed experiments and communicated outcomes to stakeholders.",
            "Operationalized data workflows for recurring model updates.",
        ],
    },
    {
        "family": "rag",
        "title": "Applied AI Engineer",
        "skills": ["Python", "RAG", "Pathway", "FastAPI", "Vector Search", "Docker", "AWS", "LLMs"],
        "summary": "Builds retrieval pipelines, LLM applications, and live document intelligence workflows.",
        "education": ["B.Tech in Information Technology"],
        "experience": [
            "Shipped grounded RAG assistants with hybrid retrieval and evidence tracing.",
            "Designed live ingestion and ranking pipelines for changing document corpora.",
            "Worked on evaluation, latency tuning, and production deployment.",
        ],
    },
    {
        "family": "design",
        "title": "Product Designer",
        "skills": ["Figma", "UX Design", "UI Design", "User Research", "Stakeholder Management"],
        "summary": "Designs thoughtful digital workflows, clear interfaces, and user-centered product experiences.",
        "education": ["Bachelor of Design"],
        "experience": [
            "Created end-to-end product workflows from research to polished UI.",
            "Ran interviews, usability studies, and design reviews with stakeholders.",
            "Partnered closely with product and engineering teams to ship production experiences.",
        ],
    },
    {
        "family": "product",
        "title": "Product Manager",
        "skills": ["Product Strategy", "Stakeholder Management", "A/B Testing", "SQL", "Tableau"],
        "summary": "Leads product discovery, roadmap decisions, and outcome-focused prioritization.",
        "education": ["MBA"],
        "experience": [
            "Owned roadmaps and aligned teams around measurable business outcomes.",
            "Used analytics and experimentation to validate product decisions.",
            "Worked with engineering and design to ship iterative improvements.",
        ],
    },
]


class ResumeDatasetLoader:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.raw_dir = settings.resumes_dir
        self.stream_dir = settings.resume_stream_dir
        self.generated_dir = settings.resume_stream_dir
        self.cache_dir = settings.cache_dir
        self.manifest_path = self.cache_dir / "resume_loader_manifest.json"
        self.suppression_path = self.cache_dir / "resume_loader_suppressions.json"
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._lock = threading.RLock()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, daemon=True, name="resume-loader")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def suppress_candidate(self, candidate_id: str) -> None:
        with self._lock:
            payload = self._load_json(self.suppression_path, default={"candidate_ids": []})
            candidate_ids = set(payload.get("candidate_ids", []))
            candidate_ids.add(candidate_id)
            self._write_json(self.suppression_path, {"candidate_ids": sorted(candidate_ids)})
            workspace_id = infer_workspace_from_entity_id(candidate_id)
            stream_base = self.stream_dir if workspace_id == SAMPLE_WORKSPACE else self.stream_dir / workspace_id
            for target in [stream_base / f"{candidate_id}.json", self.generated_dir / f"{candidate_id}.json"]:
                target.unlink(missing_ok=True)

    def restore_candidate(self, candidate_id: str) -> None:
        with self._lock:
            payload = self._load_json(self.suppression_path, default={"candidate_ids": []})
            candidate_ids = set(payload.get("candidate_ids", []))
            if candidate_id not in candidate_ids:
                return
            candidate_ids.remove(candidate_id)
            self._write_json(self.suppression_path, {"candidate_ids": sorted(candidate_ids)})

    def sync_once(self) -> None:
        with self._lock:
            manifest = self._load_json(self.manifest_path, default={})
            suppressions = set(self._load_json(self.suppression_path, default={"candidate_ids": []}).get("candidate_ids", []))
            active_sources = {str(path): path for path in self.raw_dir.rglob("*") if path.is_file()}
            next_manifest: dict[str, dict] = {}
            active_candidate_ids: set[str] = set()

            for source_path_str, source_path in active_sources.items():
                workspace_id = infer_workspace_from_relative_root(self.raw_dir, source_path)
                checksum = hashlib.sha1(source_path.read_bytes()).hexdigest()
                record = manifest.get(source_path_str, {})
                stream_paths = [Path(path) for path in record.get("stream_paths", []) if path]
                cached_candidate_ids = set(record.get("candidate_ids", []))
                cache_complete = (
                    record.get("checksum") == checksum
                    and not record.get("error")
                    and (
                        (stream_paths and all(path.exists() for path in stream_paths))
                        or (cached_candidate_ids and not stream_paths and cached_candidate_ids.issubset(suppressions))
                    )
                )
                if cache_complete:
                    next_manifest[source_path_str] = record
                    active_candidate_ids.update(
                        candidate_id for candidate_id in record.get("candidate_ids", []) if candidate_id not in suppressions
                    )
                    continue

                old_paths = {Path(path) for path in record.get("stream_paths", [])}
                try:
                    raw_bytes = source_path.read_bytes()
                    candidates = parse_resume_records(
                        source_path.name,
                        raw_bytes,
                        {"path": source_path_str, "modified_at": source_path.stat().st_mtime},
                    )
                    parsed_candidate_ids = [scoped_entity_id(workspace_id, candidate.candidate_id) for candidate in candidates]
                    new_paths: list[str] = []
                    for candidate in candidates:
                        scoped_candidate_id = scoped_entity_id(workspace_id, candidate.candidate_id)
                        if scoped_candidate_id in suppressions:
                            continue
                        stream_dir = self.stream_dir if workspace_id == SAMPLE_WORKSPACE else self.stream_dir / workspace_id
                        stream_path = stream_dir / f"{scoped_candidate_id}.json"
                        materialized = candidate.model_copy(
                            update={
                                "candidate_id": scoped_candidate_id,
                                "source_path": str(stream_path),
                                "origin_source_path": source_path_str,
                                "source_name": source_path.name,
                                "source_mode": "dataset",
                            }
                        )
                        self._write_text_atomic(stream_path, materialized.model_dump_json(indent=2))
                        new_paths.append(str(stream_path))
                        active_candidate_ids.add(scoped_candidate_id)
                    for stale in old_paths - {Path(path) for path in new_paths}:
                        stale.unlink(missing_ok=True)
                    next_manifest[source_path_str] = {
                        "checksum": checksum,
                        "candidate_ids": parsed_candidate_ids,
                        "stream_paths": new_paths,
                    }
                except Exception as exc:
                    for stale in old_paths:
                        stale.unlink(missing_ok=True)
                    next_manifest[source_path_str] = {
                        "checksum": checksum,
                        "candidate_ids": [],
                        "stream_paths": [],
                        "error": str(exc),
                    }

            removed_sources = set(manifest) - set(active_sources)
            for removed in removed_sources:
                for path in manifest.get(removed, {}).get("stream_paths", []):
                    Path(path).unlink(missing_ok=True)

            self._ensure_generated_candidates(active_candidate_ids, suppressions)
            self._write_json(self.manifest_path, next_manifest)

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.sync_once()
            except Exception:
                pass
            self._stop.wait(self.settings.loader_poll_interval_seconds)

    def _ensure_generated_candidates(self, active_candidate_ids: set[str], suppressions: set[str]) -> None:
        if not self.settings.allow_synthetic_backfill or self.settings.minimum_candidate_pool_size <= 0:
            for stale in self.generated_dir.glob("synthetic-*.json"):
                stale.unlink(missing_ok=True)
            return
        real_count = len(active_candidate_ids)
        target = max(self.settings.minimum_candidate_pool_size, real_count)
        needed = max(target - real_count, 0)
        desired_ids: list[str] = []
        index = 0
        while len(desired_ids) < needed:
            candidate_id = f"synthetic-{index + 1:04d}"
            index += 1
            if candidate_id in suppressions:
                continue
            desired_ids.append(candidate_id)
            if (self.generated_dir / f"{candidate_id}.json").exists():
                continue
            profile = self._build_generated_candidate(candidate_id, index)
            stream_path = self.generated_dir / f"{candidate_id}.json"
            materialized = profile.model_copy(update={"source_path": str(stream_path), "source_mode": "synthetic"})
            self._write_text_atomic(stream_path, materialized.model_dump_json(indent=2))
        for stale in self.generated_dir.glob("synthetic-*.json"):
            if stale.stem not in set(desired_ids):
                stale.unlink(missing_ok=True)

    def _build_generated_candidate(self, candidate_id: str, index: int) -> CandidateProfile:
        template = CANDIDATE_TEMPLATES[index % len(CANDIDATE_TEMPLATES)]
        first_name = FIRST_NAMES[index % len(FIRST_NAMES)]
        last_name = LAST_NAMES[(index // len(FIRST_NAMES)) % len(LAST_NAMES)]
        name = f"{first_name} {last_name}"
        location = LOCATIONS[index % len(LOCATIONS)]
        years_experience = float(1 + (index % 12))
        bonus_skills = []
        if template["family"] in {"software", "rag"} and index % 3 == 0:
            bonus_skills.append("Kubernetes")
        if template["family"] == "data_science" and index % 2 == 0:
            bonus_skills.append("PyTorch")
        if template["family"] == "product" and index % 2 == 1:
            bonus_skills.append("User Research")
        skills = [*template["skills"], *bonus_skills]
        source_path = str(self.generated_dir / f"{candidate_id}.json")
        return build_synthetic_candidate(
            candidate_id=candidate_id,
            name=name,
            title=template["title"],
            location=location,
            summary=template["summary"],
            skills=skills,
            experience_highlights=[
                template["experience"][0],
                template["experience"][1],
                f"Owned outcomes across {years_experience:.0f} years of delivery.",
            ],
            education=template["education"],
            years_experience=years_experience,
            source_path=source_path,
        )

    def _write_text_atomic(self, path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.cache_dir / f"{path.name}.{time.time_ns()}.tmp"
        temporary.parent.mkdir(parents=True, exist_ok=True)
        temporary.write_text(content, encoding="utf-8")
        temporary.replace(path)

    def _load_json(self, path: Path, default):
        if not path.exists():
            return default
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default

    def _write_json(self, path: Path, payload: dict) -> None:
        self._write_text_atomic(path, json.dumps(payload, indent=2))
