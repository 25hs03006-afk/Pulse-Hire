from __future__ import annotations

import secrets
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from app.models import (
    ApprovalDraft,
    ApprovalSignoffDraft,
    ATSRequisitionDraft,
    CandidateStageDraft,
    CollaborationCommentDraft,
    InterviewDraft,
    JobProfile,
    OfferDraft,
    ScorecardDraft,
)
from app.services.sqlite_store import SQLiteJsonStore

DEFAULT_STAGE_ORDER = ["Applied", "Screening", "Technical", "Hiring Manager", "Offer", "Hired"]


def _stamp() -> str:
    return datetime.now(UTC).isoformat()


class ATSWorkflowStore:
    def __init__(self, database_path: Path) -> None:
        self._store = SQLiteJsonStore(database_path)
        self._requisitions = "ats_requisitions"
        self._candidate_stages = "ats_candidate_stages"
        self._interviews = "ats_interviews"
        self._scorecards = "ats_scorecards"
        self._approvals = "ats_approvals"
        self._offers = "ats_offers"
        self._threads = "ats_threads"

    def ensure_requisition(self, workspace_id: str, job: JobProfile) -> dict[str, Any]:
        existing = self._store.get(self._requisitions, job.job_id)
        if existing:
            existing["title"] = job.title
            existing["team"] = job.team
            existing["hiring_target"] = job.hiring_target
            existing["updated_at"] = _stamp()
            self._store.set(self._requisitions, job.job_id, existing)
            return existing
        payload = {
            "job_id": job.job_id,
            "workspace_id": workspace_id,
            "title": job.title,
            "team": job.team,
            "priority": "medium",
            "requested_headcount": job.hiring_target,
            "requested_by": None,
            "hiring_manager": None,
            "budget_code": None,
            "approval_status": "approved",
            "requisition_status": "open",
            "stage_order": DEFAULT_STAGE_ORDER[:],
            "notes": None,
            "created_at": _stamp(),
            "updated_at": _stamp(),
        }
        self._store.set(self._requisitions, job.job_id, payload)
        return payload

    def upsert_requisition(self, workspace_id: str, payload: ATSRequisitionDraft, job: JobProfile) -> dict[str, Any]:
        requisition = self.ensure_requisition(workspace_id, job)
        requisition.update(
            {
                "priority": payload.priority,
                "requested_headcount": max(1, payload.requested_headcount),
                "requested_by": payload.requested_by,
                "hiring_manager": payload.hiring_manager,
                "budget_code": payload.budget_code,
                "notes": payload.notes,
                "stage_order": payload.stage_order or requisition.get("stage_order") or DEFAULT_STAGE_ORDER[:],
                "updated_at": _stamp(),
            }
        )
        self._store.set(self._requisitions, job.job_id, requisition)
        return requisition

    def list_requisitions(self, workspace_id: str) -> list[dict[str, Any]]:
        items = [item for item in self._store.get_namespace(self._requisitions).values() if item.get("workspace_id") == workspace_id]
        items.sort(key=lambda item: item.get("updated_at", ""), reverse=True)
        return items

    def request_approval(self, workspace_id: str, payload: ApprovalDraft) -> dict[str, Any]:
        approval_id = secrets.token_urlsafe(8)
        record = {
            "approval_id": approval_id,
            "workspace_id": workspace_id,
            "job_id": payload.job_id,
            "approval_type": payload.approval_type,
            "requested_by": payload.requested_by,
            "approvers": payload.approvers,
            "notes": payload.notes,
            "status": "pending",
            "signoffs": [],
            "created_at": _stamp(),
            "updated_at": _stamp(),
        }
        self._store.set(self._approvals, approval_id, record)
        return record

    def signoff_approval(self, workspace_id: str, approval_id: str, payload: ApprovalSignoffDraft) -> dict[str, Any] | None:
        record = self._store.get(self._approvals, approval_id)
        if not record or record.get("workspace_id") != workspace_id:
            return None
        signoffs = list(record.get("signoffs") or [])
        signoffs = [item for item in signoffs if item.get("approver") != payload.approver]
        signoffs.append({"approver": payload.approver, "decision": payload.decision, "notes": payload.notes, "at": _stamp()})
        record["signoffs"] = signoffs
        required = set(record.get("approvers") or [])
        approved = {item["approver"] for item in signoffs if item.get("decision") == "approved"}
        rejected = any(item.get("decision") == "rejected" for item in signoffs)
        if rejected:
            record["status"] = "rejected"
        elif required and required.issubset(approved):
            record["status"] = "approved"
        else:
            record["status"] = "pending"
        record["updated_at"] = _stamp()
        self._store.set(self._approvals, approval_id, record)
        return record

    def advance_candidate_stage(self, workspace_id: str, job_id: str, candidate_id: str, payload: CandidateStageDraft) -> dict[str, Any]:
        record_key = f"{job_id}::{candidate_id}"
        stage_state = self._store.get(self._candidate_stages, record_key) or {
            "workspace_id": workspace_id,
            "job_id": job_id,
            "candidate_id": candidate_id,
            "history": [],
        }
        stage_state["current_stage"] = payload.stage
        stage_state["decision"] = payload.decision
        history = list(stage_state.get("history") or [])
        history.append(
            {
                "stage": payload.stage,
                "actor": payload.actor,
                "notes": payload.notes,
                "decision": payload.decision,
                "at": _stamp(),
            }
        )
        stage_state["history"] = history
        stage_state["updated_at"] = _stamp()
        self._store.set(self._candidate_stages, record_key, stage_state)
        return stage_state

    def pipeline_for_job(self, workspace_id: str, job_id: str, rankings: list[dict[str, Any]]) -> dict[str, Any]:
        stages = [item for key, item in self._store.get_namespace(self._candidate_stages).items() if item.get("workspace_id") == workspace_id and item.get("job_id") == job_id]
        stage_map = {item.get("candidate_id"): item for item in stages}
        stage_counts: dict[str, int] = {}
        cards: list[dict[str, Any]] = []
        for ranking in rankings:
            candidate = ranking.get("candidate") or {}
            candidate_id = candidate.get("candidate_id")
            stage_state = stage_map.get(candidate_id) or {}
            stage = stage_state.get("current_stage") or "Applied"
            stage_counts[stage] = stage_counts.get(stage, 0) + 1
            cards.append(
                {
                    "candidate_id": candidate_id,
                    "candidate_name": candidate.get("name"),
                    "rank": ranking.get("rank"),
                    "match_score": ((ranking.get("breakdown") or {}).get("total_score")),
                    "confidence": ((ranking.get("breakdown") or {}).get("confidence_score")),
                    "stage": stage,
                    "decision": stage_state.get("decision"),
                    "history": stage_state.get("history", [])[-4:],
                }
            )
        return {"job_id": job_id, "stage_counts": stage_counts, "cards": cards}

    def schedule_interview(self, workspace_id: str, payload: InterviewDraft) -> dict[str, Any]:
        interview_id = secrets.token_urlsafe(8)
        record = {
            "interview_id": interview_id,
            "workspace_id": workspace_id,
            "job_id": payload.job_id,
            "candidate_id": payload.candidate_id,
            "stage": payload.stage,
            "interviewer": payload.interviewer,
            "scheduled_for": payload.scheduled_for,
            "mode": payload.mode,
            "meeting_link": payload.meeting_link,
            "agenda": payload.agenda,
            "status": "scheduled",
            "created_at": _stamp(),
        }
        self._store.set(self._interviews, interview_id, record)
        return record

    def submit_scorecard(self, workspace_id: str, payload: ScorecardDraft) -> dict[str, Any]:
        scorecard_id = secrets.token_urlsafe(8)
        rubric_scores = {key: float(value) for key, value in payload.rubric_scores.items()}
        overall = round(sum(rubric_scores.values()) / max(len(rubric_scores), 1), 4) if rubric_scores else 0.0
        record = {
            "scorecard_id": scorecard_id,
            "workspace_id": workspace_id,
            "job_id": payload.job_id,
            "candidate_id": payload.candidate_id,
            "interviewer": payload.interviewer,
            "stage": payload.stage,
            "rubric_scores": rubric_scores,
            "overall_score": overall,
            "recommendation": payload.recommendation,
            "strengths": payload.strengths,
            "concerns": payload.concerns,
            "notes": payload.notes,
            "created_at": _stamp(),
        }
        self._store.set(self._scorecards, scorecard_id, record)
        return record

    def create_offer(self, workspace_id: str, payload: OfferDraft) -> dict[str, Any]:
        offer_id = secrets.token_urlsafe(8)
        record = {
            "offer_id": offer_id,
            "workspace_id": workspace_id,
            "job_id": payload.job_id,
            "candidate_id": payload.candidate_id,
            "owner": payload.owner,
            "compensation": payload.compensation,
            "status": payload.status,
            "notes": payload.notes,
            "created_at": _stamp(),
            "updated_at": _stamp(),
        }
        self._store.set(self._offers, offer_id, record)
        return record

    def add_thread_comment(self, workspace_id: str, payload: CollaborationCommentDraft) -> dict[str, Any]:
        comment_id = secrets.token_urlsafe(8)
        record = {
            "comment_id": comment_id,
            "workspace_id": workspace_id,
            "job_id": payload.job_id,
            "candidate_id": payload.candidate_id,
            "author": payload.author,
            "channel": payload.channel,
            "message": payload.message,
            "created_at": _stamp(),
        }
        self._store.set(self._threads, comment_id, record)
        return record

    def candidate_packet(self, workspace_id: str, job_id: str, candidate_id: str) -> dict[str, Any]:
        interviews = [
            item for item in self._store.get_namespace(self._interviews).values()
            if item.get("workspace_id") == workspace_id and item.get("job_id") == job_id and item.get("candidate_id") == candidate_id
        ]
        scorecards = [
            item for item in self._store.get_namespace(self._scorecards).values()
            if item.get("workspace_id") == workspace_id and item.get("job_id") == job_id and item.get("candidate_id") == candidate_id
        ]
        offers = [
            item for item in self._store.get_namespace(self._offers).values()
            if item.get("workspace_id") == workspace_id and item.get("job_id") == job_id and item.get("candidate_id") == candidate_id
        ]
        comments = [
            item for item in self._store.get_namespace(self._threads).values()
            if item.get("workspace_id") == workspace_id and item.get("job_id") == job_id and (not item.get("candidate_id") or item.get("candidate_id") == candidate_id)
        ]
        stage_state = self._store.get(self._candidate_stages, f"{job_id}::{candidate_id}") or {}
        return {
            "stage_state": stage_state,
            "interviews": sorted(interviews, key=lambda item: item.get("scheduled_for", "")),
            "scorecards": sorted(scorecards, key=lambda item: item.get("created_at", ""), reverse=True),
            "offers": sorted(offers, key=lambda item: item.get("created_at", ""), reverse=True),
            "comments": sorted(comments, key=lambda item: item.get("created_at", ""), reverse=True),
        }

    def list_approvals(self, workspace_id: str, job_id: str | None = None) -> list[dict[str, Any]]:
        approvals = [item for item in self._store.get_namespace(self._approvals).values() if item.get("workspace_id") == workspace_id]
        if job_id:
            approvals = [item for item in approvals if item.get("job_id") == job_id]
        approvals.sort(key=lambda item: item.get("updated_at", ""), reverse=True)
        return approvals
