from __future__ import annotations

import secrets
from datetime import UTC, datetime, timedelta
from pathlib import Path
from threading import RLock
from typing import Any
import re

from app.config import Settings
from app.models import (
    CandidateCertificationEntry,
    ConversationMessage,
    CandidateEducationEntry,
    CandidateExperienceEntry,
    CandidateProfile,
    CandidateProfileDraft,
    CandidateProjectEntry,
    CandidateSession,
    NotificationEntry,
    TimelineEvent,
)
from app.services.parsers.extractors import parse_resume_document, slugify_identifier
from app.services.security import hash_password, password_needs_rehash, verify_password
from app.services.skills import group_skills, normalize_skills
from app.services.sqlite_store import SQLiteJsonStore
from app.services.workspaces import scoped_entity_id, workspace_source_dir

SESSION_TTL = timedelta(hours=12)


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _stamp() -> str:
    return _utc_now().isoformat()


def _base_name(file_name: str) -> str:
    return Path(file_name).name or "document"


def _name_key(value: str | None) -> str:
    return slugify_identifier(value or "")


def seed_candidate_password(full_name: str) -> str:
    first = re.sub(r"[^A-Za-z0-9]+", "", (full_name or "").split(" ")[0]).strip() or "Candidate"
    return f"{first}@201588"


def _document_terms(document: dict[str, Any]) -> set[str]:
    raw_terms: set[str] = set()
    for value in [*(document.get("tags") or []), document.get("title") or "", document.get("file_name") or ""]:
        for part in re.split(r"[,|/_\-]+", str(value)):
            cleaned = part.strip().lower()
            if cleaned:
                raw_terms.add(cleaned)
    return raw_terms


class CandidatePortalStore:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.root_dir = settings.cache_dir / "candidate_portal"
        self.files_dir = self.root_dir / "files"
        self.root_dir.mkdir(parents=True, exist_ok=True)
        self.files_dir.mkdir(parents=True, exist_ok=True)
        self._store = SQLiteJsonStore(self.root_dir / "candidate_portal.db")
        self.accounts_namespace = "candidate_accounts"
        self.profiles_namespace = "candidate_profiles"
        self.applications_namespace = "candidate_applications"
        self.documents_namespace = "candidate_documents"
        self.notifications_namespace = "candidate_notifications"
        self.timeline_namespace = "candidate_timeline"
        self.sessions_namespace = "candidate_sessions"
        self.messages_namespace = "candidate_messages"
        self._lock = RLock()

    def _load_accounts(self) -> dict[str, dict[str, Any]]:
        return self._store.get_namespace(self.accounts_namespace)

    def _load_profiles(self) -> dict[str, dict[str, Any]]:
        return self._store.get_namespace(self.profiles_namespace)

    def _load_applications(self) -> dict[str, dict[str, Any]]:
        return self._store.get_namespace(self.applications_namespace)

    def _load_documents(self) -> dict[str, dict[str, Any]]:
        return self._store.get_namespace(self.documents_namespace)

    def _load_notifications(self) -> dict[str, dict[str, Any]]:
        return self._store.get_namespace(self.notifications_namespace)

    def _load_timeline(self) -> dict[str, dict[str, Any]]:
        return self._store.get_namespace(self.timeline_namespace)

    def _load_messages(self) -> dict[str, dict[str, Any]]:
        return self._store.get_namespace(self.messages_namespace)

    def register_candidate(self, *, full_name: str, email: str, password: str) -> CandidateSession:
        email_key = email.strip().lower()
        if len(password.strip()) < 8:
            raise ValueError("Password must be at least 8 characters long.")
        with self._lock:
            accounts = self._load_accounts()
            if any(record.get("email") == email_key for record in accounts.values()):
                raise ValueError("A candidate account with that email already exists.")
            candidate_account_id = slugify_identifier(f"{full_name}-{email_key}") or secrets.token_hex(6)
            salt = secrets.token_hex(12)
            accounts[candidate_account_id] = {
                "candidate_account_id": candidate_account_id,
                "full_name": full_name.strip(),
                "email": email_key,
                "salt": salt,
                "password_hash": hash_password(password, salt),
                "created_at": _stamp(),
                "seeded": False,
            }
            self._store.replace_namespace(self.accounts_namespace, accounts)
            return self._create_session(accounts[candidate_account_id])

    def login_candidate(self, *, identifier: str, password: str) -> CandidateSession:
        lookup = identifier.strip()
        email_key = lookup.lower()
        name_key = _name_key(lookup)
        with self._lock:
            accounts = self._load_accounts()
            record = next(
                (
                    item
                    for item in accounts.values()
                    if item.get("email") == email_key or _name_key(item.get("full_name")) == name_key
                ),
                None,
            )
            if not record:
                raise ValueError("Candidate account not found.")
            if not verify_password(password, record.get("salt"), record["password_hash"]):
                raise ValueError("Incorrect password.")
            if password_needs_rehash(str(record["password_hash"])):
                record["password_hash"] = hash_password(password, record.get("salt"))
                accounts[record["candidate_account_id"]] = record
                self._store.replace_namespace(self.accounts_namespace, accounts)
            return self._create_session(record)

    def _create_session(self, record: dict[str, Any]) -> CandidateSession:
        token = secrets.token_urlsafe(32)
        issued_at = _utc_now()
        session = CandidateSession(
            token=token,
            candidate_account_id=record["candidate_account_id"],
            full_name=record["full_name"],
            email=record["email"],
            issued_at=issued_at,
            expires_at=issued_at + SESSION_TTL,
        )
        self._store.set(self.sessions_namespace, token, session.model_dump(mode="json"))
        return session

    def get_session(self, token: str | None) -> CandidateSession | None:
        if not token:
            return None
        with self._lock:
            payload = self._store.get(self.sessions_namespace, token)
            if not payload:
                return None
            session = CandidateSession.model_validate(payload)
            if session.expires_at <= _utc_now():
                self._store.delete(self.sessions_namespace, token)
                return None
            refreshed = session.model_copy(update={"expires_at": _utc_now() + SESSION_TTL})
            self._store.set(self.sessions_namespace, token, refreshed.model_dump(mode="json"))
            return refreshed.model_copy(deep=True)

    def logout(self, token: str | None) -> None:
        if not token:
            return
        with self._lock:
            self._store.delete(self.sessions_namespace, token)

    def delete_candidate_account(self, candidate_account_id: str) -> bool:
        with self._lock:
            accounts = self._load_accounts()
            if candidate_account_id not in accounts:
                return False
            accounts.pop(candidate_account_id, None)
            self._store.replace_namespace(self.accounts_namespace, accounts)

            profiles = self._load_profiles()
            profiles.pop(candidate_account_id, None)
            self._store.replace_namespace(self.profiles_namespace, profiles)

            for token, payload in list(self._store.get_namespace(self.sessions_namespace).items()):
                if str(payload.get("candidate_account_id")) == candidate_account_id:
                    self._store.delete(self.sessions_namespace, token)

            applications = self._load_applications()
            application_ids = [
                application_id
                for application_id, payload in applications.items()
                if payload.get("candidate_account_id") == candidate_account_id
            ]
            for application_id in application_ids:
                application = applications.pop(application_id, None) or {}
                company_id = str(application.get("company_id") or "")
                company_candidate_id = str(application.get("company_candidate_id") or "")
                if company_id and company_candidate_id:
                    stream_path = workspace_source_dir(self.settings.resume_stream_dir, company_id) / f"{company_candidate_id}.json"
                    stream_path.unlink(missing_ok=True)
            self._store.replace_namespace(self.applications_namespace, applications)

            documents = self._load_documents()
            for document_id, payload in list(documents.items()):
                if payload.get("candidate_account_id") != candidate_account_id:
                    continue
                path = Path(str(payload.get("path") or ""))
                if path.exists():
                    path.unlink(missing_ok=True)
                documents.pop(document_id, None)
            self._store.replace_namespace(self.documents_namespace, documents)

            notifications = {
                key: value
                for key, value in self._load_notifications().items()
                if value.get("audience_id") != candidate_account_id
            }
            self._store.replace_namespace(self.notifications_namespace, notifications)

            timeline = {
                key: value
                for key, value in self._load_timeline().items()
                if value.get("candidate_account_id") != candidate_account_id
            }
            self._store.replace_namespace(self.timeline_namespace, timeline)

            messages = {
                key: value
                for key, value in self._load_messages().items()
                if value.get("candidate_account_id") != candidate_account_id
            }
            self._store.replace_namespace(self.messages_namespace, messages)
            return True

    def get_profile(self, candidate_account_id: str) -> dict[str, Any] | None:
        return self._load_profiles().get(candidate_account_id)

    def get_account(self, candidate_account_id: str) -> dict[str, Any] | None:
        return self._load_accounts().get(candidate_account_id)

    def find_account(self, *, full_name: str | None = None, email: str | None = None) -> dict[str, Any] | None:
        email_key = (email or "").strip().lower()
        name_key = _name_key(full_name)
        for account in self._load_accounts().values():
            if email_key and str(account.get("email") or "").strip().lower() == email_key:
                return account
            if name_key and _name_key(str(account.get("full_name") or "")) == name_key:
                return account
        return None

    def save_profile(self, candidate_account_id: str, draft: CandidateProfileDraft) -> dict[str, Any]:
        with self._lock:
            profiles = self._load_profiles()
            payload = draft.model_dump(mode="json")
            payload["candidate_account_id"] = candidate_account_id
            payload["updated_at"] = _stamp()
            profiles[candidate_account_id] = payload
            self._store.replace_namespace(self.profiles_namespace, profiles)
            return payload

    def _resume_to_profile_draft(self, candidate: CandidateProfile) -> CandidateProfileDraft:
        education = [
            CandidateEducationEntry(institution=item, degree="", field=None)
            for item in candidate.education[:6]
            if item.strip()
        ]
        experience = []
        for index, highlight in enumerate(candidate.experience_highlights[:6]):
            title = candidate.current_title if index == 0 else "Experience"
            experience.append(
                CandidateExperienceEntry(
                    company="Previous employer",
                    title=title or "Experience",
                    start_date=None,
                    end_date=None,
                    highlights=[highlight],
                )
            )
        projects = [
            CandidateProjectEntry(name=f"Project {index + 1}", description=item, technologies=[])
            for index, item in enumerate(candidate.projects[:6])
            if item.strip()
        ]
        certifications = [
            CandidateCertificationEntry(name=item, issuer=None, issued_on=None)
            for item in candidate.certifications[:6]
            if item.strip()
        ]
        email = candidate.email or f"{slugify_identifier(candidate.name)}@candidate.pulsehire.local"
        return CandidateProfileDraft(
            full_name=candidate.name,
            email=email,
            phone=candidate.phone,
            location=candidate.location,
            headline=candidate.current_title,
            summary=candidate.summary,
            skills=candidate.skills,
            education=education,
            experience=experience,
            projects=projects,
            certifications=certifications,
        )

    def ensure_seed_accounts_from_resumes(self) -> list[dict[str, Any]]:
        seeded: list[dict[str, Any]] = []
        resume_root = self.settings.resumes_dir
        if not resume_root.exists():
            return seeded
        with self._lock:
            accounts = self._load_accounts()
            profiles = self._load_profiles()
            changed_accounts = False
            changed_profiles = False
            for resume_path in sorted(path for path in resume_root.iterdir() if path.is_file()):
                try:
                    candidate = parse_resume_document(resume_path.name, resume_path.read_bytes(), {"path": str(resume_path)})
                except Exception:
                    continue
                email = (candidate.email or f"{slugify_identifier(candidate.name)}@candidate.pulsehire.local").lower()
                existing = next(
                    (
                        item
                        for item in accounts.values()
                        if item.get("email") == email or _name_key(item.get("full_name")) == _name_key(candidate.name)
                    ),
                    None,
                )
                if existing:
                    candidate_account_id = str(existing["candidate_account_id"])
                else:
                    candidate_account_id = slugify_identifier(f"{candidate.name}-{email}") or secrets.token_hex(6)
                    salt = secrets.token_hex(12)
                    accounts[candidate_account_id] = {
                        "candidate_account_id": candidate_account_id,
                        "full_name": candidate.name.strip(),
                        "email": email,
                        "salt": salt,
                        "password_hash": hash_password(seed_candidate_password(candidate.name), salt),
                        "created_at": _stamp(),
                        "seeded": True,
                        "seed_source_path": str(resume_path),
                    }
                    changed_accounts = True
                if candidate_account_id not in profiles:
                    draft = self._resume_to_profile_draft(candidate).model_dump(mode="json")
                    draft["candidate_account_id"] = candidate_account_id
                    draft["updated_at"] = _stamp()
                    draft["seeded_from_resume"] = str(resume_path)
                    profiles[candidate_account_id] = draft
                    changed_profiles = True
                seeded.append(
                    {
                        "candidate_account_id": candidate_account_id,
                        "full_name": candidate.name,
                        "email": email,
                        "password": seed_candidate_password(candidate.name),
                    }
                )
            if changed_accounts:
                self._store.replace_namespace(self.accounts_namespace, accounts)
            if changed_profiles:
                self._store.replace_namespace(self.profiles_namespace, profiles)
        return seeded

    def _append_notification(
        self,
        *,
        audience_id: str,
        workspace_id: str | None,
        application_id: str | None,
        candidate_id: str | None,
        role_id: str | None,
        category: str,
        title: str,
        message: str,
        severity: str = "info",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        notifications = self._load_notifications()
        notification = NotificationEntry(
            notification_id=secrets.token_urlsafe(10),
            audience_type="candidate",
            audience_id=audience_id,
            workspace_id=workspace_id,
            application_id=application_id,
            candidate_id=candidate_id,
            role_id=role_id,
            category=category,
            title=title,
            message=message,
            severity=severity,
            metadata=metadata or {},
        )
        notifications[notification.notification_id] = notification.model_dump(mode="json")
        self._store.replace_namespace(self.notifications_namespace, notifications)
        return notifications[notification.notification_id]

    def _append_timeline_event(
        self,
        *,
        application_id: str,
        candidate_account_id: str,
        company_id: str,
        company_candidate_id: str | None,
        role_ids: list[str],
        event_type: str,
        title: str,
        description: str,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        timeline = self._load_timeline()
        event = TimelineEvent(
            event_id=secrets.token_urlsafe(10),
            application_id=application_id,
            candidate_account_id=candidate_account_id,
            company_id=company_id,
            company_candidate_id=company_candidate_id,
            role_ids=sorted(set(role_ids)),
            event_type=event_type,
            title=title,
            description=description,
            metadata=metadata or {},
        )
        timeline[event.event_id] = event.model_dump(mode="json")
        self._store.replace_namespace(self.timeline_namespace, timeline)
        return timeline[event.event_id]

    def save_document(
        self,
        *,
        candidate_account_id: str,
        company_id: str,
        role_ids: list[str],
        company_candidate_id: str | None,
        document_type: str,
        file_name: str,
        raw_bytes: bytes,
        tags: list[str] | None = None,
        title: str | None = None,
        application_id: str | None = None,
    ) -> dict[str, Any]:
        with self._lock:
            documents = self._load_documents()
            document_id = secrets.token_urlsafe(10)
            suffix = Path(file_name).suffix.lower()
            storage_name = f"{document_id}{suffix}"
            storage_path = self.files_dir / candidate_account_id / storage_name
            storage_path.parent.mkdir(parents=True, exist_ok=True)
            storage_path.write_bytes(raw_bytes)
            record = {
                "document_id": document_id,
                "candidate_account_id": candidate_account_id,
                "company_id": company_id,
                "company_candidate_id": company_candidate_id,
                "role_ids": sorted(set(role_ids)),
                "document_type": document_type,
                "file_name": _base_name(file_name),
                "title": (title or Path(file_name).stem).strip() or _base_name(file_name),
                "tags": normalize_skills(tags or []),
                "path": str(storage_path),
                "size_bytes": len(raw_bytes),
                "application_id": application_id,
                "uploaded_at": _stamp(),
            }
            documents[document_id] = record
            self._store.replace_namespace(self.documents_namespace, documents)
            if application_id:
                self._append_timeline_event(
                    application_id=application_id,
                    candidate_account_id=candidate_account_id,
                    company_id=company_id,
                    company_candidate_id=company_candidate_id,
                    role_ids=role_ids,
                    event_type="document_uploaded",
                    title=f"{document_type.replace('_', ' ').title()} uploaded",
                    description=f"{record['title']} was attached to the application.",
                    metadata={"document_id": document_id, "document_type": document_type},
                )
            return record

    def documents_for_candidate(self, candidate_account_id: str) -> list[dict[str, Any]]:
        return [
            document
            for document in self._load_documents().values()
            if document.get("candidate_account_id") == candidate_account_id
        ]

    def notifications_for_candidate(self, candidate_account_id: str) -> list[dict[str, Any]]:
        notifications = [
            notification
            for notification in self._load_notifications().values()
            if notification.get("audience_id") == candidate_account_id
        ]
        notifications.sort(key=lambda item: item.get("created_at", ""), reverse=True)
        return notifications

    def mark_notification_read(self, candidate_account_id: str, notification_id: str) -> dict[str, Any] | None:
        with self._lock:
            notifications = self._load_notifications()
            notification = notifications.get(notification_id)
            if not notification or notification.get("audience_id") != candidate_account_id:
                return None
            notification["read"] = True
            notifications[notification_id] = notification
            self._store.replace_namespace(self.notifications_namespace, notifications)
            return notification

    def timeline_for_candidate(self, candidate_account_id: str, company_id: str | None = None) -> list[dict[str, Any]]:
        timeline = [
            event
            for event in self._load_timeline().values()
            if event.get("candidate_account_id") == candidate_account_id
            and (not company_id or event.get("company_id") == company_id)
        ]
        timeline.sort(key=lambda item: item.get("created_at", ""), reverse=True)
        return timeline

    def list_messages(
        self,
        *,
        candidate_account_id: str,
        company_id: str | None = None,
        role_id: str | None = None,
    ) -> list[dict[str, Any]]:
        messages = [
            message
            for message in self._load_messages().values()
            if message.get("candidate_account_id") == candidate_account_id
            and (not company_id or message.get("company_id") == company_id)
            and (not role_id or message.get("role_id") == role_id)
        ]
        messages.sort(key=lambda item: item.get("created_at", ""))
        return messages

    def list_messages_for_company_candidate(
        self,
        *,
        company_id: str,
        company_candidate_id: str,
        role_id: str | None = None,
    ) -> list[dict[str, Any]]:
        messages = [
            message
            for message in self._load_messages().values()
            if message.get("company_id") == company_id
            and message.get("company_candidate_id") == company_candidate_id
            and (not role_id or message.get("role_id") == role_id)
        ]
        messages.sort(key=lambda item: item.get("created_at", ""))
        return messages

    def delete_message(
        self,
        *,
        candidate_account_id: str,
        message_id: str,
    ) -> dict[str, Any] | None:
        with self._lock:
            messages = self._load_messages()
            message = dict(messages.get(message_id) or {})
            if not message:
                return None
            if message.get("candidate_account_id") != candidate_account_id:
                return None
            if message.get("sender_type") != "candidate":
                raise ValueError("Only candidate-authored messages can be removed from the candidate portal.")
            deleted = messages.pop(message_id, None)
            self._store.replace_namespace(self.messages_namespace, messages)
            return deleted

    def post_message(
        self,
        *,
        company_id: str,
        candidate_account_id: str,
        company_candidate_id: str | None,
        role_id: str | None,
        sender_type: str,
        sender_name: str,
        message: str,
        application_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        clean_message = message.strip()
        if len(clean_message) < 4:
            raise ValueError("Please add a more descriptive message.")
        with self._lock:
            messages = self._load_messages()
            record = ConversationMessage(
                message_id=secrets.token_urlsafe(10),
                company_id=company_id,
                candidate_account_id=candidate_account_id,
                company_candidate_id=company_candidate_id,
                application_id=application_id,
                role_id=role_id,
                sender_type="company" if sender_type == "company" else "candidate",
                sender_name=sender_name.strip() or ("Recruiter" if sender_type == "company" else "Candidate"),
                message=clean_message,
                read_by_candidate=sender_type == "candidate",
                read_by_company=sender_type == "company",
                metadata=metadata or {},
            )
            messages[record.message_id] = record.model_dump(mode="json")
            self._store.replace_namespace(self.messages_namespace, messages)
            title = "Recruiter reply" if sender_type == "company" else "Candidate message sent"
            description = clean_message if len(clean_message) <= 180 else f"{clean_message[:177]}..."
            self._append_timeline_event(
                application_id=application_id or f"linked-{company_id}-{candidate_account_id}",
                candidate_account_id=candidate_account_id,
                company_id=company_id,
                company_candidate_id=company_candidate_id,
                role_ids=[role_id] if role_id else [],
                event_type="conversation_message",
                title=title,
                description=description,
                metadata={"sender_type": sender_type, "sender_name": sender_name.strip()},
            )
            if sender_type == "company":
                self._append_notification(
                    audience_id=candidate_account_id,
                    workspace_id=company_id,
                    application_id=application_id,
                    candidate_id=company_candidate_id,
                    role_id=role_id,
                    category="conversation",
                    title="New recruiter reply",
                    message=description,
                    severity="info",
                    metadata={"sender_name": sender_name.strip()},
                )
            return messages[record.message_id]

    def documents_for_company_candidate(self, company_id: str, company_candidate_id: str, role_id: str | None = None) -> list[dict[str, Any]]:
        documents = []
        for document in self._load_documents().values():
            if document.get("company_id") != company_id or document.get("company_candidate_id") != company_candidate_id:
                continue
            role_ids = document.get("role_ids") or []
            if role_id and role_ids and role_id not in role_ids:
                continue
            documents.append(document)
        documents.sort(key=lambda item: item.get("uploaded_at", ""), reverse=True)
        return documents

    def ensure_linked_application(
        self,
        *,
        candidate_account_id: str,
        company_id: str,
        company_candidate_id: str,
        role_ids: list[str],
        candidate_profile: CandidateProfile,
    ) -> dict[str, Any]:
        with self._lock:
            applications = self._load_applications()
            existing = next(
                (
                    application
                    for application in applications.values()
                    if application.get("candidate_account_id") == candidate_account_id
                    and application.get("company_id") == company_id
                    and application.get("company_candidate_id") == company_candidate_id
                ),
                None,
            )
            documents = self.documents_for_company_candidate(company_id, company_candidate_id)
            verification_documents = [
                document
                for document in documents
                if document.get("document_type") in {"profile_photo", "skill_certificate", "education_certificate", "supporting_document"}
            ]
            verification = self.build_verification_summary(candidate_profile=candidate_profile, documents=verification_documents)
            merged_role_ids = sorted(set((existing or {}).get("role_ids", []) + list(role_ids)))
            application = {
                "application_id": (existing or {}).get("application_id") or secrets.token_urlsafe(10),
                "candidate_account_id": candidate_account_id,
                "company_id": company_id,
                "company_candidate_id": company_candidate_id,
                "role_ids": merged_role_ids,
                "resume_mode": (existing or {}).get("resume_mode") or "linked",
                "resume_version": int((existing or {}).get("resume_version") or candidate_profile.source_version or 1),
                "resume_document_id": (existing or {}).get("resume_document_id"),
                "profile_photo_document_id": next(
                    (document["document_id"] for document in verification_documents if document.get("document_type") == "profile_photo"),
                    (existing or {}).get("profile_photo_document_id"),
                ),
                "document_ids": sorted({*(existing or {}).get("document_ids", []), *[document["document_id"] for document in documents]}),
                "verification_summary": verification,
                "role_statuses": dict((existing or {}).get("role_statuses") or {}),
                "updated_at": _stamp(),
                "created_at": (existing or {}).get("created_at") or _stamp(),
                "linked_from_workspace": True,
            }
            applications[application["application_id"]] = application
            self._store.replace_namespace(self.applications_namespace, applications)
            return application

    def _builder_to_candidate_profile(
        self,
        *,
        candidate_account_id: str,
        company_id: str,
        company_candidate_id: str,
        role_ids: list[str],
        profile: CandidateProfileDraft,
        resume_version: int,
        source_name: str,
    ) -> CandidateProfile:
        skills = normalize_skills(profile.skills)
        education = [
            " | ".join(
                part
                for part in [entry.degree, entry.field, entry.institution, f"{entry.start_year or ''}-{entry.end_year or ''}".strip("-")]
                if part
            )
            for entry in profile.education
        ]
        experience_highlights = []
        years_experience = 0.0
        for entry in profile.experience:
            label = " | ".join(part for part in [entry.title, entry.company, f"{entry.start_date or ''} - {entry.end_date or 'Present'}"] if part)
            if label:
                experience_highlights.append(label)
            experience_highlights.extend(entry.highlights[:2])
            years_experience += 1.5
        projects = [
            " | ".join(part for part in [entry.name, entry.description, ", ".join(entry.technologies[:4])] if part)
            for entry in profile.projects
        ]
        certifications = [
            " | ".join(part for part in [entry.name, entry.issuer, entry.issued_on] if part)
            for entry in profile.certifications
        ]
        stream_path = workspace_source_dir(self.settings.resume_stream_dir, company_id) / f"{company_candidate_id}.json"
        return CandidateProfile(
            candidate_id=company_candidate_id,
            name=profile.full_name.strip(),
            email=profile.email.strip().lower(),
            phone=profile.phone,
            location=profile.location,
            current_title=profile.headline,
            summary=profile.summary,
            raw_text="\n".join(
                [
                    profile.summary,
                    "Skills: " + ", ".join(skills),
                    "Education: " + "; ".join(education),
                    "Experience: " + "; ".join(experience_highlights),
                    "Projects: " + "; ".join(projects),
                    "Certifications: " + "; ".join(certifications),
                ]
            ).strip(),
            skills=skills,
            skill_groups=group_skills(skills),
            certifications=certifications,
            education=education,
            experience_highlights=experience_highlights[:8],
            projects=projects[:6],
            years_experience=round(years_experience, 1),
            source_path=str(stream_path),
            source_name=source_name,
            source_version=resume_version,
            last_updated=_utc_now(),
        )

    def _uploaded_resume_to_candidate_profile(
        self,
        *,
        candidate_account_id: str,
        company_id: str,
        company_candidate_id: str,
        role_ids: list[str],
        file_name: str,
        raw_bytes: bytes,
        resume_version: int,
    ) -> CandidateProfile:
        parsed = parse_resume_document(file_name, raw_bytes, {"path": file_name})
        stream_path = workspace_source_dir(self.settings.resume_stream_dir, company_id) / f"{company_candidate_id}.json"
        return parsed.model_copy(
            update={
                "candidate_id": company_candidate_id,
                "source_path": str(stream_path),
                "source_name": _base_name(file_name),
                "source_version": resume_version,
                "last_updated": _utc_now(),
            }
        )

    def build_verification_summary(self, *, candidate_profile: CandidateProfile, documents: list[dict[str, Any]]) -> dict[str, Any]:
        skill_proof_documents = [
            document
            for document in documents
            if document.get("document_type") in {"skill_certificate", "supporting_document"}
        ]
        education_proof_documents = [
            document
            for document in documents
            if document.get("document_type") == "education_certificate"
        ]
        profile_photo_documents = [
            document
            for document in documents
            if document.get("document_type") == "profile_photo"
        ]
        skill_tags = {
            tag
            for document in skill_proof_documents
            for tag in normalize_skills(document.get("tags") or [])
        }
        education_tags = {
            term
            for document in education_proof_documents
            for term in _document_terms(document)
        }
        verified_skills = [skill for skill in candidate_profile.skills if skill in skill_tags]
        unverified_skills = [skill for skill in candidate_profile.skills if skill not in skill_tags]
        education_claims = candidate_profile.education[:]
        education_verified = [claim for claim in education_claims if any(tag.lower() in claim.lower() for tag in education_tags)]
        education_pending = [claim for claim in education_claims if claim not in education_verified]
        certification_claims = [claim for claim in candidate_profile.certifications if claim.strip()]
        certification_tags = {
            term
            for document in documents
            if document.get("document_type") in {"skill_certificate", "supporting_document", "education_certificate"}
            for term in _document_terms(document)
        }
        certifications_verified = [
            claim for claim in certification_claims if any(tag.lower() in claim.lower() for tag in certification_tags)
        ]
        certifications_pending = [claim for claim in certification_claims if claim not in certifications_verified]
        skill_ratio = len(verified_skills) / max(len(candidate_profile.skills), 1) if candidate_profile.skills else 0.0
        education_ratio = len(education_verified) / len(education_claims) if education_claims else 0.0
        certification_ratio = len(certifications_verified) / len(certification_claims) if certification_claims else 0.0
        profile_photo_uploaded = bool(profile_photo_documents)
        all_claim_tokens = {item.lower() for item in (candidate_profile.skills + certification_claims)}
        all_claim_tokens.update(claim.lower() for claim in education_claims)
        unmatched_documents = []
        for document in documents:
            doc_tags = _document_terms(document)
            if doc_tags and not any(tag in claim or claim in tag for tag in doc_tags for claim in all_claim_tokens):
                unmatched_documents.append(document.get("title") or document.get("file_name") or "Supporting document")
        risk_flags: list[str] = []
        if not documents:
            risk_flags.append("No supporting documents have been attached to validate resume claims.")
        if not profile_photo_uploaded:
            risk_flags.append("Profile photo is missing.")
        if unverified_skills:
            risk_flags.append("Some claimed skills still lack supporting proof.")
        if education_pending:
            risk_flags.append("Education claims are pending verification.")
        if certifications_pending:
            risk_flags.append("Certification claims are pending verification.")
        if unmatched_documents:
            risk_flags.append("Some uploaded documents do not match any visible resume claim.")
        checks = [
            {
                "label": "Profile photo",
                "status": "verified" if profile_photo_uploaded else "missing",
                "detail": "A profile image is attached." if profile_photo_uploaded else "No profile image uploaded yet.",
            },
            {
                "label": "Skill proof",
                "status": "verified" if not unverified_skills and candidate_profile.skills else "partial" if verified_skills else "missing",
                "detail": f"{len(verified_skills)} of {len(candidate_profile.skills)} claimed skills have document support." if candidate_profile.skills else "No explicit skill claims were extracted.",
            },
            {
                "label": "Education proof",
                "status": "verified" if not education_pending and education_claims else "partial" if education_verified else "missing",
                "detail": f"{len(education_verified)} of {len(education_claims)} education claims are backed by documents." if education_claims else "No formal education claim was extracted.",
            },
            {
                "label": "Certificate proof",
                "status": "verified" if not certifications_pending and certification_claims else "partial" if certifications_verified else "missing",
                "detail": f"{len(certifications_verified)} of {len(certification_claims)} certifications are backed by evidence." if certification_claims else "No explicit certification claim was extracted.",
            },
        ]
        return {
            "verified_skills": verified_skills[:8],
            "unverified_skills": unverified_skills[:8],
            "verified_education": education_verified[:4],
            "pending_education": education_pending[:4],
            "verified_certifications": certifications_verified[:4],
            "pending_certifications": certifications_pending[:4],
            "document_count": len(documents),
            "skill_proof_documents_count": len(skill_proof_documents),
            "education_proof_documents_count": len(education_proof_documents),
            "profile_photo_documents_count": len(profile_photo_documents),
            "profile_photo_uploaded": profile_photo_uploaded,
            "checks": checks,
            "risk_flags": risk_flags[:6],
            "unmatched_documents": unmatched_documents[:6],
            "verification_score": round(
                skill_ratio * 0.45 + education_ratio * 0.2 + certification_ratio * 0.2 + (0.15 if profile_photo_uploaded else 0.0),
                4,
            ),
        }

    def upsert_application(
        self,
        *,
        candidate_account_id: str,
        company_id: str,
        role_ids: list[str],
        resume_mode: str,
        profile_draft: CandidateProfileDraft | None,
        resume_document: dict[str, Any] | None,
    ) -> dict[str, Any]:
        with self._lock:
            if not role_ids:
                raise ValueError("Choose at least one role before submitting.")
            documents = self._load_documents()
            applications = self._load_applications()
            relevant_documents = [
                document
                for document in documents.values()
                if document.get("candidate_account_id") == candidate_account_id
                and document.get("company_id") == company_id
                and document.get("document_type") != "resume"
            ]
            verification_documents = [
                document
                for document in relevant_documents
                if document.get("document_type") in {"profile_photo", "skill_certificate", "education_certificate", "supporting_document"}
            ]

            existing = next(
                (
                    application
                    for application in applications.values()
                    if application.get("candidate_account_id") == candidate_account_id and application.get("company_id") == company_id
                ),
                None,
            )
            company_candidate_id = str((existing or {}).get("company_candidate_id") or scoped_entity_id(company_id, f"candidate-{candidate_account_id}"))
            resume_version = int(existing.get("resume_version", 0)) + 1 if existing else 1
            application_id = existing.get("application_id") if existing else secrets.token_urlsafe(10)

            if resume_mode == "builder":
                if not profile_draft:
                    raise ValueError("Complete the structured resume before submitting.")
                candidate_profile = self._builder_to_candidate_profile(
                    candidate_account_id=candidate_account_id,
                    company_id=company_id,
                    company_candidate_id=company_candidate_id,
                    role_ids=role_ids,
                    profile=profile_draft,
                    resume_version=resume_version,
                    source_name=f"{candidate_account_id}-builder-v{resume_version}.json",
                )
            else:
                if not resume_document:
                    raise ValueError("Upload a resume before submitting.")
                raw_bytes = Path(resume_document["path"]).read_bytes()
                candidate_profile = self._uploaded_resume_to_candidate_profile(
                    candidate_account_id=candidate_account_id,
                    company_id=company_id,
                    company_candidate_id=company_candidate_id,
                    role_ids=role_ids,
                    file_name=resume_document["file_name"],
                    raw_bytes=raw_bytes,
                    resume_version=resume_version,
                )

            verification = self.build_verification_summary(candidate_profile=candidate_profile, documents=verification_documents)
            enriched = candidate_profile.model_copy(
                update={
                    "source_path": str(workspace_source_dir(self.settings.resume_stream_dir, company_id) / f"{company_candidate_id}.json"),
                    "source_name": candidate_profile.source_name or f"{candidate_account_id}-resume-v{resume_version}.json",
                    "source_version": resume_version,
                    "last_updated": _utc_now(),
                    "source_mode": "candidate_portal",
                    "candidate_account_id": candidate_account_id,
                    "role_ids": sorted(set(role_ids)),
                    "verification_summary": verification,
                }
            )
            stream_path = Path(enriched.source_path)
            stream_path.parent.mkdir(parents=True, exist_ok=True)
            stream_path.write_text(enriched.model_dump_json(indent=2), encoding="utf-8")

            if resume_document:
                documents[resume_document["document_id"]]["company_candidate_id"] = company_candidate_id
                documents[resume_document["document_id"]]["application_id"] = application_id
                documents[resume_document["document_id"]]["role_ids"] = sorted(set(role_ids))

            linked_document_ids = []
            for document in verification_documents:
                document["company_candidate_id"] = company_candidate_id
                document["application_id"] = application_id
                document["role_ids"] = sorted(set(role_ids))
                linked_document_ids.append(document["document_id"])
            self._store.replace_namespace(self.documents_namespace, documents)

            application = {
                "application_id": application_id,
                "candidate_account_id": candidate_account_id,
                "company_id": company_id,
                "company_candidate_id": company_candidate_id,
                "role_ids": sorted(set(role_ids)),
                "resume_mode": resume_mode,
                "resume_version": resume_version,
                "resume_document_id": resume_document["document_id"] if resume_document else None,
                "profile_photo_document_id": next(
                    (document["document_id"] for document in verification_documents if document.get("document_type") == "profile_photo"),
                    (existing or {}).get("profile_photo_document_id"),
                ),
                "document_ids": sorted(set(linked_document_ids + ([resume_document["document_id"]] if resume_document else []))),
                "verification_summary": verification,
                "role_statuses": dict((existing or {}).get("role_statuses") or {}),
                "updated_at": _stamp(),
                "created_at": existing.get("created_at", _stamp()) if existing else _stamp(),
            }
            applications[application_id] = application
            self._store.replace_namespace(self.applications_namespace, applications)
            self._append_timeline_event(
                application_id=application_id,
                candidate_account_id=candidate_account_id,
                company_id=company_id,
                company_candidate_id=company_candidate_id,
                role_ids=role_ids,
                event_type="application_submitted",
                title="Application submitted",
                description=f"Application saved for {len(role_ids)} role(s).",
                metadata={"resume_mode": resume_mode, "resume_version": resume_version},
            )
            self._append_notification(
                audience_id=candidate_account_id,
                workspace_id=company_id,
                application_id=application_id,
                candidate_id=company_candidate_id,
                role_id=role_ids[0] if role_ids else None,
                category="application",
                title="Application updated",
                message=f"Your application for {company_id.replace('-', ' ').title()} was submitted and is now ready for recruiter review.",
                severity="success",
                metadata={"role_ids": role_ids, "resume_version": resume_version},
            )
            return application

    def candidate_applications(self, candidate_account_id: str) -> list[dict[str, Any]]:
        applications = [
            application
            for application in self._load_applications().values()
            if application.get("candidate_account_id") == candidate_account_id
        ]
        applications.sort(key=lambda item: item.get("updated_at", ""), reverse=True)
        return applications

    def applications_for_company(self, company_id: str) -> list[dict[str, Any]]:
        applications = [
            application
            for application in self._load_applications().values()
            if application.get("company_id") == company_id
        ]
        applications.sort(key=lambda item: item.get("updated_at", ""), reverse=True)
        return applications

    def candidate_application(self, candidate_account_id: str, company_id: str) -> dict[str, Any] | None:
        return next(
            (
                application
                for application in self.candidate_applications(candidate_account_id)
                if application.get("company_id") == company_id
            ),
            None,
        )

    def application_by_company_candidate(self, company_id: str, company_candidate_id: str) -> dict[str, Any] | None:
        return next(
            (
                application
                for application in self._load_applications().values()
                if application.get("company_id") == company_id and application.get("company_candidate_id") == company_candidate_id
            ),
            None,
        )

    def record_recruiter_feedback(
        self,
        *,
        company_id: str,
        company_candidate_id: str,
        role_id: str | None,
        label: str,
        notes: str,
        recruiter: str | None,
    ) -> dict[str, Any] | None:
        with self._lock:
            application = self.application_by_company_candidate(company_id, company_candidate_id)
            if not application:
                return None
            role_statuses = dict(application.get("role_statuses") or {})
            target_role = role_id or (application.get("role_ids") or [None])[0]
            if target_role:
                status_record = dict(role_statuses.get(target_role) or {})
                status_record.update(
                    {
                        "status": label,
                        "updated_at": _stamp(),
                        "recruiter": recruiter,
                        "notes": notes,
                    }
                )
                role_statuses[target_role] = status_record
            application["role_statuses"] = role_statuses
            application["updated_at"] = _stamp()
            applications = self._load_applications()
            applications[application["application_id"]] = application
            self._store.replace_namespace(self.applications_namespace, applications)
            title = label.replace("_", " ").title()
            self._append_timeline_event(
                application_id=application["application_id"],
                candidate_account_id=application["candidate_account_id"],
                company_id=company_id,
                company_candidate_id=company_candidate_id,
                role_ids=[target_role] if target_role else application.get("role_ids", []),
                event_type="recruiter_feedback",
                title=f"Recruiter update: {title}",
                description=notes or "The recruiter updated your application.",
                metadata={"label": label, "recruiter": recruiter},
            )
            self._append_notification(
                audience_id=application["candidate_account_id"],
                workspace_id=company_id,
                application_id=application["application_id"],
                candidate_id=company_candidate_id,
                role_id=target_role,
                category="recruiter_feedback",
                title=f"Recruiter update: {title}",
                message=notes or f"A recruiter updated your application to {title.lower()}.",
                severity="info" if label not in {"reject", "rejected"} else "warning",
                metadata={"label": label, "recruiter": recruiter},
            )
            return application

    def record_verification_review(
        self,
        *,
        company_id: str,
        company_candidate_id: str,
        role_id: str | None,
        decision: str,
        notes: str,
        reviewer: str | None,
    ) -> dict[str, Any] | None:
        with self._lock:
            application = self.application_by_company_candidate(company_id, company_candidate_id)
            if not application:
                return None
            role_statuses = dict(application.get("role_statuses") or {})
            target_role = role_id or (application.get("role_ids") or [None])[0]
            if target_role:
                status_record = dict(role_statuses.get(target_role) or {})
                status_record.update(
                    {
                        "verification_status": decision,
                        "verification_updated_at": _stamp(),
                        "verification_reviewer": reviewer,
                        "verification_notes": notes,
                    }
                )
                role_statuses[target_role] = status_record
            application["role_statuses"] = role_statuses
            application["updated_at"] = _stamp()
            applications = self._load_applications()
            applications[application["application_id"]] = application
            self._store.replace_namespace(self.applications_namespace, applications)
            title = "Documents verified" if decision == "verified" else "Verification rejected"
            description = notes or ("Your documents were verified by the hiring team." if decision == "verified" else "The hiring team requested changes to your uploaded proof.")
            self._append_timeline_event(
                application_id=application["application_id"],
                candidate_account_id=application["candidate_account_id"],
                company_id=company_id,
                company_candidate_id=company_candidate_id,
                role_ids=[target_role] if target_role else application.get("role_ids", []),
                event_type="verification_review",
                title=title,
                description=description,
                metadata={"decision": decision, "reviewer": reviewer},
            )
            self._append_notification(
                audience_id=application["candidate_account_id"],
                workspace_id=company_id,
                application_id=application["application_id"],
                candidate_id=company_candidate_id,
                role_id=target_role,
                category="verification",
                title=title,
                message=description,
                severity="success" if decision == "verified" else "warning",
                metadata={"decision": decision, "reviewer": reviewer},
            )
            return application
