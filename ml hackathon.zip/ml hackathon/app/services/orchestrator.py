from __future__ import annotations

from app.models import CandidateProfile, FeedbackEntry, JobProfile, RankingSnapshot
from app.services.insights import build_candidate_insight, build_job_insights, compare_candidates
from app.services.qa import answer_recruiter_question
from app.services.ranking.engine import RankingService
from app.services.retrieval import DocumentRetriever
from app.services.state.store import RuntimeState
from app.services.workspaces import belongs_to_workspace, infer_workspace_from_entity_id


class ScreeningOrchestrator:
    def __init__(self, state: RuntimeState, retriever: DocumentRetriever, ranking_service: RankingService) -> None:
        self.state = state
        self.retriever = retriever
        self.ranking_service = ranking_service

    def _compute_snapshot(self, job: JobProfile) -> RankingSnapshot:
        workspace_id = infer_workspace_from_entity_id(job.job_id)
        previous_snapshot = self.state.get_ranking_snapshot(job.job_id)
        candidates = [
            candidate
            for candidate in self.state.list_candidates()
            if belongs_to_workspace(entity_id=candidate.candidate_id, source_path=candidate.source_path, workspace_id=workspace_id)
        ]
        feedback_entries = [
            entry
            for entry in self.state.get_feedback_for_job(job.job_id)
            if belongs_to_workspace(entity_id=entry.candidate_id or entry.job_id, source_path=entry.source_path, workspace_id=workspace_id)
        ]
        snapshot = self.ranking_service.rank_job(
            job=job,
            candidates=candidates,
            feedback_entries=feedback_entries,
            retrieval_hits=self.retriever.query_for_job(job, k=self.ranking_service.settings.retrieval_top_k, workspace_id=workspace_id),
            previous_snapshot=previous_snapshot,
            source_revision=self.state.revision,
        )
        return self.state.save_ranking_snapshot(snapshot)

    def refresh_job(self, job_id: str) -> RankingSnapshot | None:
        job = self.state.get_job(job_id)
        if not job:
            return None
        return self._compute_snapshot(job)

    def refresh_all_rankings(self) -> None:
        for job in self.state.list_jobs():
            self._compute_snapshot(job)

    def handle_candidate_upsert(self, candidate: CandidateProfile) -> CandidateProfile:
        enriched = self.state.upsert_candidate(candidate)
        return enriched

    def handle_candidate_remove(self, candidate_id: str) -> None:
        self.state.remove_candidate(candidate_id)

    def handle_job_upsert(self, job: JobProfile) -> JobProfile:
        enriched = self.state.upsert_job(job)
        return enriched

    def handle_job_remove(self, job_id: str) -> None:
        self.state.remove_job(job_id)

    def handle_feedback_replace(self, source_path: str, entries: list[FeedbackEntry]) -> list[FeedbackEntry]:
        enriched = self.state.replace_feedback_from_source(source_path, entries)
        return enriched

    def handle_feedback_remove(self, source_path: str) -> None:
        self.state.remove_feedback_source(source_path)

    def get_rankings(self, job_id: str) -> RankingSnapshot | None:
        if self.state.is_snapshot_stale(job_id):
            return self.refresh_job(job_id)
        return self.state.get_ranking_snapshot(job_id)

    def _workspace_feedback(self, job_id: str) -> list[FeedbackEntry]:
        workspace_id = infer_workspace_from_entity_id(job_id)
        return [
            entry
            for entry in self.state.get_feedback_for_job(job_id)
            if belongs_to_workspace(
                entity_id=entry.candidate_id or entry.job_id,
                source_path=entry.source_path,
                workspace_id=workspace_id,
            )
        ]

    def _workspace_events(self, job_id: str) -> list[dict]:
        workspace_id = infer_workspace_from_entity_id(job_id)
        return [
            event.model_dump(mode="json")
            for event in self.state.recent_events("recruiter")
            if belongs_to_workspace(entity_id=event.entity_id, source_path=event.entity_id, workspace_id=workspace_id)
        ]

    def job_insights(self, job_id: str) -> dict | None:
        job = self.state.get_job(job_id)
        snapshot = self.get_rankings(job_id)
        if not job or not snapshot:
            return None
        return build_job_insights(
            job=job,
            snapshot=snapshot,
            feedback_entries=self._workspace_feedback(job_id),
            recent_events=self._workspace_events(job_id),
        )

    def candidate_insight(self, job_id: str, candidate_id: str) -> dict | None:
        job = self.state.get_job(job_id)
        snapshot = self.get_rankings(job_id)
        if not job or not snapshot:
            return None
        ranking = next((item for item in snapshot.rankings if item.candidate.candidate_id == candidate_id), None)
        if not ranking:
            return None
        feedback = [
            entry
            for entry in self._workspace_feedback(job_id)
            if entry.candidate_id == candidate_id
        ]
        return build_candidate_insight(job, ranking, feedback)

    def compare(self, job_id: str, left_candidate_id: str, right_candidate_id: str) -> dict | None:
        job = self.state.get_job(job_id)
        snapshot = self.get_rankings(job_id)
        if not job or not snapshot:
            return None
        left = next((item for item in snapshot.rankings if item.candidate.candidate_id == left_candidate_id), None)
        right = next((item for item in snapshot.rankings if item.candidate.candidate_id == right_candidate_id), None)
        if not left or not right:
            return None
        return compare_candidates(job, left, right)

    def answer_question(self, job_id: str, question: str):
        job = self.state.get_job(job_id)
        snapshot = self.get_rankings(job_id)
        if not job or not snapshot:
            return None
        insights = build_job_insights(
            job=job,
            snapshot=snapshot,
            feedback_entries=self._workspace_feedback(job_id),
            recent_events=self._workspace_events(job_id),
        )
        return answer_recruiter_question(question, job, snapshot, insights)
