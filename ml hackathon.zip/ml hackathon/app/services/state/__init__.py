"""In-memory state store."""
