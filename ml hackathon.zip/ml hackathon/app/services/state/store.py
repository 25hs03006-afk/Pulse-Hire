from __future__ import annotations

import hashlib
from collections import deque
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock
from typing import Any

from app.models import ActivityEvent, CandidateProfile, FeedbackEntry, JobProfile, PipelineStatus, RankingSnapshot


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _snapshot_signature(snapshot: RankingSnapshot) -> list[tuple[str, int, float]]:
    return [
        (
            ranking.candidate.candidate_id,
            ranking.rank,
            ranking.breakdown.total_score,
        )
        for ranking in snapshot.rankings
    ]


def _checksum(parts: list[str]) -> str:
    payload = "||".join(part.strip() for part in parts if part and part.strip())
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()


def _profile_completeness(candidate: CandidateProfile) -> float:
    signals = [
        bool(candidate.summary.strip()),
        bool(candidate.current_title),
        bool(candidate.location),
        bool(candidate.email),
        bool(candidate.phone),
        bool(candidate.skills),
        bool(candidate.education),
        bool(candidate.experience_highlights),
        bool(candidate.projects),
        candidate.years_experience > 0,
    ]
    return round(sum(1 for item in signals if item) / len(signals), 4)


def _document_label(path: str | None, fallback: str) -> str:
    if not path:
        return fallback
    return Path(path).name or fallback


class RuntimeState:
    def __init__(self) -> None:
        self._lock = RLock()
        self._candidates: dict[str, CandidateProfile] = {}
        self._jobs: dict[str, JobProfile] = {}
        self._feedback: dict[str, FeedbackEntry] = {}
        self._feedback_ids_by_source: dict[str, set[str]] = {}
        self._rankings: dict[str, RankingSnapshot] = {}
        self._events: deque[ActivityEvent] = deque(maxlen=160)
        self._pipeline = PipelineStatus()
        self._revision = 0
        self._documents: dict[str, dict[str, Any]] = {}
        self._failures: deque[dict[str, Any]] = deque(maxlen=24)

    def _bump_revision(self) -> None:
        self._revision += 1
        self._pipeline.last_update = _utc_now()

    def _record_document(
        self,
        *,
        path: str,
        entity_kind: str,
        entity_id: str,
        label: str,
        checksum: str | None,
        version: int,
        status: str = "ready",
        details: dict[str, Any] | None = None,
    ) -> None:
        self._documents[path] = {
            "path": path,
            "entity_kind": entity_kind,
            "entity_id": entity_id,
            "label": label,
            "checksum": checksum,
            "version": version,
            "status": status,
            "updated_at": _utc_now().isoformat(),
            "details": details or {},
        }

    def _drop_document(self, path: str | None) -> None:
        if path:
            self._documents.pop(path, None)

    def _detect_duplicates(self, candidate: CandidateProfile) -> tuple[str | None, list[str]]:
        duplicates: list[str] = []
        for existing in self._candidates.values():
            if existing.candidate_id == candidate.candidate_id:
                continue
            same_email = bool(candidate.email and existing.email and candidate.email.lower() == existing.email.lower())
            same_phone = bool(candidate.phone and existing.phone and candidate.phone == existing.phone)
            same_identity = (
                candidate.name.strip().lower() == existing.name.strip().lower()
                and (candidate.location or "").strip().lower() == (existing.location or "").strip().lower()
            )
            if same_email or same_phone or same_identity:
                duplicates.append(existing.candidate_id)
        return (duplicates[0] if duplicates else None, sorted(set(duplicates)))

    def set_pipeline_status(self, state: str, details: dict[str, Any] | None = None) -> None:
        with self._lock:
            self._pipeline.state = state
            self._pipeline.last_update = _utc_now()
            if details:
                self._pipeline.details.update(details)

    def add_event(
        self,
        event_type: str,
        message: str,
        entity_id: str | None = None,
        entity_kind: str | None = None,
        *,
        audience: str = "recruiter",
        severity: str = "info",
        details: dict[str, Any] | None = None,
    ) -> None:
        with self._lock:
            self._events.appendleft(
                ActivityEvent(
                    event_type=event_type,
                    message=message,
                    entity_id=entity_id,
                    entity_kind=entity_kind,
                    audience=audience,
                    severity=severity,
                    details=details or {},
                )
            )
            self._pipeline.last_update = _utc_now()

    def record_document_failure(self, entity_kind: str, source_path: str, error: str) -> None:
        with self._lock:
            record = {
                "entity_kind": entity_kind,
                "path": source_path,
                "error": error,
                "timestamp": _utc_now().isoformat(),
            }
            self._failures.appendleft(record)
            self._record_document(
                path=source_path,
                entity_kind=entity_kind,
                entity_id=source_path,
                label=_document_label(source_path, "Unparsed document"),
                checksum=None,
                version=1,
                status="error",
                details={"error": error},
            )
            self._pipeline.details["last_failure"] = record
            self._bump_revision()
            self.add_event(
                event_type="document_error",
                message=f"{entity_kind.title()} ingestion failed for {_document_label(source_path, 'document')}.",
                entity_id=source_path,
                entity_kind=entity_kind,
                audience="system",
                severity="error",
                details={"error": error},
            )

    @property
    def revision(self) -> int:
        with self._lock:
            return self._revision

    def upsert_candidate(self, candidate: CandidateProfile) -> CandidateProfile:
        with self._lock:
            previous = self._candidates.get(candidate.candidate_id)
            checksum = _checksum(
                [
                    candidate.name,
                    candidate.summary,
                    candidate.raw_text,
                    " ".join(candidate.skills),
                    " ".join(candidate.education),
                    candidate.current_title or "",
                ]
            )
            version = 1
            if previous:
                version = previous.source_version if previous.source_checksum == checksum else previous.source_version + 1

            duplicate_of, duplicate_candidates = self._detect_duplicates(candidate)
            enriched = candidate.model_copy(
                update={
                    "source_name": _document_label(candidate.source_path, candidate.name),
                    "source_checksum": checksum,
                    "source_version": version,
                    "completeness_score": _profile_completeness(candidate),
                    "duplicate_of": duplicate_of,
                    "duplicate_candidates": duplicate_candidates,
                }
            )
            self._candidates[enriched.candidate_id] = enriched
            self._record_document(
                path=enriched.source_path,
                entity_kind="candidate",
                entity_id=enriched.candidate_id,
                label=enriched.name,
                checksum=checksum,
                version=version,
                details={"completeness_score": enriched.completeness_score, "duplicate_of": duplicate_of},
            )
            self._bump_revision()
            action = "updated" if previous and previous.source_checksum != checksum else "added"
            self.add_event(
                event_type="candidate_upserted",
                message=f"Candidate {action}: {enriched.name}.",
                entity_id=enriched.candidate_id,
                entity_kind="candidate",
                details={
                    "version": enriched.source_version,
                    "completeness_score": enriched.completeness_score,
                    "duplicate_of": duplicate_of,
                },
            )
            if duplicate_of:
                self.add_event(
                    event_type="candidate_duplicate_flagged",
                    message=f"Potential duplicate detected for {enriched.name}.",
                    entity_id=enriched.candidate_id,
                    entity_kind="candidate",
                    audience="system",
                    severity="warning",
                    details={"duplicate_of": duplicate_of, "related_candidates": duplicate_candidates},
                )
            return deepcopy(enriched)

    def remove_candidate(self, candidate_id: str) -> None:
        with self._lock:
            removed = self._candidates.pop(candidate_id, None)
            if not removed:
                return
            self._drop_document(removed.source_path)
            self._bump_revision()
            self.add_event(
                event_type="candidate_removed",
                message=f"Candidate profile removed: {removed.name}.",
                entity_id=candidate_id,
                entity_kind="candidate",
                audience="system",
            )

    def upsert_job(self, job: JobProfile) -> JobProfile:
        with self._lock:
            previous = self._jobs.get(job.job_id)
            checksum = _checksum(
                [
                    job.title,
                    job.description,
                    " ".join(job.must_have_skills),
                    " ".join(job.nice_to_have_skills),
                    " ".join(job.keywords),
                ]
            )
            version = 1
            if previous:
                version = previous.source_version if previous.source_checksum == checksum else previous.source_version + 1
            enriched = job.model_copy(
                update={
                    "source_name": _document_label(job.source_path, job.title),
                    "source_checksum": checksum,
                    "source_version": version,
                }
            )
            self._jobs[enriched.job_id] = enriched
            self._record_document(
                path=enriched.source_path,
                entity_kind="job",
                entity_id=enriched.job_id,
                label=enriched.title,
                checksum=checksum,
                version=version,
                details={"must_have_skills": len(enriched.must_have_skills)},
            )
            self._bump_revision()
            action = "updated" if previous and previous.source_checksum != checksum else "added"
            self.add_event(
                event_type="job_upserted",
                message=f"Role {action}: {enriched.title}.",
                entity_id=enriched.job_id,
                entity_kind="job",
                details={"version": enriched.source_version, "must_have_skills": enriched.must_have_skills},
            )
            return deepcopy(enriched)

    def remove_job(self, job_id: str) -> None:
        with self._lock:
            removed = self._jobs.pop(job_id, None)
            self._rankings.pop(job_id, None)
            if not removed:
                return
            self._drop_document(removed.source_path)
            self._bump_revision()
            self.add_event(
                event_type="job_removed",
                message=f"Job brief removed: {removed.title}.",
                entity_id=job_id,
                entity_kind="job",
                audience="system",
            )

    def replace_feedback_from_source(self, source_path: str, entries: list[FeedbackEntry]) -> list[FeedbackEntry]:
        with self._lock:
            previous_ids = self._feedback_ids_by_source.get(source_path, set())
            previous_version = int(self._documents.get(source_path, {}).get("version") or 0)
            for feedback_id in previous_ids:
                self._feedback.pop(feedback_id, None)
            self._feedback_ids_by_source[source_path] = set()
            version = previous_version + 1 if previous_version else 1
            enriched_entries: list[FeedbackEntry] = []
            for entry in entries:
                enriched = entry.model_copy(
                    update={
                        "source_name": _document_label(source_path, "Feedback PDF"),
                        "source_version": version,
                    }
                )
                self._feedback[enriched.feedback_id] = enriched
                self._feedback_ids_by_source[source_path].add(enriched.feedback_id)
                enriched_entries.append(enriched)
            self._record_document(
                path=source_path,
                entity_kind="feedback",
                entity_id=source_path,
                label=_document_label(source_path, "Feedback PDF"),
                checksum=_checksum([entry.feedback_id for entry in enriched_entries] + [entry.notes for entry in enriched_entries]),
                version=version,
                details={"entries": len(enriched_entries)},
            )
            self._bump_revision()
            self.add_event(
                event_type="feedback_upserted",
                message=f"Recruiter review added for {len(enriched_entries)} candidate signal(s).",
                entity_id=source_path,
                entity_kind="feedback",
                details={"entries": len(enriched_entries), "version": version},
            )
            return [deepcopy(item) for item in enriched_entries]

    def remove_feedback_source(self, source_path: str) -> None:
        with self._lock:
            removed_ids = self._feedback_ids_by_source.pop(source_path, set())
            for feedback_id in removed_ids:
                self._feedback.pop(feedback_id, None)
            self._drop_document(source_path)
            self._bump_revision()
            self.add_event(
                event_type="feedback_removed",
                message=f"Feedback source removed: {_document_label(source_path, 'feedback')}.",
                entity_id=source_path,
                entity_kind="feedback",
                audience="system",
            )

    def get_candidate(self, candidate_id: str) -> CandidateProfile | None:
        with self._lock:
            candidate = self._candidates.get(candidate_id)
            return deepcopy(candidate) if candidate else None

    def get_job(self, job_id: str) -> JobProfile | None:
        with self._lock:
            job = self._jobs.get(job_id)
            return deepcopy(job) if job else None

    def list_candidates(self) -> list[CandidateProfile]:
        with self._lock:
            return sorted((deepcopy(item) for item in self._candidates.values()), key=lambda item: item.name)

    def list_jobs(self) -> list[JobProfile]:
        with self._lock:
            return sorted((deepcopy(item) for item in self._jobs.values()), key=lambda item: item.title)

    def list_feedback(self) -> list[FeedbackEntry]:
        with self._lock:
            return sorted(
                (deepcopy(item) for item in self._feedback.values()),
                key=lambda item: item.created_at,
                reverse=True,
            )

    def get_feedback(self, feedback_id: str) -> FeedbackEntry | None:
        with self._lock:
            entry = self._feedback.get(feedback_id)
            return deepcopy(entry) if entry else None

    def get_feedback_entries_for_source(self, source_path: str) -> list[FeedbackEntry]:
        with self._lock:
            entries = [item for item in self._feedback.values() if item.source_path == source_path]
            return sorted((deepcopy(item) for item in entries), key=lambda item: item.created_at, reverse=True)

    def get_feedback_for_job(self, job_id: str) -> list[FeedbackEntry]:
        with self._lock:
            relevant = [item for item in self._feedback.values() if not item.job_id or item.job_id == job_id]
            return sorted((deepcopy(item) for item in relevant), key=lambda item: item.created_at, reverse=True)

    def save_ranking_snapshot(self, snapshot: RankingSnapshot) -> RankingSnapshot:
        with self._lock:
            previous = self._rankings.get(snapshot.job_id)
            changed = previous is None or _snapshot_signature(previous) != _snapshot_signature(snapshot)
            self._rankings[snapshot.job_id] = deepcopy(snapshot)
            if changed and snapshot.rankings:
                leader = snapshot.rankings[0].candidate.name
                movers = [
                    ranking.candidate.name
                    for ranking in snapshot.rankings
                    if ranking.rank_delta or abs(ranking.score_delta) >= 0.01
                ][:3]
                self.add_event(
                    event_type="ranking_refreshed",
                    message=f"Ranking updated for job {snapshot.job_id}.",
                    entity_id=snapshot.job_id,
                    entity_kind="job",
                    audience="system",
                    details={
                        "leader": leader,
                        "movers": movers,
                        "source_revision": snapshot.source_revision,
                    },
                )
            return deepcopy(snapshot)

    def get_ranking_snapshot(self, job_id: str) -> RankingSnapshot | None:
        with self._lock:
            snapshot = self._rankings.get(job_id)
            return deepcopy(snapshot) if snapshot else None

    def is_snapshot_stale(self, job_id: str) -> bool:
        with self._lock:
            snapshot = self._rankings.get(job_id)
            if snapshot is None:
                return True
            return snapshot.source_revision < self._revision

    def recent_events(self, audience: str | None = None) -> list[ActivityEvent]:
        with self._lock:
            events = list(self._events)
            if audience:
                events = [event for event in events if event.audience == audience]
            return [deepcopy(event) for event in events]

    def document_registry(self) -> list[dict[str, Any]]:
        with self._lock:
            documents = [deepcopy(item) for item in self._documents.values()]
            return sorted(documents, key=lambda item: item.get("updated_at", ""), reverse=True)

    def recent_failures(self) -> list[dict[str, Any]]:
        with self._lock:
            return [deepcopy(item) for item in self._failures]

    def quality_metrics(self) -> dict[str, Any]:
        with self._lock:
            candidates = list(self._candidates.values())
            completeness = [candidate.completeness_score for candidate in candidates]
            duplicate_count = sum(1 for candidate in candidates if candidate.duplicate_of)
            return {
                "revision": self._revision,
                "avg_profile_completeness": round(sum(completeness) / len(completeness), 4) if completeness else 0.0,
                "duplicate_profiles": duplicate_count,
                "documents_with_errors": len([item for item in self._documents.values() if item.get("status") == "error"]),
            }

    def summary(self) -> dict[str, Any]:
        with self._lock:
            return {
                "pipeline": self._pipeline.model_dump(mode="json"),
                "counts": {
                    "candidates": len(self._candidates),
                    "jobs": len(self._jobs),
                    "feedback_entries": len(self._feedback),
                    "ranked_jobs": len(self._rankings),
                    "documents": len(self._documents),
                },
                "quality": self.quality_metrics(),
                "documents": self.document_registry()[:20],
                "recent_events": [event.model_dump(mode="json") for event in list(self._events)[:12]],
                "recent_failures": self.recent_failures()[:5],
            }
