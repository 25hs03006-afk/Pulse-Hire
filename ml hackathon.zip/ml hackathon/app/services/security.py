from __future__ import annotations

import hashlib
import secrets

try:  # pragma: no cover - optional dependency path
    from argon2 import PasswordHasher
    from argon2.exceptions import VerifyMismatchError
except Exception:  # pragma: no cover - fallback path
    PasswordHasher = None
    VerifyMismatchError = Exception

PBKDF2_ITERATIONS = 200_000
_ARGON2 = PasswordHasher() if PasswordHasher is not None else None


def legacy_hash_password(password: str, salt: str) -> str:
    return hashlib.sha256(f"{salt}::{password}".encode("utf-8")).hexdigest()


def hash_password(password: str, salt: str | None = None) -> str:
    if _ARGON2 is not None:
        return _ARGON2.hash(password)
    effective_salt = salt or secrets.token_hex(12)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), effective_salt.encode("utf-8"), PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${effective_salt}${digest.hex()}"


def verify_password(password: str, salt: str | None, stored_hash: str) -> bool:
    if stored_hash.startswith("$argon2") and _ARGON2 is not None:
        try:
            return bool(_ARGON2.verify(stored_hash, password))
        except VerifyMismatchError:
            return False
        except Exception:
            return False
    if stored_hash.startswith("pbkdf2_sha256$"):
        try:
            _, iterations, stored_salt, stored_digest = stored_hash.split("$", 3)
            candidate = hashlib.pbkdf2_hmac(
                "sha256",
                password.encode("utf-8"),
                stored_salt.encode("utf-8"),
                int(iterations),
            ).hex()
            return secrets.compare_digest(candidate, stored_digest)
        except Exception:
            return False
    if salt is None:
        return False
    return secrets.compare_digest(legacy_hash_password(password, salt), stored_hash)


def password_needs_rehash(stored_hash: str) -> bool:
    if stored_hash.startswith("$argon2"):
        if _ARGON2 is None:
            return False
        try:
            return bool(_ARGON2.check_needs_rehash(stored_hash))
        except Exception:
            return False
    return True
