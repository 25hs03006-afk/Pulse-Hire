from __future__ import annotations

from pathlib import Path

from app.services.parsers.extractors import slugify_identifier

SAMPLE_WORKSPACE = "sample"
ID_SEPARATOR = "--"


def normalize_workspace_id(value: str | None) -> str:
    normalized = slugify_identifier(value or SAMPLE_WORKSPACE)
    return normalized or SAMPLE_WORKSPACE


def scoped_entity_id(workspace_id: str, entity_id: str) -> str:
    workspace_id = normalize_workspace_id(workspace_id)
    if workspace_id == SAMPLE_WORKSPACE:
        return entity_id
    prefix = f"{workspace_id}{ID_SEPARATOR}"
    return entity_id if entity_id.startswith(prefix) else f"{prefix}{entity_id}"


def infer_workspace_from_entity_id(entity_id: str | None) -> str:
    value = (entity_id or "").strip()
    if ID_SEPARATOR in value:
        return normalize_workspace_id(value.split(ID_SEPARATOR, 1)[0])
    return SAMPLE_WORKSPACE


def workspace_source_dir(root: Path, workspace_id: str) -> Path:
    workspace_id = normalize_workspace_id(workspace_id)
    return root if workspace_id == SAMPLE_WORKSPACE else root / workspace_id


def infer_workspace_from_relative_root(root_dir: Path, source_path: Path) -> str:
    try:
        relative = source_path.relative_to(root_dir)
    except ValueError:
        return SAMPLE_WORKSPACE
    if len(relative.parts) > 1:
        first = relative.parts[0]
        if "." not in first:
            return normalize_workspace_id(first)
    return SAMPLE_WORKSPACE


def infer_workspace_from_path(source_path: str | None) -> str:
    path = Path(source_path or "")
    parts = list(path.parts)
    for marker in ("resumes", "jobs", "feedback"):
        lowered = [part.lower() for part in parts]
        if marker not in lowered:
            continue
        index = lowered.index(marker)
        if index + 1 >= len(parts):
            return SAMPLE_WORKSPACE
        candidate = parts[index + 1]
        if "." in candidate:
            return SAMPLE_WORKSPACE
        return normalize_workspace_id(candidate)
    return SAMPLE_WORKSPACE


def belongs_to_workspace(*, entity_id: str | None = None, source_path: str | None = None, workspace_id: str) -> bool:
    workspace_id = normalize_workspace_id(workspace_id)
    if entity_id and infer_workspace_from_entity_id(entity_id) == workspace_id:
        return True
    return infer_workspace_from_path(source_path) == workspace_id
