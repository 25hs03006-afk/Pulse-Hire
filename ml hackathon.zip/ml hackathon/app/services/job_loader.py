from __future__ import annotations

import csv
import hashlib
import io
import json
import threading
import time
from pathlib import Path

from app.config import Settings
from app.models import JobProfile
from app.services.parsers.extractors import parse_job_document, slugify_identifier
from app.services.workspaces import SAMPLE_WORKSPACE, infer_workspace_from_entity_id, infer_workspace_from_relative_root, scoped_entity_id


def _safe_csv_rows(raw_bytes: bytes) -> list[dict[str, str]]:
    for encoding in ("utf-8", "utf-8-sig", "latin-1", "utf-16"):
        try:
            decoded = raw_bytes.decode(encoding)
            rows = list(csv.DictReader(io.StringIO(decoded)))
            if rows:
                return [{str(key): str(value or "") for key, value in row.items()} for row in rows]
        except Exception:
            continue
    return []


def _row_value(row: dict[str, str], *keys: str) -> str:
    for key in keys:
        value = row.get(key)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def parse_job_records(file_name: str, raw_bytes: bytes, metadata: dict | None = None) -> list[JobProfile]:
    metadata = metadata or {}
    source_path = str(metadata.get("path") or file_name)
    if Path(file_name).suffix.lower() != ".csv":
        return [parse_job_document(file_name, raw_bytes, metadata)]

    rows = _safe_csv_rows(raw_bytes)
    if not rows:
        return [parse_job_document(file_name, raw_bytes, metadata)]

    jobs: list[JobProfile] = []
    for index, row in enumerate(rows, start=1):
        must_have = _row_value(
            row,
            "must_have_skills",
            "required_skills",
            "skills",
            "Key Skills",
            "key_skills",
            "Required Skills",
        ).replace("|", ",")
        nice_to_have = _row_value(
            row,
            "nice_to_have_skills",
            "preferred_skills",
            "Preferred Skills",
            "preferredSkills",
        ).replace("|", ",")
        responsibilities = _row_value(
            row,
            "responsibilities",
            "responsibility",
            "Responsibilities",
            "job_responsibilities",
        )
        payload = {
            "title": _row_value(row, "title", "job_title", "Job Title", "position", "Position") or f"Role {index}",
            "team": _row_value(row, "team", "department", "Department", "company"),
            "location": _row_value(row, "location", "Location", "job_location"),
            "employment_type": _row_value(row, "employment_type", "type", "Type", "employmentType"),
            "description": _row_value(row, "description", "job_description", "Job Description", "text", "content"),
            "must_have_skills": [item.strip() for item in must_have.split(",") if item.strip()],
            "nice_to_have_skills": [item.strip() for item in nice_to_have.split(",") if item.strip()],
            "responsibilities": [item.strip() for item in responsibilities.replace("\n", "|").split("|") if item.strip()],
            "min_years_experience": float(_row_value(row, "min_years_experience", "years_experience", "Experience", "experience_years") or 0.0),
            "education_requirement": _row_value(row, "education_requirement", "education", "Education", "qualification") or None,
        }
        job = parse_job_document(
            f"{Path(file_name).stem}-{index}.json",
            json.dumps(payload).encode("utf-8"),
            {"path": f"{source_path}#row={index}", "modified_at": metadata.get("modified_at")},
        )
        identity = f"{job.title.lower()}||{job.team or ''}||{source_path}||{index}"
        job_id = f"{slugify_identifier(job.title)}-{hashlib.sha1(identity.encode('utf-8')).hexdigest()[:8]}"
        jobs.append(
            job.model_copy(
                update={
                    "job_id": job_id,
                    "source_name": Path(source_path).name,
                    "origin_source_path": source_path,
                    "source_record_index": index,
                }
            )
        )
    if not jobs:
        raise ValueError("Could not parse any usable job descriptions from this dataset file.")
    return jobs


def build_default_jobs(settings: Settings) -> list[JobProfile]:
    templates = [
        {
            "job_id": "software-engineer-core",
            "title": "Software Engineer",
            "team": "Platform Engineering",
            "location": "Bengaluru, India",
            "description": "Build backend services, APIs, cloud infrastructure, and resilient engineering systems for production platforms.",
            "must_have_skills": ["Python", "Docker", "REST APIs", "Git", "CI/CD"],
            "nice_to_have_skills": ["Kubernetes", "AWS", "SQL", "Microservices"],
            "responsibilities": ["Build production APIs", "Improve service reliability", "Collaborate across engineering teams"],
            "min_years_experience": 3.0,
        },
        {
            "job_id": "data-scientist-core",
            "title": "Data Scientist",
            "team": "Applied Intelligence",
            "location": "Hyderabad, India",
            "description": "Develop machine learning models, experimentation frameworks, and decision support pipelines for product teams.",
            "must_have_skills": ["Python", "SQL", "Machine Learning", "Pandas", "Scikit-learn"],
            "nice_to_have_skills": ["PyTorch", "NLP", "A/B Testing", "Vector Search"],
            "responsibilities": ["Develop predictive models", "Run experiments", "Present insights to stakeholders"],
            "min_years_experience": 3.0,
        },
        {
            "job_id": "product-manager-core",
            "title": "Product Manager",
            "team": "Product",
            "location": "Mumbai, India",
            "description": "Drive roadmap decisions, stakeholder alignment, and experimentation for high-impact digital products.",
            "must_have_skills": ["Product Strategy", "Stakeholder Management", "A/B Testing"],
            "nice_to_have_skills": ["SQL", "Tableau", "User Research"],
            "responsibilities": ["Own roadmap", "Prioritize opportunities", "Align cross-functional teams"],
            "min_years_experience": 4.0,
        },
        {
            "job_id": "ui-ux-designer-core",
            "title": "UI/UX Designer",
            "team": "Design",
            "location": "Remote",
            "description": "Design intuitive workflows, strong interfaces, and user-centered product experiences.",
            "must_have_skills": ["Figma", "UX Design", "UI Design", "User Research"],
            "nice_to_have_skills": ["Product Strategy", "Stakeholder Management"],
            "responsibilities": ["Design flows", "Validate with users", "Ship polished interfaces"],
            "min_years_experience": 3.0,
        },
    ]
    jobs: list[JobProfile] = []
    for template in templates:
        raw = json.dumps(template).encode("utf-8")
        source_path = str(settings.generated_job_dir / f"{template['job_id']}.json")
        job = parse_job_document(f"{template['job_id']}.json", raw, {"path": source_path})
        jobs.append(job.model_copy(update={"job_id": template["job_id"], "source_path": source_path, "source_mode": "starter"}))
    return jobs


class JobDatasetLoader:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.raw_dir = settings.jobs_dir
        self.stream_dir = settings.job_stream_dir
        self.generated_dir = settings.job_stream_dir
        self.cache_dir = settings.cache_dir
        self.manifest_path = self.cache_dir / "job_loader_manifest.json"
        self.suppression_path = self.cache_dir / "job_loader_suppressions.json"
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._lock = threading.RLock()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._loop, daemon=True, name="job-loader")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def suppress_job(self, job_id: str) -> None:
        with self._lock:
            payload = self._load_json(self.suppression_path, default={"job_ids": []})
            job_ids = set(payload.get("job_ids", []))
            job_ids.add(job_id)
            self._write_json(self.suppression_path, {"job_ids": sorted(job_ids)})
            workspace_id = infer_workspace_from_entity_id(job_id)
            stream_base = self.stream_dir if workspace_id == SAMPLE_WORKSPACE else self.stream_dir / workspace_id
            target = stream_base / f"{job_id}.json"
            target.unlink(missing_ok=True)

    def restore_job(self, job_id: str) -> None:
        with self._lock:
            payload = self._load_json(self.suppression_path, default={"job_ids": []})
            job_ids = set(payload.get("job_ids", []))
            if job_id not in job_ids:
                return
            job_ids.remove(job_id)
            self._write_json(self.suppression_path, {"job_ids": sorted(job_ids)})

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.sync_once()
            except Exception:
                pass
            self._stop.wait(self.settings.loader_poll_interval_seconds)

    def sync_once(self) -> None:
        with self._lock:
            manifest = self._load_json(self.manifest_path, default={})
            suppressions = set(self._load_json(self.suppression_path, default={"job_ids": []}).get("job_ids", []))
            active_sources = {str(path): path for path in self.raw_dir.rglob("*") if path.is_file()}
            next_manifest: dict[str, dict] = {}
            active_job_ids: set[str] = set()

            for source_path_str, source_path in active_sources.items():
                workspace_id = infer_workspace_from_relative_root(self.raw_dir, source_path)
                checksum = hashlib.sha1(source_path.read_bytes()).hexdigest()
                record = manifest.get(source_path_str, {})
                stream_paths = [Path(path) for path in record.get("stream_paths", []) if path]
                cached_job_ids = set(record.get("job_ids", []))
                cache_complete = (
                    record.get("checksum") == checksum
                    and not record.get("error")
                    and (
                        (stream_paths and all(path.exists() for path in stream_paths))
                        or (cached_job_ids and not stream_paths and cached_job_ids.issubset(suppressions))
                    )
                )
                if cache_complete:
                    next_manifest[source_path_str] = record
                    active_job_ids.update(job_id for job_id in record.get("job_ids", []) if job_id not in suppressions)
                    continue

                old_paths = {Path(path) for path in record.get("stream_paths", [])}
                try:
                    raw_bytes = source_path.read_bytes()
                    jobs = parse_job_records(
                        source_path.name,
                        raw_bytes,
                        {"path": source_path_str, "modified_at": source_path.stat().st_mtime},
                    )
                    parsed_job_ids = [scoped_entity_id(workspace_id, job.job_id) for job in jobs]
                    new_paths: list[str] = []
                    for job in jobs:
                        scoped_job_id = scoped_entity_id(workspace_id, job.job_id)
                        if scoped_job_id in suppressions:
                            continue
                        stream_dir = self.stream_dir if workspace_id == SAMPLE_WORKSPACE else self.stream_dir / workspace_id
                        stream_path = stream_dir / f"{scoped_job_id}.json"
                        materialized = job.model_copy(
                            update={
                                "job_id": scoped_job_id,
                                "source_path": str(stream_path),
                                "origin_source_path": source_path_str,
                                "source_name": source_path.name,
                                "source_mode": "dataset",
                            }
                        )
                        self._write_text_atomic(stream_path, materialized.model_dump_json(indent=2))
                        new_paths.append(str(stream_path))
                        active_job_ids.add(scoped_job_id)
                    for stale in old_paths - {Path(path) for path in new_paths}:
                        stale.unlink(missing_ok=True)
                    next_manifest[source_path_str] = {
                        "checksum": checksum,
                        "job_ids": parsed_job_ids,
                        "stream_paths": new_paths,
                    }
                except Exception as exc:
                    for stale in old_paths:
                        stale.unlink(missing_ok=True)
                    next_manifest[source_path_str] = {
                        "checksum": checksum,
                        "job_ids": [],
                        "stream_paths": [],
                        "error": str(exc),
                    }

            removed_sources = set(manifest) - set(active_sources)
            for removed in removed_sources:
                for path in manifest.get(removed, {}).get("stream_paths", []):
                    Path(path).unlink(missing_ok=True)

            self._ensure_generated_jobs(active_job_ids, suppressions)
            self._write_json(self.manifest_path, next_manifest)

    def _ensure_generated_jobs(self, active_job_ids: set[str], suppressions: set[str]) -> None:
        defaults = build_default_jobs(self.settings)
        required_seed_count = max(int(self.settings.minimum_job_pool_size), 0)
        needed = max(required_seed_count - len(active_job_ids), 0)
        desired = [job for job in defaults if job.job_id not in suppressions][:needed]
        desired_ids = {job.job_id for job in desired}

        for default_job in defaults:
            stale_path = self.generated_dir / f"{default_job.job_id}.json"
            if default_job.job_id not in desired_ids:
                stale_path.unlink(missing_ok=True)

        for job in desired:
            stream_path = self.generated_dir / f"{job.job_id}.json"
            if job.job_id in active_job_ids or stream_path.exists():
                continue
            materialized = job.model_copy(update={"source_path": str(stream_path), "source_mode": "starter"})
            self._write_text_atomic(stream_path, materialized.model_dump_json(indent=2))

    def _load_json(self, path: Path, default):
        if not path.exists():
            return default
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default

    def _write_text_atomic(self, path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.cache_dir / f"{path.name}.{time.time_ns()}.tmp"
        temporary.parent.mkdir(parents=True, exist_ok=True)
        temporary.write_text(content, encoding="utf-8")
        temporary.replace(path)

    def _write_json(self, path: Path, payload: dict) -> None:
        self._write_text_atomic(path, json.dumps(payload, indent=2))
