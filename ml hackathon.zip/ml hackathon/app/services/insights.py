from __future__ import annotations

from collections import Counter
from statistics import mean
from typing import Any

from app.models import CandidateRanking, FeedbackEntry, JobProfile, RankingSnapshot
from app.services.skills import group_skills


def _feedback_summary(entries: list[FeedbackEntry]) -> dict[str, Any]:
    if not entries:
        return {"count": 0, "labels": [], "net_signal": 0.0}
    return {
        "count": len(entries),
        "labels": [entry.label for entry in entries[:4]],
        "net_signal": round(sum(entry.score_adjustment for entry in entries) / len(entries), 4),
    }


def _coverage_rows(job: JobProfile, snapshot: RankingSnapshot) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    total = max(len(snapshot.rankings), 1)
    for skill in job.must_have_skills:
        covered = [
            ranking.candidate.name
            for ranking in snapshot.rankings
            if skill.lower() in {item.lower() for item in ranking.candidate.skills}
        ]
        rows.append(
            {
                "skill": skill,
                "coverage_ratio": round(len(covered) / total, 4),
                "covered_candidates": covered[:6],
            }
        )
    return rows


def _skill_group_coverage(job: JobProfile, snapshot: RankingSnapshot) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    total = max(len(snapshot.rankings), 1)
    job_groups = job.skill_groups or group_skills([*job.must_have_skills, *job.nice_to_have_skills])
    for group_name, grouped_skills in job_groups.items():
        skill_rows: list[dict[str, Any]] = []
        family_coverages: list[float] = []
        covered_candidates_by_family: set[str] = set()
        for skill in grouped_skills:
            covered = [
                ranking.candidate.name
                for ranking in snapshot.rankings
                if skill.lower() in {candidate_skill.lower() for candidate_skill in ranking.candidate.skills}
            ]
            ratio = round(len(covered) / total, 4)
            skill_rows.append(
                {
                    "skill": skill,
                    "coverage_ratio": ratio,
                    "covered_candidates": covered[:6],
                }
            )
            family_coverages.append(ratio)
            covered_candidates_by_family.update(covered)
        rows.append(
            {
                "group": group_name,
                "skills": grouped_skills,
                "coverage_ratio": round(sum(family_coverages) / len(family_coverages), 4) if family_coverages else 0.0,
                "covered_candidates": sorted(covered_candidates_by_family)[:6],
                "skill_rows": skill_rows,
            }
        )
    return rows


def build_job_insights(
    job: JobProfile,
    snapshot: RankingSnapshot,
    feedback_entries: list[FeedbackEntry],
    recent_events: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    rankings = snapshot.rankings
    if not rankings:
        return {
            "headline": f"No candidates are currently ranked for {job.title}.",
            "coverage": [],
            "movement_digest": [],
            "recommendations": ["Ingest resume PDFs to start live screening."],
            "risk_register": ["No candidate evidence is available yet."],
            "fit_distribution": {},
        }

    top = rankings[0]
    fit_distribution = Counter(item.fit_band for item in rankings)
    hiring_target = max(int(job.hiring_target or 1), 1)
    shortlist = [item for item in rankings if item.fit_band in {"excellent", "strong"}] or rankings[:hiring_target]
    shortlist = shortlist[:hiring_target]
    movement_digest = [
        {
            "candidate_id": item.candidate.candidate_id,
            "name": item.candidate.name,
            "rank": item.rank,
            "rank_delta": item.rank_delta,
            "score_delta": item.score_delta,
            "movement_summary": item.movement_summary,
        }
        for item in rankings
        if item.rank_delta or abs(item.score_delta) >= 0.01
    ][:6]
    feedback_map: dict[str, list[FeedbackEntry]] = {}
    for entry in feedback_entries:
        feedback_map.setdefault(entry.candidate_id, []).append(entry)

    risk_register: list[str] = []
    if any(item.breakdown.missing_must_have_skills for item in rankings[:3]):
        risk_register.append("At least one top-ranked candidate still has must-have skill gaps.")
    if any(item.candidate.duplicate_of for item in rankings):
        risk_register.append("Potential duplicate resumes were detected and down-weighted.")
    if not risk_register:
        risk_register.append("The current shortlist is structurally healthy with no systemic blockers detected.")

    recommendations = [
        f"Prioritize {top.candidate.name} for the next recruiter touchpoint.",
        "Use the comparison panel to validate trade-offs between the top two candidates.",
        "Probe any remaining must-have gaps before final shortlist decisions.",
    ]
    if len(rankings) >= 2 and rankings[1].breakdown.total_score >= 0.72:
        recommendations[1] = f"Keep {rankings[1].candidate.name} as a strong backup shortlist option."

    return {
        "headline": snapshot.insight_summary,
        "top_candidate": {
            "candidate_id": top.candidate.candidate_id,
            "name": top.candidate.name,
            "rank": top.rank,
            "fit_band": top.fit_band,
            "decision_signal": top.decision_signal,
        },
        "fit_distribution": dict(fit_distribution),
        "shortlist": [
            {
                "candidate_id": item.candidate.candidate_id,
                "name": item.candidate.name,
                "rank": item.rank,
                "score": item.breakdown.total_score,
                "fit_band": item.fit_band,
                "decision_signal": item.decision_signal,
                "confidence_score": item.breakdown.confidence_score,
                "stability_score": item.breakdown.stability_score,
            }
            for item in shortlist[:hiring_target]
        ],
        "hiring_target": hiring_target,
        "coverage": _coverage_rows(job, snapshot),
        "skill_group_coverage": _skill_group_coverage(job, snapshot),
        "movement_digest": movement_digest,
        "recommendations": recommendations,
        "risk_register": risk_register,
        "feedback_summary": {
            ranking.candidate.name: _feedback_summary(feedback_map.get(ranking.candidate.candidate_id, []))
            for ranking in rankings[:5]
        },
        "live_activity": recent_events[:6] if recent_events else [],
        "average_score": round(mean(item.breakdown.total_score for item in rankings), 4),
        "stability_overview": {
            "average_stability": round(mean(item.breakdown.stability_score for item in rankings), 4),
            "high_confidence_candidates": sum(1 for item in rankings if item.breakdown.confidence_score >= 0.75),
            "volatile_candidates": [item.candidate.name for item in rankings if item.breakdown.stability_score < 0.45][:4],
        },
    }


def build_candidate_insight(
    job: JobProfile,
    ranking: CandidateRanking,
    feedback_entries: list[FeedbackEntry],
) -> dict[str, Any]:
    return {
        "candidate_id": ranking.candidate.candidate_id,
        "name": ranking.candidate.name,
        "current_title": ranking.candidate.current_title,
        "fit_band": ranking.fit_band,
        "decision_signal": ranking.decision_signal,
        "score": ranking.breakdown.total_score,
        "confidence_score": ranking.breakdown.confidence_score,
        "stability_score": ranking.breakdown.stability_score,
        "strengths": ranking.strengths,
        "risks": ranking.risks,
        "why_selected": ranking.why_selected,
        "why_not_selected": ranking.why_not_selected,
        "interview_focus": ranking.interview_focus,
        "movement_summary": ranking.movement_summary,
        "matched_skills": ranking.breakdown.matched_skills,
        "missing_skills": ranking.breakdown.missing_must_have_skills,
        "matched_skill_groups": ranking.breakdown.matched_skill_groups,
        "missing_skill_groups": ranking.breakdown.missing_skill_groups,
        "skill_groups": ranking.candidate.skill_groups,
        "matched_keywords": ranking.breakdown.matched_keywords,
        "feedback": _feedback_summary(feedback_entries),
        "evidence_sections": [item.section or "profile" for item in ranking.evidence],
        "job_title": job.title,
    }


def compare_candidates(job: JobProfile, left: CandidateRanking, right: CandidateRanking) -> dict[str, Any]:
    left_score = left.breakdown.total_score
    right_score = right.breakdown.total_score
    winner = left if left_score >= right_score else right
    loser = right if winner is left else left

    winner_edges: list[str] = []
    if winner.breakdown.must_have_score > loser.breakdown.must_have_score:
        winner_edges.append("better must-have coverage")
    if winner.breakdown.retrieval_score > loser.breakdown.retrieval_score:
        winner_edges.append("stronger grounded evidence in the resume")
    if winner.breakdown.experience_score > loser.breakdown.experience_score:
        winner_edges.append("deeper experience fit")
    if winner.breakdown.feedback_score > loser.breakdown.feedback_score:
        winner_edges.append("more positive recruiter signal")
    if not winner_edges:
        winner_edges.append("higher total composite score")

    loser_tradeoffs: list[str] = []
    if loser.breakdown.missing_must_have_skills:
        loser_tradeoffs.append("still missing " + ", ".join(loser.breakdown.missing_must_have_skills[:3]))
    if loser.risks:
        loser_tradeoffs.extend(loser.risks[:2])

    return {
        "job_title": job.title,
        "winner": {
            "candidate_id": winner.candidate.candidate_id,
            "name": winner.candidate.name,
            "score": winner.breakdown.total_score,
            "confidence_score": winner.breakdown.confidence_score,
            "reasons": winner_edges,
        },
        "runner_up": {
            "candidate_id": loser.candidate.candidate_id,
            "name": loser.candidate.name,
            "score": loser.breakdown.total_score,
            "confidence_score": loser.breakdown.confidence_score,
            "tradeoffs": loser_tradeoffs or ["No major trade-offs beyond lower overall score."],
        },
        "recommendation": (
            f"For {job.title}, {winner.candidate.name} is the better immediate choice because of "
            + ", ".join(winner_edges[:3])
            + "."
        ),
    }
