from __future__ import annotations

import secrets
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from app.services.sqlite_store import SQLiteJsonStore


def _utc_stamp() -> str:
    return datetime.now(UTC).isoformat()


class AuditLog:
    def __init__(self, database_path: Path) -> None:
        self._store = SQLiteJsonStore(database_path)
        self._namespace = "audit_events"

    def record(
        self,
        *,
        actor_type: str,
        actor_id: str | None,
        action: str,
        workspace_id: str | None = None,
        entity_kind: str | None = None,
        entity_id: str | None = None,
        status: str = "success",
        details: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        event_id = f"{_utc_stamp()}::{secrets.token_urlsafe(6)}"
        payload = {
            "event_id": event_id,
            "timestamp": _utc_stamp(),
            "actor_type": actor_type,
            "actor_id": actor_id,
            "workspace_id": workspace_id,
            "action": action,
            "entity_kind": entity_kind,
            "entity_id": entity_id,
            "status": status,
            "details": details or {},
        }
        self._store.set(self._namespace, event_id, payload)
        return payload

    def list_events(self, *, workspace_id: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        events = list(self._store.get_namespace(self._namespace).values())
        if workspace_id:
            events = [event for event in events if event.get("workspace_id") == workspace_id]
        events.sort(key=lambda item: item.get("timestamp", ""), reverse=True)
        return events[:limit]
