from __future__ import annotations

import csv
import io
import json
import re
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable

try:
    import yaml
except ImportError:  # pragma: no cover - fallback for bare environments
    yaml = None

from app.models import CandidateProfile, FeedbackEntry, JobProfile
from app.services.skills import group_skills, normalize_skills

def _utc_now() -> datetime:
    return datetime.now(UTC)


def _utc_from_timestamp(value: float | int) -> datetime:
    return datetime.fromtimestamp(value, UTC)


def _metadata_timestamp(metadata: dict | None) -> datetime:
    metadata = metadata or {}
    modified_at = metadata.get("modified_at")
    if modified_at is None:
        modified_at = _utc_now().timestamp()
    return _utc_from_timestamp(modified_at)


SECTION_HEADERS = {
    "summary",
    "experience",
    "work experience",
    "professional experience",
    "education",
    "skills",
    "projects",
    "certifications",
    "achievements",
    "contact",
    "responsibilities",
    "requirements",
    "must have",
    "nice to have",
}

SKILL_PATTERNS: dict[str, tuple[str, ...]] = {
    "Python": (r"\bpython\b",),
    "SQL": (r"\bsql\b", r"\bpostgres(?:ql)?\b", r"\bmysql\b"),
    "JavaScript": (r"\bjavascript\b", r"\bjs\b"),
    "TypeScript": (r"\btypescript\b", r"\bts\b"),
    "React": (r"\breact(?:js)?\b",),
    "Node.js": (r"\bnode(?:\.js|js)?\b",),
    "Java": (r"\bjava\b",),
    "FastAPI": (r"\bfastapi\b",),
    "Streamlit": (r"\bstreamlit\b",),
    "Docker": (r"\bdocker\b",),
    "Kubernetes": (r"\bkubernetes\b", r"\bk8s\b"),
    "AWS": (r"\baws\b", r"\bamazon web services\b"),
    "Azure": (r"\bazure\b",),
    "GCP": (r"\bgcp\b", r"\bgoogle cloud\b"),
    "PyTorch": (r"\bpytorch\b",),
    "TensorFlow": (r"\btensorflow\b",),
    "Scikit-learn": (r"\bscikit[- ]learn\b", r"\bsklearn\b"),
    "Pandas": (r"\bpandas\b",),
    "NumPy": (r"\bnumpy\b",),
    "Airflow": (r"\bairflow\b",),
    "Kafka": (r"\bkafka\b",),
    "Pathway": (r"\bpathway\b",),
    "RAG": (r"\brag\b", r"\bretrieval augmented generation\b"),
    "Vector Search": (r"\bvector (?:search|database|index)\b", r"\bfaiss\b", r"\bchroma\b", r"\bpinecone\b"),
    "LLMs": (r"\bllms?\b", r"\blarge language models?\b", r"\bgenerative ai\b"),
    "MLOps": (r"\bmlops\b", r"\bmachine learning operations\b"),
    "Machine Learning": (r"\bmachine learning\b", r"\bml models?\b"),
    "Deep Learning": (r"\bdeep learning\b",),
    "NLP": (r"\bnlp\b", r"\bnatural language processing\b"),
    "LangChain": (r"\blangchain\b",),
    "LlamaIndex": (r"\bllamaindex\b",),
    "ETL": (r"\betl\b",),
    "CI/CD": (r"\bci/cd\b", r"\bcontinuous integration\b", r"\bcontinuous delivery\b"),
    "Git": (r"\bgit\b",),
    "Linux": (r"\blinux\b",),
    "REST APIs": (r"\brest(?:ful)? apis?\b", r"\bapi development\b"),
    "Microservices": (r"\bmicroservices?\b",),
    "Redis": (r"\bredis\b",),
    "MongoDB": (r"\bmongodb\b",),
    "Spark": (r"\bspark\b", r"\bpyspark\b"),
    "XGBoost": (r"\bxgboost\b",),
    "Data Pipelines": (r"\bdata pipelines?\b", r"\bstream processing\b"),
    "dbt": (r"\bdbt\b",),
    "Tableau": (r"\btableau\b",),
    "Power BI": (r"\bpower bi\b",),
    "Product Strategy": (r"\bproduct strategy\b", r"\broadmap(?:ping)?\b", r"\bprioritization\b"),
    "Stakeholder Management": (r"\bstakeholder management\b", r"\bstakeholder communication\b"),
    "A/B Testing": (r"\ba/?b testing\b", r"\bexperimentation\b"),
    "User Research": (r"\buser research\b", r"\bux research\b"),
    "Figma": (r"\bfigma\b",),
    "UI Design": (r"\bui design\b", r"\bvisual design\b", r"\binterface design\b"),
    "UX Design": (r"\bux design\b", r"\binteraction design\b", r"\bwireframing\b", r"\bprototyping\b"),
}

DEGREE_PATTERNS: dict[str, tuple[str, ...]] = {
    "PhD": (r"\bph\.?d\b", r"\bdoctor of philosophy\b"),
    "Masters": (r"\bmaster(?:'s)?\b", r"\bm\.?tech\b", r"\bm\.?s\b", r"\bmba\b"),
    "Bachelors": (r"\bbachelor(?:'s)?\b", r"\bb\.?tech\b", r"\bb\.?e\b", r"\bb\.?s\b"),
    "Diploma": (r"\bdiploma\b",),
}

MONTH_LOOKUP = {
    "jan": 1,
    "feb": 2,
    "mar": 3,
    "apr": 4,
    "may": 5,
    "jun": 6,
    "jul": 7,
    "aug": 8,
    "sep": 9,
    "oct": 10,
    "nov": 11,
    "dec": 12,
}

NON_RESUME_MARKERS = {
    "problem statement",
    "evaluation criteria",
    "submission format",
    "deliverables",
    "hackathon",
    "presentation",
    "judges",
}

NON_JOB_MARKERS = {
    "problem statement",
    "evaluation criteria",
    "submission format",
    "demo video",
    "maximum of 12 slides",
    "hackathon",
    "judges",
}


def _clean_text_artifacts(text: str) -> str:
    cleaned = (
        text.replace("\ufeff", "")
        .replace("\u2022", "- ")
        .replace("â€¢", "- ")
        .replace("Ã¢â‚¬Â¢", "- ")
        .replace("â€“", "-")
        .replace("â€”", "-")
    )
    cleaned = re.sub(r"[ \t]+", " ", cleaned)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()


def _safe_text_decode(raw_bytes: bytes) -> str:
    for encoding in ("utf-8", "latin-1", "utf-16"):
        try:
            return _clean_text_artifacts(raw_bytes.decode(encoding))
        except UnicodeDecodeError:
            continue
    return _clean_text_artifacts(raw_bytes.decode("utf-8", errors="ignore"))


def _extract_text_from_pdf(raw_bytes: bytes) -> str:
    try:
        from pypdf import PdfReader
    except ImportError:
        return ""

    reader = PdfReader(io.BytesIO(raw_bytes))
    return _clean_text_artifacts("\n".join(page.extract_text() or "" for page in reader.pages).strip())


def _extract_text_from_docx(raw_bytes: bytes) -> str:
    try:
        import docx
    except ImportError:
        return _safe_text_decode(raw_bytes)

    document = docx.Document(io.BytesIO(raw_bytes))
    return _clean_text_artifacts("\n".join(paragraph.text for paragraph in document.paragraphs if paragraph.text).strip())


def extract_text_from_document(file_name: str, raw_bytes: bytes) -> str:
    suffix = Path(file_name).suffix.lower()
    if suffix == ".pdf":
        return _extract_text_from_pdf(raw_bytes)
    if suffix == ".docx":
        return _extract_text_from_docx(raw_bytes)
    return _safe_text_decode(raw_bytes)


def _fallback_partition_text(file_name: str, raw_bytes: bytes) -> str:
    suffix = Path(file_name).suffix.lower()
    try:
        if suffix == ".pdf":
            from unstructured.partition.pdf import partition_pdf

            elements = partition_pdf(file=io.BytesIO(raw_bytes))
        elif suffix == ".docx":
            from unstructured.partition.docx import partition_docx

            elements = partition_docx(file=io.BytesIO(raw_bytes))
        else:
            return ""
        return _clean_text_artifacts("\n".join(str(element) for element in elements if str(element).strip()))
    except Exception:
        return ""


def _looks_readable(text: str, minimum_characters: int = 40) -> bool:
    return len(re.sub(r"\W+", "", text)) >= minimum_characters


def has_readable_text(text: str, minimum_characters: int = 40) -> bool:
    return _looks_readable(text, minimum_characters=minimum_characters)


def _extract_text_from_pdf(raw_bytes: bytes) -> str:
    try:
        import fitz  # PyMuPDF

        with fitz.open(stream=raw_bytes, filetype="pdf") as document:
            primary = _clean_text_artifacts("\n".join(page.get_text("text") or "" for page in document))
        if _looks_readable(primary):
            return primary
    except Exception:
        pass

    try:
        import pdfplumber

        with pdfplumber.open(io.BytesIO(raw_bytes)) as document:
            secondary = _clean_text_artifacts("\n".join(page.extract_text() or "" for page in document.pages))
        if _looks_readable(secondary):
            return secondary
    except Exception:
        pass

    try:
        from pypdf import PdfReader
    except ImportError:
        return _safe_text_decode(raw_bytes)

    reader = PdfReader(io.BytesIO(raw_bytes))
    primary = _clean_text_artifacts("\n".join(page.extract_text() or "" for page in reader.pages).strip())
    if _looks_readable(primary):
        return primary
    fallback = _fallback_partition_text(".pdf", raw_bytes)
    if _looks_readable(fallback):
        return fallback
    return ""


def _extract_text_from_docx(raw_bytes: bytes) -> str:
    try:
        import docx
    except ImportError:
        return ""

    document = docx.Document(io.BytesIO(raw_bytes))
    primary = _clean_text_artifacts("\n".join(paragraph.text for paragraph in document.paragraphs if paragraph.text).strip())
    if _looks_readable(primary):
        return primary
    fallback = _fallback_partition_text(".docx", raw_bytes)
    if _looks_readable(fallback):
        return fallback
    return ""


def extract_text_from_document(file_name: str, raw_bytes: bytes) -> str:
    suffix = Path(file_name).suffix.lower()
    if suffix == ".pdf":
        return _extract_text_from_pdf(raw_bytes)
    if suffix == ".docx":
        return _extract_text_from_docx(raw_bytes)
    return _safe_text_decode(raw_bytes)


def slugify_identifier(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or "unknown"


def candidate_id_from_path(source_path: str) -> str:
    return slugify_identifier(Path(source_path).stem)


def job_id_from_path(source_path: str) -> str:
    return slugify_identifier(Path(source_path).stem)


def _normalize_lines(text: str) -> list[str]:
    return [line.strip() for line in re.split(r"[\r\n]+", text) if line.strip()]


def _find_email(text: str) -> str | None:
    match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text)
    return match.group(0) if match else None


def _find_phone(text: str) -> str | None:
    match = re.search(r"(\+?\d[\d\s().-]{8,}\d)", text)
    return match.group(1) if match else None


def _extract_name(lines: list[str]) -> str:
    for line in lines[:6]:
        cleaned = re.sub(r"\s+", " ", line).strip(" |,-")
        if not cleaned:
            continue
        lowered = cleaned.lower()
        if any(token in lowered for token in ("@", "linkedin", "github", "phone", "email")):
            continue
        if lowered in SECTION_HEADERS:
            continue
        if len(cleaned.split()) <= 6 and len(cleaned) <= 60:
            return cleaned.title()
    return "Unknown Candidate"


def _extract_location(lines: list[str]) -> str | None:
    city_hint = re.compile(
        r"\b(bengaluru|bangalore|mumbai|pune|hyderabad|delhi|gurugram|remote|chennai|noida|kolkata|london|new york|san francisco)\b",
        re.IGNORECASE,
    )
    for line in lines[:12]:
        lowered = line.lower()
        if lowered.startswith("location:"):
            return line.split(":", 1)[1].strip()
        if city_hint.search(line):
            if "|" in line:
                for segment in reversed([part.strip() for part in line.split("|")]):
                    if city_hint.search(segment):
                        return segment
            return line
    return None


def _extract_current_title(lines: list[str], name: str) -> str | None:
    for line in lines[:10]:
        if line == name:
            continue
        lowered = line.lower()
        if any(keyword in lowered for keyword in ("engineer", "scientist", "developer", "architect", "analyst", "manager", "lead")):
            return line
    return None


def _extract_prefixed_value(lines: list[str], prefix: str) -> str | None:
    prefix = prefix.lower().strip()
    for line in lines[:16]:
        lowered = line.lower()
        if lowered.startswith(prefix + ":"):
            return line.split(":", 1)[1].strip() or None
    return None


def _extract_skills(text: str) -> list[str]:
    lowered = text.lower()
    matches = []
    for skill, patterns in SKILL_PATTERNS.items():
        if any(re.search(pattern, lowered) for pattern in patterns):
            matches.append(skill)
    return normalize_skills(matches)


def _extract_education(lines: list[str]) -> list[str]:
    entries: list[str] = []
    for line in lines:
        lowered = line.lower()
        if any(re.search(pattern, lowered) for patterns in DEGREE_PATTERNS.values() for pattern in patterns):
            entries.append(line.lstrip("-*â€¢ ").strip())
    return entries[:5]


def _extract_highlights(lines: list[str], section_names: Iterable[str], limit: int = 6) -> list[str]:
    collected: list[str] = []
    active = False
    targets = {name.lower() for name in section_names}
    for line in lines:
        lowered = line.lower().strip(":")
        if lowered in targets:
            active = True
            continue
        if lowered in SECTION_HEADERS and lowered not in targets:
            active = False
        if active and (line.startswith(("-", "*", "•")) or len(line.split()) > 4):
            collected.append(line.lstrip("-*• ").strip())
        if len(collected) >= limit:
            break
    return collected


def _extract_summary(lines: list[str]) -> str:
    explicit_summary = _extract_highlights(lines, {"summary", "professional summary", "profile"}, limit=3)
    if explicit_summary:
        return " ".join(explicit_summary).strip()
    summary_lines: list[str] = []
    for line in lines[:12]:
        lowered = line.lower().strip(":")
        if lowered in SECTION_HEADERS:
            if summary_lines:
                break
            continue
        if any(token in lowered for token in ("@", "linkedin", "github")):
            continue
        summary_lines.append(line)
        if len(" ".join(summary_lines)) > 240:
            break
    return " ".join(summary_lines[:3]).strip()


def _parse_year_from_token(token: str) -> datetime | None:
    token = token.strip().lower()
    if token in {"present", "current", "now"}:
        return _utc_now()
    month_year = re.match(r"([a-z]{3,9})\s+(\d{4})", token)
    if month_year:
        month = MONTH_LOOKUP.get(month_year.group(1)[:3], 1)
        return datetime(int(month_year.group(2)), month, 1, tzinfo=UTC)
    year_only = re.match(r"(\d{4})", token)
    if year_only:
        return datetime(int(year_only.group(1)), 1, 1, tzinfo=UTC)
    month_numeric = re.match(r"(\d{1,2})/(\d{4})", token)
    if month_numeric:
        return datetime(int(month_numeric.group(2)), int(month_numeric.group(1)), 1, tzinfo=UTC)
    return None


def _estimate_years_experience(text: str) -> float:
    explicit_years = [
        float(match.group(1))
        for match in re.finditer(r"(\d+(?:\.\d+)?)\+?\s+years?\s+(?:of\s+)?experience", text, flags=re.IGNORECASE)
    ]
    if explicit_years:
        return max(explicit_years)

    total_months = 0.0
    for match in re.finditer(
        r"((?:[A-Za-z]{3,9}\s+\d{4})|(?:\d{1,2}/\d{4})|(?:\d{4}))\s*(?:-|to|–|—)\s*((?:present|current|now)|(?:[A-Za-z]{3,9}\s+\d{4})|(?:\d{1,2}/\d{4})|(?:\d{4}))",
        text,
        flags=re.IGNORECASE,
    ):
        start = _parse_year_from_token(match.group(1))
        end = _parse_year_from_token(match.group(2))
        if start and end and end >= start:
            total_months += max((end.year - start.year) * 12 + (end.month - start.month), 1)
    if total_months:
        return round(total_months / 12.0, 1)
    return 0.0


def _extract_certifications(lines: list[str]) -> list[str]:
    explicit = _extract_highlights(lines, {"certifications", "certification", "licenses"}, limit=5)
    if explicit:
        return explicit
    return [line for line in lines if "certified" in line.lower()][:5]


def _extract_projects(lines: list[str]) -> list[str]:
    return _extract_highlights(lines, {"projects", "project experience"}, limit=6)


def _extract_keywords(text: str, limit: int = 12) -> list[str]:
    stopwords = {
        "the",
        "and",
        "for",
        "with",
        "that",
        "this",
        "from",
        "into",
        "able",
        "will",
        "have",
        "has",
        "using",
        "use",
        "you",
        "your",
        "our",
        "their",
        "they",
        "are",
        "job",
        "role",
        "team",
        "candidate",
        "resume",
    }
    tokens = re.findall(r"[A-Za-z][A-Za-z0-9+/.-]{2,}", text.lower())
    frequency: dict[str, int] = defaultdict(int)
    for token in tokens:
        if token in stopwords:
            continue
        frequency[token] += 1
    ordered = sorted(frequency.items(), key=lambda item: (-item[1], item[0]))
    return [token for token, _ in ordered[:limit]]


def _looks_like_real_resume(candidate: CandidateProfile, text: str) -> bool:
    lowered = text.lower()
    negative_hits = sum(1 for marker in NON_RESUME_MARKERS if marker in lowered)
    resume_signals = sum(
        [
            bool(candidate.email),
            bool(candidate.phone),
            bool(candidate.location),
            bool(candidate.current_title),
            bool(candidate.education),
            bool(candidate.experience_highlights),
            candidate.years_experience > 0,
            len(candidate.skills) >= 3,
        ]
    )
    if negative_hits >= 2 and resume_signals <= 4 and candidate.years_experience < 1:
        return False
    return resume_signals >= 3


def _looks_like_real_job(job: JobProfile, text: str) -> bool:
    lowered = text.lower()
    if "hackathon" in lowered and any(marker in lowered for marker in {"problem statement", "evaluation criteria", "submission format"}):
        return False
    negative_hits = sum(1 for marker in NON_JOB_MARKERS if marker in lowered)
    structural_signals = sum(
        [
            bool(job.title and len(job.title.strip()) >= 3),
            bool(job.must_have_skills),
            bool(job.nice_to_have_skills),
            bool(job.responsibilities),
            bool(job.education_requirement),
            bool(job.team),
            bool(job.location),
            job.min_years_experience > 0,
        ]
    )
    narrative_signals = sum(
        marker in lowered
        for marker in {
            "requirements",
            "responsibilities",
            "must have",
            "nice to have",
            "qualifications",
            "employment type",
            "experience",
            "team",
            "location",
        }
    )
    if negative_hits >= 2 and structural_signals + narrative_signals <= 5:
        return False
    return structural_signals >= 3 and (structural_signals + narrative_signals) >= 5


def _parse_json_or_yaml(text: str) -> dict | list | None:
    loaders = [json.loads]
    if yaml is not None:
        loaders.append(yaml.safe_load)
    for loader in loaders:
        try:
            parsed = loader(text)
        except Exception:
            continue
        if parsed:
            return parsed
    return None


def parse_resume_document(file_name: str, raw_bytes: bytes, metadata: dict | None = None) -> CandidateProfile:
    metadata = metadata or {}
    source_path = str(metadata.get("path") or file_name)
    text = extract_text_from_document(file_name, raw_bytes)
    if not has_readable_text(text, minimum_characters=25):
        raise ValueError("Could not extract readable resume content.")
    parsed_structured = _parse_json_or_yaml(text) if Path(file_name).suffix.lower() in {".json", ".yaml", ".yml"} else None

    if isinstance(parsed_structured, dict):
        name = parsed_structured.get("name") or Path(file_name).stem.replace("_", " ").title()
        skills = parsed_structured.get("skills") or []
        education = parsed_structured.get("education") or []
        highlights = parsed_structured.get("experience_highlights") or parsed_structured.get("experience") or []
        projects = parsed_structured.get("projects") or []
        certifications = parsed_structured.get("certifications") or []
        years_experience = float(parsed_structured.get("years_experience") or 0.0)
        candidate = CandidateProfile(
            candidate_id=candidate_id_from_path(source_path),
            name=name,
            email=parsed_structured.get("email"),
            phone=parsed_structured.get("phone"),
            location=parsed_structured.get("location"),
            current_title=parsed_structured.get("current_title"),
            summary=parsed_structured.get("summary") or "",
            raw_text=text,
            skills=normalize_skills(str(skill) for skill in skills),
            skill_groups=group_skills(str(skill) for skill in skills),
            certifications=[str(item) for item in certifications],
            education=[str(item) for item in education],
            experience_highlights=[str(item) for item in highlights][:6],
            projects=[str(item) for item in projects][:6],
            years_experience=years_experience,
            source_path=source_path,
            last_updated=_metadata_timestamp(metadata),
        )
        if not _looks_like_real_resume(candidate, text):
            raise ValueError("The uploaded file does not look like a resume.")
        return candidate

    if Path(file_name).suffix.lower() == ".csv":
        decoded = _safe_text_decode(raw_bytes)
        reader = csv.DictReader(io.StringIO(decoded))
        rows = list(reader)
        if rows:
            row = rows[0]
            csv_skills = [item.strip() for item in (row.get("skills") or "").split("|") if item.strip()]
            candidate = CandidateProfile(
                candidate_id=candidate_id_from_path(source_path),
                name=row.get("name") or Path(file_name).stem.replace("_", " ").title(),
                email=row.get("email") or None,
                phone=row.get("phone") or None,
                location=row.get("location") or None,
                current_title=row.get("current_title") or None,
                summary=row.get("summary") or "",
                raw_text=text,
                skills=normalize_skills(csv_skills + _extract_skills(decoded)),
                skill_groups=group_skills(csv_skills + _extract_skills(decoded)),
                certifications=[item.strip() for item in (row.get("certifications") or "").split("|") if item.strip()],
                education=[item.strip() for item in (row.get("education") or "").split("|") if item.strip()],
                experience_highlights=[item.strip() for item in (row.get("experience_highlights") or "").split("|") if item.strip()],
                projects=[item.strip() for item in (row.get("projects") or "").split("|") if item.strip()],
                years_experience=float(row.get("years_experience") or 0.0),
                source_path=source_path,
                last_updated=_metadata_timestamp(metadata),
            )
            if not _looks_like_real_resume(candidate, text):
                raise ValueError("The uploaded file does not look like a resume.")
            return candidate

    lines = _normalize_lines(text)
    name = _extract_name(lines)
    skills = _extract_skills(text)
    candidate = CandidateProfile(
        candidate_id=candidate_id_from_path(source_path),
        name=name,
        email=_find_email(text),
        phone=_find_phone(text),
        location=_extract_location(lines),
        current_title=_extract_current_title(lines, name),
        summary=_extract_summary(lines),
        raw_text=text,
        skills=skills,
        skill_groups=group_skills(skills),
        certifications=_extract_certifications(lines),
        education=_extract_education(lines),
        experience_highlights=_extract_highlights(lines, {"experience", "work experience", "professional experience"}),
        projects=_extract_projects(lines),
        years_experience=_estimate_years_experience(text),
        source_path=source_path,
        last_updated=_metadata_timestamp(metadata),
    )
    if not _looks_like_real_resume(candidate, text):
        raise ValueError("The uploaded file does not look like a resume.")
    return candidate


def parse_job_document(file_name: str, raw_bytes: bytes, metadata: dict | None = None) -> JobProfile:
    metadata = metadata or {}
    source_path = str(metadata.get("path") or file_name)
    text = extract_text_from_document(file_name, raw_bytes)
    if not has_readable_text(text, minimum_characters=20):
        raise ValueError("Could not extract readable job content.")
    parsed = _parse_json_or_yaml(text)

    if isinstance(parsed, dict):
        title = parsed.get("title") or Path(file_name).stem.replace("_", " ").title()
        description = parsed.get("description") or text
        must_have = list(parsed.get("must_have_skills") or parsed.get("required_skills") or [])
        nice_to_have = list(parsed.get("nice_to_have_skills") or parsed.get("preferred_skills") or [])
        responsibilities = list(parsed.get("responsibilities") or [])
        keywords = list(parsed.get("keywords") or _extract_keywords(description))
        job = JobProfile(
            job_id=job_id_from_path(source_path),
            title=title,
            team=parsed.get("team"),
            location=parsed.get("location"),
            employment_type=parsed.get("employment_type"),
            description=description,
            must_have_skills=normalize_skills(str(skill) for skill in must_have) or _extract_skills(description)[:6],
            nice_to_have_skills=normalize_skills(str(skill) for skill in nice_to_have),
            skill_groups=group_skills([*(str(skill) for skill in must_have), *(str(skill) for skill in nice_to_have)]),
            responsibilities=[str(item) for item in responsibilities][:8],
            keywords=[str(item) for item in keywords][:12],
            hiring_target=max(1, int(parsed.get("hiring_target") or parsed.get("open_positions") or 1)),
            min_years_experience=float(parsed.get("min_years_experience") or 0.0),
            education_requirement=parsed.get("education_requirement"),
            source_path=source_path,
            last_updated=_metadata_timestamp(metadata),
        )
        if not _looks_like_real_job(job, text):
            raise ValueError("The uploaded file does not look like a job description.")
        return job

    lines = _normalize_lines(text)
    title = lines[0] if lines else Path(file_name).stem.replace("_", " ").title()
    required_lines = _extract_highlights(lines, {"requirements", "must have", "required skills"}, limit=8)
    preferred_lines = _extract_highlights(lines, {"nice to have", "preferred", "preferred skills"}, limit=6)
    must_have_text = "\n".join(required_lines) or text
    nice_to_have_text = "\n".join(preferred_lines)
    experience_match = re.search(r"(\d+(?:\.\d+)?)\+?\s+years?", text, flags=re.IGNORECASE)
    hiring_match = re.search(r"(\d+)\s+(?:open positions?|openings?|hires?|hiring target)", text, flags=re.IGNORECASE)
    education_requirement = None
    lowered = text.lower()
    for degree, patterns in DEGREE_PATTERNS.items():
        if any(re.search(pattern, lowered) for pattern in patterns):
            education_requirement = degree
            break
    must_have_skills = normalize_skills(_extract_skills(must_have_text) or _extract_skills(text)[:6])
    nice_to_have_skills = normalize_skills(_extract_skills(nice_to_have_text))
    job = JobProfile(
        job_id=job_id_from_path(source_path),
        title=title,
        team=_extract_prefixed_value(lines, "team"),
        location=_extract_prefixed_value(lines, "location"),
        employment_type=_extract_prefixed_value(lines, "employment type"),
        description=text,
        must_have_skills=must_have_skills,
        nice_to_have_skills=nice_to_have_skills,
        skill_groups=group_skills([*must_have_skills, *nice_to_have_skills]),
        responsibilities=_extract_highlights(lines, {"responsibilities", "what you will do", "what you'll do"}, limit=8),
        keywords=_extract_keywords(text),
        hiring_target=max(1, int(hiring_match.group(1))) if hiring_match else 1,
        min_years_experience=float(experience_match.group(1)) if experience_match else 0.0,
        education_requirement=education_requirement,
        source_path=source_path,
        last_updated=_metadata_timestamp(metadata),
    )
    if not _looks_like_real_job(job, text):
        raise ValueError("The uploaded file does not look like a job description.")
    return job


def parse_feedback_document(file_name: str, raw_bytes: bytes, metadata: dict | None = None) -> list[FeedbackEntry]:
    metadata = metadata or {}
    source_path = str(metadata.get("path") or file_name)
    text = extract_text_from_document(file_name, raw_bytes)
    if not has_readable_text(text, minimum_characters=10):
        raise ValueError("Could not extract readable feedback content.")
    parsed = _parse_json_or_yaml(text)
    entries: list[FeedbackEntry] = []

    def build_entry(payload: dict, index: int) -> FeedbackEntry:
        label = str(payload.get("label") or payload.get("decision") or payload.get("status") or "neutral").lower()
        score_map = {
            "strong_yes": 0.35,
            "shortlist": 0.20,
            "interview": 0.15,
            "interview_recommended": 0.30,
            "maybe": 0.05,
            "hold": -0.05,
            "reject": -0.35,
            "rejected": -0.35,
            "neutral": 0.0,
        }
        score_adjustment = float(payload.get("score_adjustment") or score_map.get(label, 0.0))
        candidate_id = payload.get("candidate_id") or candidate_id_from_path(payload.get("candidate_path") or source_path)
        job_id = payload.get("job_id")
        feedback_id = payload.get("feedback_id") or f"{slugify_identifier(source_path)}-{index}"
        created_at = payload.get("created_at")
        return FeedbackEntry(
            feedback_id=str(feedback_id),
            candidate_id=str(candidate_id),
            job_id=str(job_id) if job_id else None,
            recruiter=payload.get("recruiter"),
            label=label,
            score_adjustment=score_adjustment,
            notes=str(payload.get("notes") or ""),
            created_at=datetime.fromisoformat(created_at) if created_at else _metadata_timestamp(metadata),
            source_path=source_path,
        )

    if isinstance(parsed, list):
        for index, payload in enumerate(parsed, start=1):
            if isinstance(payload, dict):
                entries.append(build_entry(payload, index))
        return entries

    if isinstance(parsed, dict):
        return [build_entry(parsed, 1)]

    lines = _normalize_lines(text)
    payload = {
        "candidate_id": candidate_id_from_path(source_path),
        "job_id": None,
        "label": "neutral",
        "notes": " ".join(lines[:3]),
    }
    for line in lines:
        lowered = line.lower()
        if lowered.startswith("candidate_id:"):
            payload["candidate_id"] = line.split(":", 1)[1].strip()
        elif lowered.startswith("job_id:"):
            payload["job_id"] = line.split(":", 1)[1].strip()
        elif lowered.startswith("label:"):
            payload["label"] = line.split(":", 1)[1].strip()
        elif lowered.startswith("notes:"):
            payload["notes"] = line.split(":", 1)[1].strip()
    return [build_entry(payload, 1)]


def format_candidate_document(candidate: CandidateProfile) -> str:
    skills = ", ".join(candidate.skills) if candidate.skills else "Not explicitly listed"
    education = "; ".join(candidate.education) if candidate.education else "Not explicitly listed"
    highlights = "\n".join(f"- {item}" for item in candidate.experience_highlights[:4])
    projects = "\n".join(f"- {item}" for item in candidate.projects[:3])
    return (
        f"Candidate: {candidate.name}\n"
        f"Current title: {candidate.current_title or 'Unknown'}\n"
        f"Location: {candidate.location or 'Unknown'}\n"
        f"Years of experience: {candidate.years_experience}\n"
        f"Skills: {skills}\n"
        f"Education: {education}\n"
        f"Summary: {candidate.summary}\n"
        f"Experience highlights:\n{highlights or '- Not available'}\n"
        f"Projects:\n{projects or '- Not available'}\n"
        f"Raw resume text:\n{candidate.raw_text}"
    )
