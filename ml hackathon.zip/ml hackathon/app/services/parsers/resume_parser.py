from __future__ import annotations

import csv
import hashlib
import io
import re
from pathlib import Path
from typing import Iterable

from app.models import CandidateProfile
from app.services.parsers.extractors import (
    _estimate_years_experience,
    _extract_certifications,
    _extract_education,
    _extract_projects,
    _extract_skills,
    _extract_summary,
    _normalize_lines,
    parse_resume_document,
    slugify_identifier,
)
from app.services.skills import group_skills, normalize_skills


def _safe_csv_rows(raw_bytes: bytes) -> list[dict[str, str]]:
    for encoding in ("utf-8", "utf-8-sig", "latin-1", "utf-16"):
        try:
            decoded = raw_bytes.decode(encoding)
            rows = list(csv.DictReader(io.StringIO(decoded)))
            if rows:
                return [{str(key): str(value or "") for key, value in row.items()} for row in rows]
        except Exception:
            continue
    return []


def _row_value(row: dict[str, str], *keys: str) -> str:
    for key in keys:
        value = row.get(key)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def _candidate_label_from_row(row: dict[str, str], index: int) -> tuple[str, str | None]:
    category = _row_value(row, "category", "Category", "resume_category", "Resume_Category")
    explicit_name = _row_value(row, "name", "Name", "candidate_name", "Candidate_Name")
    current_title = _row_value(row, "current_title", "Current_Title", "title", "Title")
    if explicit_name:
        return explicit_name, current_title or category or None
    if category:
        return f"{category} Candidate {index}", current_title or category
    return f"Resume Candidate {index}", current_title or None


def _resume_text_from_row(row: dict[str, str]) -> str:
    ordered_fields = [
        "name",
        "Name",
        "category",
        "Category",
        "current_title",
        "Current_Title",
        "title",
        "Title",
        "email",
        "phone",
        "location",
        "summary",
        "skills",
        "experience",
        "experience_highlights",
        "education",
        "projects",
        "certifications",
        "resume",
        "Resume",
        "resume_str",
        "Resume_str",
        "resume_html",
        "Resume_html",
        "resume_text",
        "text",
        "content",
        "description",
        "Description",
    ]
    lines: list[str] = []
    for field in ordered_fields:
        value = (row.get(field) or "").strip()
        if not value:
            continue
        if field in {"skills", "education", "projects", "certifications", "experience_highlights"}:
            separator = "|" if "|" in value else ","
            value = "\n".join(f"- {item.strip()}" for item in value.split(separator) if item.strip())
        lines.append(f"{field.replace('_', ' ').title()}\n{value}")
    resume_blob = _row_value(
        row,
        "resume_str",
        "Resume_str",
        "resume",
        "Resume",
        "resume_text",
        "text",
        "content",
        "description",
        "Description",
    )
    category = _row_value(row, "category", "Category", "resume_category", "Resume_Category")
    if category and not _row_value(row, "current_title", "Current_Title", "title", "Title"):
        lines.insert(1 if lines else 0, f"Current Title\n{category}")
    if resume_blob and not any(marker in "\n".join(lines).lower() for marker in ("summary\n", "experience\n", "education\n")):
        lines.append(f"Summary\n{resume_blob}")
        lines.append(f"Experience\n{resume_blob}")
    if not lines:
        lines = [f"{key}: {value}" for key, value in row.items() if value and str(value).strip()]
    return "\n\n".join(lines)


def _stable_candidate_id(candidate: CandidateProfile, source_path: str, index: int) -> str:
    identity = "||".join(
        [
            candidate.name.strip().lower(),
            (candidate.email or "").strip().lower(),
            (candidate.phone or "").strip(),
            (candidate.location or "").strip().lower(),
            source_path,
            str(index),
        ]
    )
    digest = hashlib.sha1(identity.encode("utf-8")).hexdigest()[:8]
    return f"{slugify_identifier(candidate.name)}-{digest}"


def _candidate_from_row_fallback(
    *,
    source_path: str,
    file_name: str,
    index: int,
    payload_text: str,
    fallback_name: str,
    fallback_title: str | None,
    row: dict[str, str],
) -> CandidateProfile:
    lines = _normalize_lines(payload_text)
    raw_skills = _row_value(row, "skills", "Skills", "key_skills", "Key Skills", "required_skills", "Required Skills")
    parsed_skills = [item.strip() for item in raw_skills.replace("|", ",").split(",") if item.strip()]
    skills = normalize_skills(parsed_skills or _extract_skills(payload_text))
    summary = _row_value(row, "summary", "Summary") or _extract_summary(lines) or payload_text[:420]
    education = [item.strip() for item in _row_value(row, "education", "Education").replace("|", ",").split(",") if item.strip()]
    profile = CandidateProfile(
        candidate_id=slugify_identifier(f"{fallback_name}-{index}"),
        name=fallback_name,
        email=_row_value(row, "email", "Email") or None,
        phone=_row_value(row, "phone", "Phone") or None,
        location=_row_value(row, "location", "Location") or None,
        current_title=fallback_title or None,
        summary=summary,
        raw_text=payload_text,
        skills=skills,
        skill_groups=group_skills(skills),
        certifications=_extract_certifications(lines),
        education=education or _extract_education(lines),
        experience_highlights=[item for item in lines if len(item.split()) > 6][:6],
        projects=_extract_projects(lines),
        years_experience=float(_row_value(row, "years_experience", "Years_Experience") or _estimate_years_experience(payload_text) or 0.0),
        source_path=f"{source_path}#row={index}",
        source_name=Path(file_name).name,
    )
    return profile


def parse_resume_records(file_name: str, raw_bytes: bytes, metadata: dict | None = None) -> list[CandidateProfile]:
    metadata = metadata or {}
    source_path = str(metadata.get("path") or file_name)
    suffix = Path(file_name).suffix.lower()
    if suffix != ".csv":
        return [parse_resume_document(file_name, raw_bytes, metadata)]

    rows = _safe_csv_rows(raw_bytes)
    if not rows:
        return [parse_resume_document(file_name, raw_bytes, metadata)]

    candidates: list[CandidateProfile] = []
    for index, row in enumerate(rows, start=1):
        payload_text = _resume_text_from_row(row)
        if len(re.sub(r"\W+", "", payload_text)) < 20:
            continue
        row_path = f"{source_path}#row={index}"
        fallback_name, fallback_title = _candidate_label_from_row(row, index)
        try:
            candidate = parse_resume_document(
                f"{Path(file_name).stem}-{index}.txt",
                payload_text.encode("utf-8"),
                {"path": row_path, "modified_at": metadata.get("modified_at")},
            )
        except ValueError:
            candidate = _candidate_from_row_fallback(
                source_path=source_path,
                file_name=file_name,
                index=index,
                payload_text=payload_text,
                fallback_name=fallback_name,
                fallback_title=fallback_title,
                row=row,
            )
        explicit_name = _row_value(row, "name", "Name", "candidate_name", "Candidate_Name")
        normalized_name = (
            explicit_name
            or (candidate.name if candidate.name and candidate.name != "Unknown Candidate" else fallback_name)
            or fallback_name
        )
        if not explicit_name and fallback_name:
            normalized_name = fallback_name
        normalized_title = fallback_title or candidate.current_title
        candidate_id = _stable_candidate_id(candidate.model_copy(update={"name": normalized_name}), source_path, index)
        candidates.append(
            candidate.model_copy(
                update={
                    "candidate_id": candidate_id,
                    "name": normalized_name,
                    "current_title": normalized_title,
                    "source_name": Path(source_path).name,
                    "origin_source_path": source_path,
                    "source_record_index": index,
                    "resume_category": _row_value(row, "category", "Category", "resume_category", "Resume_Category") or None,
                }
            )
        )
    if not candidates:
        raise ValueError("Could not parse any usable resumes from this dataset file.")
    return candidates


def parse_uploaded_resume_records(file_name: str, raw_bytes: bytes, metadata: dict | None = None) -> list[CandidateProfile]:
    return parse_resume_records(file_name, raw_bytes, metadata)


def build_synthetic_candidate(
    *,
    candidate_id: str,
    name: str,
    title: str,
    location: str,
    summary: str,
    skills: Iterable[str],
    experience_highlights: Iterable[str],
    education: Iterable[str],
    years_experience: float,
    source_path: str,
) -> CandidateProfile:
    candidate = parse_resume_document(
        f"{candidate_id}.txt",
        (
            f"{name}\n{title}\n{location}\nSummary\n{summary}\nSkills\n"
            + ", ".join(skills)
            + "\nExperience\n"
            + "\n".join(f"- {item}" for item in experience_highlights)
            + "\nEducation\n"
            + "\n".join(f"- {item}" for item in education)
            + f"\n{years_experience} years of experience."
        ).encode("utf-8"),
        {"path": source_path},
    )
    return candidate.model_copy(
        update={
            "candidate_id": candidate_id,
            "name": name,
            "current_title": title,
            "location": location,
            "summary": summary,
            "skills": normalize_skills(skills),
            "skill_groups": group_skills(skills),
            "experience_highlights": list(experience_highlights),
            "education": list(education),
            "years_experience": years_experience,
            "source_path": source_path,
            "source_name": Path(source_path).name,
            "source_mode": "synthetic",
        }
    )
