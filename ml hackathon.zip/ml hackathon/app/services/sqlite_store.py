from __future__ import annotations

import json
import sqlite3
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock
from typing import Any


def _utc_stamp() -> str:
    return datetime.now(UTC).isoformat()


class SQLiteJsonStore:
    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(str(self.database_path))
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with self._lock, closing(self._connect()) as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS records (
                    namespace TEXT NOT NULL,
                    record_key TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(namespace, record_key)
                )
                """
            )
            connection.commit()

    def get(self, namespace: str, record_key: str, default: Any = None) -> Any:
        with self._lock, closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT payload FROM records WHERE namespace = ? AND record_key = ?",
                (namespace, record_key),
            ).fetchone()
        if not row:
            return default
        try:
            return json.loads(str(row["payload"]))
        except Exception:
            return default

    def get_namespace(self, namespace: str) -> dict[str, Any]:
        with self._lock, closing(self._connect()) as connection:
            rows = connection.execute(
                "SELECT record_key, payload FROM records WHERE namespace = ? ORDER BY record_key",
                (namespace,),
            ).fetchall()
        payload: dict[str, Any] = {}
        for row in rows:
            try:
                payload[str(row["record_key"])] = json.loads(str(row["payload"]))
            except Exception:
                continue
        return payload

    def set(self, namespace: str, record_key: str, value: Any) -> None:
        encoded = json.dumps(value, default=str)
        with self._lock, closing(self._connect()) as connection:
            connection.execute(
                """
                INSERT INTO records(namespace, record_key, payload, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(namespace, record_key) DO UPDATE SET
                    payload = excluded.payload,
                    updated_at = excluded.updated_at
                """,
                (namespace, record_key, encoded, _utc_stamp()),
            )
            connection.commit()

    def replace_namespace(self, namespace: str, mapping: dict[str, Any]) -> None:
        with self._lock, closing(self._connect()) as connection:
            connection.execute("DELETE FROM records WHERE namespace = ?", (namespace,))
            connection.executemany(
                "INSERT INTO records(namespace, record_key, payload, updated_at) VALUES (?, ?, ?, ?)",
                [
                    (namespace, str(record_key), json.dumps(value, default=str), _utc_stamp())
                    for record_key, value in mapping.items()
                ],
            )
            connection.commit()

    def delete(self, namespace: str, record_key: str) -> None:
        with self._lock, closing(self._connect()) as connection:
            connection.execute(
                "DELETE FROM records WHERE namespace = ? AND record_key = ?",
                (namespace, record_key),
            )
            connection.commit()

    def clear_namespace(self, namespace: str) -> None:
        with self._lock, closing(self._connect()) as connection:
            connection.execute("DELETE FROM records WHERE namespace = ?", (namespace,))
            connection.commit()
