from __future__ import annotations

from functools import lru_cache
from pathlib import Path

try:
    from pydantic_settings import BaseSettings, SettingsConfigDict
except ImportError:  # pragma: no cover - fallback for bare environments
    from pydantic import BaseModel

    class BaseSettings(BaseModel):  # type: ignore[misc]
        pass

    def SettingsConfigDict(**kwargs):  # type: ignore[misc]
        return kwargs


class Settings(BaseSettings):
    project_name: str = "PulseHire Live RAG"
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    vector_host: str = "0.0.0.0"
    vector_port: int = 8765
    ui_port: int = 8501

    data_root: Path = Path("data")
    resumes_dir: Path = Path("data/resumes")
    jobs_dir: Path = Path("data/jobs")
    feedback_dir: Path = Path("data/feedback")
    catalog_dir: Path = Path("data/catalog")
    staging_dir: Path = Path("data/staging")
    artifacts_dir: Path = Path("artifacts")
    cache_dir: Path = Path("artifacts/cache")
    platform_db_path: Path = Path("artifacts/platform.db")
    stream_root: Path = Path("artifacts/stream")
    resume_stream_dir: Path = Path("artifacts/stream/resumes")
    job_stream_dir: Path = Path("artifacts/stream/jobs")
    generated_root: Path = Path("artifacts/generated")
    generated_resume_dir: Path = Path("artifacts/generated/resumes")
    generated_job_dir: Path = Path("artifacts/generated/jobs")
    kaggle_root: Path = Path("artifacts/kaggle")

    retrieval_top_k: int = 8
    ranking_top_k: int = 10
    autocommit_duration_ms: int = 750
    ui_refresh_ms: int = 3000
    live_poll_interval_ms: int = 2000
    loader_poll_interval_seconds: float = 1.5
    max_upload_size_mb: int = 12
    max_dataset_bundle_size_mb: int = 256
    resume_upload_types: tuple[str, ...] = (".pdf", ".docx", ".txt", ".csv")
    job_upload_types: tuple[str, ...] = (".pdf", ".docx", ".txt", ".csv")
    feedback_upload_types: tuple[str, ...] = (".pdf", ".docx", ".txt", ".csv", ".json")
    minimum_candidate_pool_size: int = 0
    minimum_job_pool_size: int = 0
    allow_synthetic_backfill: bool = False
    kaggle_username: str | None = None
    kaggle_key: str | None = None
    kaggle_auto_sync: bool = False

    embedder_backend: str = "sentence-transformers"
    embedding_model: str = "BAAI/bge-small-en-v1.5"
    openai_api_key: str | None = None
    llm_model: str = "gpt-4.1-mini"

    score_weight_retrieval: float = 0.40
    score_weight_must_have: float = 0.20
    score_weight_nice_to_have: float = 0.10
    score_weight_experience: float = 0.10
    score_weight_education: float = 0.05
    score_weight_keyword: float = 0.05
    score_weight_feedback: float = 0.10

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    @property
    def vector_base_url(self) -> str:
        return f"http://127.0.0.1:{self.vector_port}"

    @property
    def ensured_directories(self) -> tuple[Path, ...]:
        return (
            self.data_root,
            self.resumes_dir,
            self.jobs_dir,
            self.feedback_dir,
            self.catalog_dir,
            self.staging_dir,
            self.artifacts_dir,
            self.cache_dir,
            self.platform_db_path.parent,
            self.stream_root,
            self.resume_stream_dir,
            self.job_stream_dir,
            self.generated_root,
            self.generated_resume_dir,
            self.generated_job_dir,
            self.kaggle_root,
        )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    settings = Settings()
    for directory in settings.ensured_directories:
        directory.mkdir(parents=True, exist_ok=True)
    return settings
