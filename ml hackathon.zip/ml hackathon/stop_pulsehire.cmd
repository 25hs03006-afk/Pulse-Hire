@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\stop_pulsehire.ps1"
